Este paquete contiene la tubería «inventory-cleaner» preparada para ejecutarse fuera del repositorio.

Estructura:
  tools\    Scripts necesarios para generar inventario y duplicados
  docs\     Artefactos HTML/JSON generados (pueden regenerarse con inventory-cleaner)
  logs\     Directorio vacío para salidas de ejecución

Uso sugerido:
  pwsh -NoProfile -ExecutionPolicy Bypass -File tools/agents/inventory-cleaner.ps1 -RepoRoot . -SweepMode None

Requisitos:
  - PowerShell 7+
  - Python instalado (para remove_nonmedia_duplicates / generate_duplicates_table)
