pwsh -NoLogo -ExecutionPolicy Bypass -File .\tools\push-repo-simple.ps1 -Branch main `
  -Message "inventario actualizado"