(function() {
    var _degree = 0,
        _timer = null,
        doc = document;

    function ts_button_stop_progress(doc) {
        if (_timer) {
            clearInterval(_timer);
            _timer = null;
        }
    }

	function bindHover() {
        TorrentStream.jQuery('#torrentstream-button .rotate', doc).hover(
            function() {
                if (_timer === null) {
					_timer = setInterval(function() {
							++_degree;
							var srotate = "rotate(" + _degree + "deg)";
							TorrentStream.jQuery('#torrentstream-button .rotate', doc).css({'-moz-transform': srotate, '-webkit-transform': srotate, '-o-transform': srotate, '-ms-transform': srotate, 'transform': srotate});
					}, 1);
				}
            },
            function() {
                ts_button_stop_progress(doc);
            }
            );
    };

    TorrentStream.Button = {
		init: function(){
            TorrentStream.Utils.log("tsbutton:init");
        },

        start: function() {
            if (_timer === null) {
                _timer = setInterval(function() {
                        ++_degree;
                        var srotate = "rotate(" + _degree + "deg)";
                        TorrentStream.jQuery('#torrentstream-button .rotate', doc).css({'-moz-transform': srotate, '-webkit-transform': srotate, '-o-transform': srotate, '-ms-transform': srotate, 'transform': srotate});
                }, 1);
            }
        },

        stop: function() {
            ts_button_stop_progress(doc);
            _degree = 0;
            TorrentStream.jQuery('#torrentstream-button .rotate', doc).css({'-moz-transform': 'rotate(0deg)', '-webkit-transform': 'rotate(0deg)', '-o-transform': 'rotate(0deg)', '-ms-transform': 'rotate(0deg)', 'transform': 'rotate(0deg)'});
        }
    };
})();