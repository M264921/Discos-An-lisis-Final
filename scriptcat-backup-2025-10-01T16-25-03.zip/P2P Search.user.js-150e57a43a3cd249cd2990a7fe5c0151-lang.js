if(typeof TorrentStream === "undefined") {
    throw "lang.js: missing TorrentStream object";
}

TorrentStream.Lang = function() {
    var _data = {},
        _defaultLang = 'en',
        _currentLang = 'en';

    function add(data) {
        _data = TorrentStream.Utils.extend(_data, data);
    }

    function setDefault(lang) {
        _defaultLang = lang;
    }

    function setCurrent(lang) {
        _currentLang = lang;
    }

    function getString(str, defaultValue) {
        if(_currentLang && _data[_currentLang] && _data[_currentLang][str]) {
            return _data[_currentLang][str];
        }
        else if(_defaultLang && _data[_defaultLang] && _data[_defaultLang][str]) {
            return _data[_defaultLang][str];
        }
        else {
            return (typeof defaultValue === "undefined") ? str : defaultValue;
        }
    }

    return {
        add: add,
        setCurrent: setCurrent,
        setDefault: setDefault,
        getString: getString
    };
}();