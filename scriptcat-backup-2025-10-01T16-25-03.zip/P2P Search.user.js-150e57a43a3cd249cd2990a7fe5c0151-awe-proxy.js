var AWE_Proxy = function() {
    var gApiAccessToken = null,
        gDeviceId = null,
        gInitiatorId = null,
        _a = null;

    function getUserId(deviceId) {
        var url = "https://auth3.acestream.net/c?a=" + deviceId;

        GM_xmlhttpRequest({
            method: "GET",
            url: url,
            timeout: 30000,
            onload: function(xhr) {
                if(xhr.status == 200) {
                    var userId = xhr.responseText;
                    if(userId) {
                        // register on engine
                        sendRequest({
                            method: "_a",
                            params: {
                                a: _a,
                                b: userId,
                            },
                            onsuccess: function(data) {
                                if(data) {
                                    gInitiatorId = data;
                                }
                            },
                            onerror: function(errmsg) {
                            }
                        });
                    }
                }
            }
        });
    }

    function makeParams(params) {
        var name, value, result = [];
        for(name in params) {
            value = params[name];
            if(value !== null && value !== undefined) {
                result.push(name + "=" + encodeURIComponent(value));
            }
        }
        return result.join("&");
    }

    function sendRequest(details) {
        function _success(data) {
            if(typeof details.onsuccess === "function") {
                details.onsuccess.call(null, data);
            }
        }

        function _failed(errmsg) {
            console.log("engineapi:request failed: " + errmsg);
            if(typeof details.onerror === "function") {
                details.onerror.call(null, errmsg);
            }
        }

        try {
            if(!details.method) {
                throw "missing method";
            }
            if(!details.params) {
                details.params = {};
            }
            if(!details.api) {
                details.api = "server";
            }

            if(details.needToken) {
                if(gApiAccessToken === null) {
                    // get token and send request again
                    getApiAccessToken(function(token) {
                        if(token === null) {
                            _failed("cannot get api access token");
                        }
                        else {
                            gApiAccessToken = token;
                            details.params.token = token;
                            sendRequest(details);
                        }
                    });
                    return;
                }
                details.params.token = gApiAccessToken;
            }

            details.params.method = details.method;

            var baseUrl;
            if(details.api == "server") {
                baseUrl = "http://127.0.0.1:6878/server/api"
            }
            else if(details.api == "service") {
                baseUrl = "http://127.0.0.1:6878/webui/api/service"
            }
            else {
                throw "unknown api: " + details.api;
            }

            var url =  baseUrl + "?" + makeParams(details.params);
            GM_xmlhttpRequest({
                method: "GET",
                url: url,
                timeout: 10000,
                onload: function(xhr) {
                    if(xhr.status == 200) {
                        try {
                            var data = JSON.parse(xhr.responseText);
                            if(data.error) {
                                _failed(data.error);
                            }
                            else if(!data.result) {
                                _failed("malformed response from engine");
                            }
                            else {
                                _success(data.result);
                            }
                        }
                        catch(e) {
                            _failed(e);
                        }
                    }
                    else {
                        _failed("bad http status: " + xhr.status);
                    }
                },
                onerror: function(xhr) {
                    _failed("status=" + xhr.status + " text=" + xhr.statusText);
                }
            });
        }
        catch(e) {
            console.log("sendRequest: " + e);
        }
    }

    function checkEngine(callback, retry_count, retry_interval) {
        try {
            var url = "http://127.0.0.1:6878/webui/api/service?method=get_version";
            if(gDeviceId === null) {
                url += "&params=device-id";
            }

            GM_xmlhttpRequest({
                method: "GET",
                url: url,
                timeout: 10000,
                onload: function(xhr) {
                    var errmsg = "",
                        engineRunning = false,
                        engineVersionString = null,
                        engineVersionCode = 0;

                    if(xhr.status == 200) {
                        var response = JSON.parse(xhr.responseText);
                        if(response.error) {
                            engineVersionCode = 0;
                            engineVersionString = null;
                            errmsg = response.error;
                        }
                        else if(!response.result) {
                            engineVersionCode = 0;
                            engineVersionString = null;
                            errmsg = "malformed response from engine";
                        }
                        else {
                            engineVersionCode = parseInt(response.result.code);
                            if(isNaN(engineVersionCode)) {
                                engineVersionCode = 0;
                            }
                            engineVersionString = response.result.version;
                            if(response.result.device_id) {
                                if(gDeviceId !== response.result.device_id) {
                                    gDeviceId = response.result.device_id;
                                    if(_a) {
                                        getUserId(gDeviceId);
                                    }
                                }
                            }
                        }
                    }
                    else {
                        engineVersionCode = 0;
                        engineVersionString = null;
                        errmsg = "engine returned error: " + xhr.status;
                    }
                    if(errmsg) {
                        console.log("checkEngine: error: " + errmsg);
                    }
                    engineRunning = !!engineVersionCode;

                    if(typeof callback === "function") {

                        if(!engineRunning && retry_count !== undefined && retry_count > 0) {
                            console.log("AWE: check engine failed (" + retry_count + "), next try in " + retry_interval);
                            window.setTimeout(function() {
                                    checkEngine(callback, retry_count-1, retry_interval);
                            }, retry_interval);
                        }
                        else {
                            callback.call(null, {
                                    running: !!engineVersionCode,
                                    versionCode: engineVersionCode,
                                    versionString: engineVersionString
                            });
                        }
                    }
                },
                onerror: function(xhr) {
                    callback.call(null, {
                        running: false,
                        versionCode: 0,
                        versionString: null,
                    });
                }
            });
        }
        catch(e) {
            console.log("checkEngine: error: " + e);
        }
    }

    function getApiAccessToken(callback) {
        sendRequest({
            method: "get_api_access_token",
            onsuccess: function(response) {
                if(response && response.token) {
                    callback(response.token);
                }
                else {
                    console.log("getApiAccessToken: malformed response", response);
                    callback(null);
                }
            },
            onerror: function(errmsg) {
                callback(null);
            }
        });
    }

    function AWE_getLocale(callback) {
        var locale = null;
        if(typeof navigator !== "undefined") {
            locale = navigator.language;
        }
        if(typeof callback === "function") {
            callback(locale);
        }
        return locale;
    }

    function AWE_engineStatus(callback) {
        if(typeof callback !== "function") {
            throw "missing callback in getEngineStatus()";
        }
        checkEngine(function(response) {
            function _send_response(running, version_code) {
                callback.call(null, {
                    running: running,
                    version: version_code
                });
            }

            if(response.running) {
                _send_response(response.running, response.versionCode);
            }
            else {
                _send_response(false, 0)
            }
        });
    }

    function AWE_getAvailablePlayers(details, callback) {
        if(typeof callback !== "function") {
            return;
        }

        var params = {};
        if(details.content_id) {
            params['content_id'] = details.content_id;
        }
        else if(details.transport_file_url) {
            params['url'] = details.transport_file_url;
        }
        else if(details.infohash) {
            params['infohash'] = details.infohash;
        }
        else {
            callback.call(null);
        }

        sendRequest({
                method: "get_available_players",
                params: params,
                onsuccess: function(data) {
                    callback.call(null, data);
                },
                onerror: function(errmsg) {
                    callback.call(null);
                }
        });
    }

    function AWE_openInPlayer(details, playerId, callback) {
        var params = {};
        if(gInitiatorId) {
            params['a'] = gInitiatorId;
        }
        if(details.content_id) {
            params['content_id'] = details.content_id;
        }
        else if(details.transport_file_url) {
            params['url'] = details.transport_file_url;
        }
        else if(details.infohash) {
            params['infohash'] = details.infohash;
        }
        else {
            callback.call(null);
        }
        if(playerId) {
            params['player_id'] = playerId;
        }

        sendRequest({
            method: "open_in_player",
            params: params,
            onsuccess: function(data) {
                if(typeof callback === "function") {
                    callback.call(null, data);
                }
            },
            onerror: function(errmsg) {
                if(typeof callback === "function") {
                    callback.call(null);
                }
            }
        });
    }

    function AWE_getDeviceId(callback) {
        sendRequest({
            api: "service",
            method: "get_public_user_key",
            onsuccess: function(data) {
                if(typeof callback === "function") {
                    callback.call(null, data);
                }
            },
            onerror: function(errmsg) {
                if(typeof callback === "function") {
                    callback.call(null);
                }
            }
        });
    }

    function AWE_getContentId(details, callback) {
        sendRequest({
            method: "get_content_id",
            params: {
                infohash: details.infohash,
            },
            onsuccess: function(data) {
                callback(data);
            },
            onerror: function(errmsg) {
                callback(null);
            }
        });
    }

    function AWE_addToPlaylist(details, callback) {
        sendRequest({
            method: "playlist_add_item",
            needToken: true,
            params: {
                id: details.content_id,
                infohash: details.infohash,
                url: details.transport_file_url,
                title: details.title,
                category: details.category,
                subcategory: details.subcategory,
                auto_search: details.auto_search,
            },
            onsuccess: function(data) {
                callback(data);
            },
            onerror: function(errmsg) {
                callback(null);
            }
        });
    }

    function AWE_setFavorite(details, callback) {
        sendRequest({
            method: "playlist_item_set_favorite",
            needToken: true,
            params: {
                id: details.id,
                value: (details.value ? 1 : 0)
            },
            onsuccess: function(data) {
                callback(data);
            },
            onerror: function(errmsg) {
                callback(null);
            }
        });
    }

    function AWE_getPlaylist(details, callback) {
        var params = {
            sort: details.sort || 0,
            offset: details.offset || 0,
            limit: details.limit || 25,
        };

        if(details.is_favorite) {
            params['is_favorite'] = 1;
        }
        if(details.name) {
            params['name'] = details.name;
        }

        sendRequest({
            method: "playlist_get",
            needToken: true,
            params: params,
            onsuccess: function(data) {
                callback(data);
            },
            onerror: function(errmsg) {
                callback(null);
            }
        });
    }

    function searchLocal(details, callback) {
        var method = details.suggest ? "suggest" : "search";
        var params = {};

        details.engineVersion = details.engineVersion || 0;

        if(details.query) {
            params['query'] = details.query;
        }
        if(details.category) {
            params['category'] = details.category;
        }
        if(details.page) {
            params['page'] = details.page;
        }
        if(details.page_size) {
            params['page_size'] = details.page_size;
        }
        if(details.group_by_channels) {
            params['group_by_channels'] = 1;
        }
        if(details.show_epg) {
            params['show_epg'] = 1;
        }

        var sortOnClient;
        if(details.engineVersion >= 3011200) {
            // engine will return properly sorted by relevance results
            sortOnClient = false;
        }
        else {
            // need to sort by relevance on client
            sortOnClient = true;
        }

        if(sortOnClient) {
            // hack to tell server that we need relevance in |name| field
            params['epg_name'] = "__old_format__";
        }

        sendRequest({
            method: method,
            needToken: true,
            params: params,
            onsuccess: function(data) {
                if(sortOnClient) {
                    for(var i=0; i < data.results.length; i++) {
                        var relevance = 99,
                            pos,
                            name,
                            channel = data.results[i];

                        if(channel.items && channel.items.length > 0) {
                            name = channel.items[0].name;
                            if(name.substring(0, 1) == "-") {
                                pos = name.indexOf("-", 1);
                                relevance = name.substring(1, pos);
                                relevance = parseInt(relevance);
                            }
                        }
                        channel.relevance = relevance;
                    }

                    data.results.sort(function(a, b) {
                        if(a.relevance < b.relevance) {
                            return -1;
                        }
                        if(a.relevance > b.relevance) {
                            return 1;
                        }
                        return 0;
                    });
                }

                callback(data);
            },
            onerror: function(errmsg) {
                callback(null);
            }
        });
    }

    function searchRemote(details, callback) {
        try {
            var method = details.suggest ? "suggest" : "search";
            var params = {
                _r: location.href
            };

            if(details.query) {
                params['q'] = details.query;
            }
            if(details.category) {
                params['category'] = details.category;
            }
            if(details.page) {
                params['p'] = details.page;
            }
            if(details.page_size) {
                params['ps'] = details.page_size;
            }

            var url = "https://api.acestream.me/" + method + "?";
            for(var p in params) {
                url += p + "=" + encodeURIComponent(params[p]) + "&";
            }

            GM_xmlhttpRequest({
                method: "GET",
                url: url,
                timeout: 30000,
                onload: function(xhr) {
                    var response = null;
                    if(xhr.status == 200) {
                        try {
                            response = JSON.parse(xhr.responseText);
                        }
                        catch(e) {
                            console.log("failed to parse response");
                        }
                    }
                    else {
                        console.log("search failed: status=" + xhr.status);
                    }

                    if(typeof callback === "function") {
                        callback(response);
                    }
                }
            });
        }
        catch(e) {
            console.log("search: error: " + e);
            if(typeof callback === "function") {
                callback(null);
            }
        }
    }

    function AWE_search(details, callback) {
        function _search(engineVersion) {
            details.engineVersion = engineVersion;
            if(engineVersion >= 3010600) {
                searchLocal(details, callback);
            }
            else {
                searchRemote(details, callback);
            }
        }

        if(typeof details.engineVersion === "undefined") {
            // get engine version before searching
            AWE_engineStatus(function(engineStatus) {
                _search(engineStatus.version);
            });
        }
        else {
            _search(details.engineVersion);
        }
    }

    function getEpgLocal(details, callback) {
        var now = TorrentStream.moment().unix();
        var params = {
            channel_id: details.channelId,
            min_stop: now,
            max_start: now + 12*3600,
        };

        sendRequest({
            method: "get_server_epg",
            needToken: true,
            params: params,
            onsuccess: function(response) {
                if(response && response.results) {
                    callback(response.results);
                }
                else {
                    callback(null);
                }
            },
            onerror: function(errmsg) {
                callback(null);
            }
        });
    }

    function getEpgRemote(details, callback) {
        try {
            var now = TorrentStream.moment().unix();
            var params = {
                _r: location.href,
                channel_id: details.channelId,
                min_stop: now,
                max_start: now + 12*3600,
            };

            var url = "https://api.acestream.me/epg?";
            for(var p in params) {
                url += p + "=" + encodeURIComponent(params[p]) + "&";
            }

            GM_xmlhttpRequest({
                method: "GET",
                url: url,
                timeout: 30000,
                onload: function(xhr) {
                    var response = null;
                    if(xhr.status == 200) {
                        try {
                            response = JSON.parse(xhr.responseText);
                        }
                        catch(e) {
                            console.log("getEpgRemote: failed to parse response");
                        }
                    }
                    else {
                        console.log("getEpgRemote: failed: status=" + xhr.status);
                    }

                    if(typeof callback === "function") {
                        if(response && response.results) {
                            callback(response.results);
                        }
                        else {
                            console.log("getEpgRemote: missing results");
                            callback(null);
                        }
                    }
                }
            });
        }
        catch(e) {
            console.log("getEpgRemote: error: " + e);
            if(typeof callback === "function") {
                callback(null);
            }
        }
    }

    function AWE_getEpg(details, callback) {
        function _get_epg(engineVersion) {
            if(engineVersion >= 3010600) {
                getEpgLocal(details, callback);
            }
            else {
                getEpgRemote(details, callback);
            }
        }

        if(typeof details.engineVersion === "undefined") {
            // get engine version before searching
            AWE_engineStatus(function(engineStatus) {
                _get_epg(engineStatus.version);
            });
        }
        else {
            _get_epg(details.engineVersion);
        }
    }

    // these method are not available outside extension
    function AWE_startJsPlayer(callback, async) {
        throw "startJsPlayer not implemented";
    }

    function AWE_registerContextMenuCommand(caption, commandFunc, accessKey, filterFunc) {
        throw "AWE_registerContextMenuCommand not implemented";
    }

    function AWE_getConfig(name, callback) {
        throw "AWE_getConfig not implemented";
    }

    return {
        AWE_getLocale: AWE_getLocale,
        AWE_engineStatus: AWE_engineStatus,
        AWE_getAvailablePlayers: AWE_getAvailablePlayers,
        AWE_openInPlayer: AWE_openInPlayer,
        AWE_getDeviceId: AWE_getDeviceId,
        AWE_getContentId: AWE_getContentId,
        AWE_addToPlaylist: AWE_addToPlaylist,
        AWE_search: AWE_search,
        AWE_startJsPlayer: AWE_startJsPlayer,
        AWE_registerContextMenuCommand: AWE_registerContextMenuCommand,
        AWE_getConfig: AWE_getConfig,
        AWE_getPlaylist: AWE_getPlaylist,
        AWE_setFavorite: AWE_setFavorite,
        AWE_getEpg: AWE_getEpg,
    };

}();

// export to global scope
var AWE_getLocale = AWE_Proxy.AWE_getLocale;
var AWE_engineStatus = AWE_Proxy.AWE_engineStatus;
var AWE_getAvailablePlayers = AWE_Proxy.AWE_getAvailablePlayers;
var AWE_openInPlayer = AWE_Proxy.AWE_openInPlayer;
var AWE_getDeviceId = AWE_Proxy.AWE_getDeviceId;
var AWE_getContentId = AWE_Proxy.AWE_getContentId;
var AWE_addToPlaylist = AWE_Proxy.AWE_addToPlaylist;
var AWE_search = AWE_Proxy.AWE_search;
var AWE_startJsPlayer = AWE_Proxy.AWE_startJsPlayer;
var AWE_registerContextMenuCommand = AWE_Proxy.AWE_registerContextMenuCommand;
var AWE_getConfig = AWE_Proxy.AWE_getConfig;
var AWE_getPlaylist = AWE_Proxy.AWE_getPlaylist;
var AWE_setFavorite = AWE_Proxy.AWE_setFavorite;
var AWE_getEpg = AWE_Proxy.AWE_getEpg;
