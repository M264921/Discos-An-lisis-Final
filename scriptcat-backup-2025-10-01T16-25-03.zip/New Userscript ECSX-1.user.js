// ==UserScript==
// @name         New Userscript ECSX-1
// @namespace    https://bbs.tampermonkey.net.cn/
// @version      0.1.0
// @description  try to take over the world!
// @author       You
// @match        https://*/*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // Your code here...<iframe src="http://acestream.org/embed/06013d0c0dcdd677ae09363db1b1f93bd97589bd?autoplay=1" width="560" height="315" />
})();
