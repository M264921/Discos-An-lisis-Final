TorrentStream.jQuery = window.jQuery.noConflict(true);
