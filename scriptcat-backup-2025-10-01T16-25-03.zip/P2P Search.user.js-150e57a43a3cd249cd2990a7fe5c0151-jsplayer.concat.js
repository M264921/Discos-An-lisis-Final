TorrentStream.initJsPlayer = function() {
    
    if(TorrentStream.__initJsPlayerDone) {
        console.log("js player init already done");
        return;
    };
    
    console.log("init js player");
    TorrentStream.__initJsPlayerDone = true;
    
// vim:ts=4:sts=4:sw=4:
/*!
 *
 * Copyright 2009-2016 Kris Kowal under the terms of the MIT
 * license found at https://github.com/kriskowal/q/blob/v1/LICENSE
 *
 * With parts by Tyler Close
 * Copyright 2007-2009 Tyler Close under the terms of the MIT X license found
 * at http://www.opensource.org/licenses/mit-license.html
 * Forked at ref_send.js version: 2009-05-11
 *
 * With parts by Mark Miller
 * Copyright (C) 2011 Google Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 */

(function (definition) {
    "use strict";

    // This file will function properly as a <script> tag, or a module
    // using CommonJS and NodeJS or RequireJS module formats.  In
    // Common/Node/RequireJS, the module exports the Q API and when
    // executed as a simple <script>, it creates a Q global instead.

    // Montage Require
    if (typeof bootstrap === "function") {
        bootstrap("promise", definition);

    // CommonJS
    } else if (typeof exports === "object" && typeof module === "object") {
        module.exports = definition();

    // RequireJS
    } else if (typeof define === "function" && define.amd) {
        define(definition);

    // SES (Secure EcmaScript)
    } else if (typeof ses !== "undefined") {
        if (!ses.ok()) {
            return;
        } else {
            ses.makeQ = definition;
        }

    // <script>
    } else if (typeof window !== "undefined" || typeof self !== "undefined") {
        // Prefer window over self for add-on scripts. Use self for
        // non-windowed contexts.
        var global = typeof window !== "undefined" ? window : self;

        // Get the `window` object, save the previous Q global
        // and initialize Q as a global.
        var previousQ = global.Q;
        global.Q = definition();

        // Add a noConflict function so Q can be removed from the
        // global namespace.
        global.Q.noConflict = function () {
            global.Q = previousQ;
            return this;
        };

    } else {
        throw new Error("This environment was not anticipated by Q. Please file a bug.");
    }

})(function () {
"use strict";

var hasStacks = false;
try {
    throw new Error();
} catch (e) {
    hasStacks = !!e.stack;
}

// All code after this point will be filtered from stack traces reported
// by Q.
var qStartingLine = captureLine();
var qFileName;

// shims

// used for fallback in "allResolved"
var noop = function () {};

// Use the fastest possible means to execute a task in a future turn
// of the event loop.
var nextTick =(function () {
    // linked list of tasks (single, with head node)
    var head = {task: void 0, next: null};
    var tail = head;
    var flushing = false;
    var requestTick = void 0;
    var isNodeJS = false;
    // queue for late tasks, used by unhandled rejection tracking
    var laterQueue = [];

    function flush() {
        /* jshint loopfunc: true */
        var task, domain;

        while (head.next) {
            head = head.next;
            task = head.task;
            head.task = void 0;
            domain = head.domain;

            if (domain) {
                head.domain = void 0;
                domain.enter();
            }
            runSingle(task, domain);

        }
        while (laterQueue.length) {
            task = laterQueue.pop();
            runSingle(task);
        }
        flushing = false;
    }
    // runs a single function in the async queue
    function runSingle(task, domain) {
        try {
            task();

        } catch (e) {
            if (isNodeJS) {
                // In node, uncaught exceptions are considered fatal errors.
                // Re-throw them synchronously to interrupt flushing!

                // Ensure continuation if the uncaught exception is suppressed
                // listening "uncaughtException" events (as domains does).
                // Continue in next event to avoid tick recursion.
                if (domain) {
                    domain.exit();
                }
                setTimeout(flush, 0);
                if (domain) {
                    domain.enter();
                }

                throw e;

            } else {
                // In browsers, uncaught exceptions are not fatal.
                // Re-throw them asynchronously to avoid slow-downs.
                setTimeout(function () {
                    throw e;
                }, 0);
            }
        }

        if (domain) {
            domain.exit();
        }
    }

    nextTick = function (task) {
        tail = tail.next = {
            task: task,
            domain: isNodeJS && process.domain,
            next: null
        };

        if (!flushing) {
            flushing = true;
            requestTick();
        }
    };

    if (typeof process === "object" &&
        process.toString() === "[object process]" && process.nextTick) {
        // Ensure Q is in a real Node environment, with a `process.nextTick`.
        // To see through fake Node environments:
        // * Mocha test runner - exposes a `process` global without a `nextTick`
        // * Browserify - exposes a `process.nexTick` function that uses
        //   `setTimeout`. In this case `setImmediate` is preferred because
        //    it is faster. Browserify's `process.toString()` yields
        //   "[object Object]", while in a real Node environment
        //   `process.nextTick()` yields "[object process]".
        isNodeJS = true;

        requestTick = function () {
            process.nextTick(flush);
        };

    } else if (typeof setImmediate === "function") {
        // In IE10, Node.js 0.9+, or https://github.com/NobleJS/setImmediate
        if (typeof window !== "undefined") {
            requestTick = setImmediate.bind(window, flush);
        } else {
            requestTick = function () {
                setImmediate(flush);
            };
        }

    } else if (typeof MessageChannel !== "undefined") {
        // modern browsers
        // http://www.nonblocking.io/2011/06/windownexttick.html
        var channel = new MessageChannel();
        // At least Safari Version 6.0.5 (8536.30.1) intermittently cannot create
        // working message ports the first time a page loads.
        channel.port1.onmessage = function () {
            requestTick = requestPortTick;
            channel.port1.onmessage = flush;
            flush();
        };
        var requestPortTick = function () {
            // Opera requires us to provide a message payload, regardless of
            // whether we use it.
            channel.port2.postMessage(0);
        };
        requestTick = function () {
            setTimeout(flush, 0);
            requestPortTick();
        };

    } else {
        // old browsers
        requestTick = function () {
            setTimeout(flush, 0);
        };
    }
    // runs a task after all other tasks have been run
    // this is useful for unhandled rejection tracking that needs to happen
    // after all `then`d tasks have been run.
    nextTick.runAfter = function (task) {
        laterQueue.push(task);
        if (!flushing) {
            flushing = true;
            requestTick();
        }
    };
    return nextTick;
})();

// Attempt to make generics safe in the face of downstream
// modifications.
// There is no situation where this is necessary.
// If you need a security guarantee, these primordials need to be
// deeply frozen anyway, and if you don’t need a security guarantee,
// this is just plain paranoid.
// However, this **might** have the nice side-effect of reducing the size of
// the minified code by reducing x.call() to merely x()
// See Mark Miller’s explanation of what this does.
// http://wiki.ecmascript.org/doku.php?id=conventions:safe_meta_programming
var call = Function.call;
function uncurryThis(f) {
    return function () {
        return call.apply(f, arguments);
    };
}
// This is equivalent, but slower:
// uncurryThis = Function_bind.bind(Function_bind.call);
// http://jsperf.com/uncurrythis

var array_slice = uncurryThis(Array.prototype.slice);

var array_reduce = uncurryThis(
    Array.prototype.reduce || function (callback, basis) {
        var index = 0,
            length = this.length;
        // concerning the initial value, if one is not provided
        if (arguments.length === 1) {
            // seek to the first value in the array, accounting
            // for the possibility that is is a sparse array
            do {
                if (index in this) {
                    basis = this[index++];
                    break;
                }
                if (++index >= length) {
                    throw new TypeError();
                }
            } while (1);
        }
        // reduce
        for (; index < length; index++) {
            // account for the possibility that the array is sparse
            if (index in this) {
                basis = callback(basis, this[index], index);
            }
        }
        return basis;
    }
);

var array_indexOf = uncurryThis(
    Array.prototype.indexOf || function (value) {
        // not a very good shim, but good enough for our one use of it
        for (var i = 0; i < this.length; i++) {
            if (this[i] === value) {
                return i;
            }
        }
        return -1;
    }
);

var array_map = uncurryThis(
    Array.prototype.map || function (callback, thisp) {
        var self = this;
        var collect = [];
        array_reduce(self, function (undefined, value, index) {
            collect.push(callback.call(thisp, value, index, self));
        }, void 0);
        return collect;
    }
);

var object_create = Object.create || function (prototype) {
    function Type() { }
    Type.prototype = prototype;
    return new Type();
};

var object_hasOwnProperty = uncurryThis(Object.prototype.hasOwnProperty);

var object_keys = Object.keys || function (object) {
    var keys = [];
    for (var key in object) {
        if (object_hasOwnProperty(object, key)) {
            keys.push(key);
        }
    }
    return keys;
};

var object_toString = uncurryThis(Object.prototype.toString);

function isObject(value) {
    return value === Object(value);
}

// generator related shims

// FIXME: Remove this function once ES6 generators are in SpiderMonkey.
function isStopIteration(exception) {
    return (
        object_toString(exception) === "[object StopIteration]" ||
        exception instanceof QReturnValue
    );
}

// FIXME: Remove this helper and Q.return once ES6 generators are in
// SpiderMonkey.
var QReturnValue;
if (typeof ReturnValue !== "undefined") {
    QReturnValue = ReturnValue;
} else {
    QReturnValue = function (value) {
        this.value = value;
    };
}

// long stack traces

var STACK_JUMP_SEPARATOR = "From previous event:";

function makeStackTraceLong(error, promise) {
    // If possible, transform the error stack trace by removing Node and Q
    // cruft, then concatenating with the stack trace of `promise`. See #57.
    if (hasStacks &&
        promise.stack &&
        typeof error === "object" &&
        error !== null &&
        error.stack &&
        error.stack.indexOf(STACK_JUMP_SEPARATOR) === -1
    ) {
        var stacks = [];
        for (var p = promise; !!p; p = p.source) {
            if (p.stack) {
                stacks.unshift(p.stack);
            }
        }
        stacks.unshift(error.stack);

        var concatedStacks = stacks.join("\n" + STACK_JUMP_SEPARATOR + "\n");
        error.stack = filterStackString(concatedStacks);
    }
}

function filterStackString(stackString) {
    var lines = stackString.split("\n");
    var desiredLines = [];
    for (var i = 0; i < lines.length; ++i) {
        var line = lines[i];

        if (!isInternalFrame(line) && !isNodeFrame(line) && line) {
            desiredLines.push(line);
        }
    }
    return desiredLines.join("\n");
}

function isNodeFrame(stackLine) {
    return stackLine.indexOf("(module.js:") !== -1 ||
           stackLine.indexOf("(node.js:") !== -1;
}

function getFileNameAndLineNumber(stackLine) {
    // Named functions: "at functionName (filename:lineNumber:columnNumber)"
    // In IE10 function name can have spaces ("Anonymous function") O_o
    var attempt1 = /at .+ \((.+):(\d+):(?:\d+)\)$/.exec(stackLine);
    if (attempt1) {
        return [attempt1[1], Number(attempt1[2])];
    }

    // Anonymous functions: "at filename:lineNumber:columnNumber"
    var attempt2 = /at ([^ ]+):(\d+):(?:\d+)$/.exec(stackLine);
    if (attempt2) {
        return [attempt2[1], Number(attempt2[2])];
    }

    // Firefox style: "function@filename:lineNumber or @filename:lineNumber"
    var attempt3 = /.*@(.+):(\d+)$/.exec(stackLine);
    if (attempt3) {
        return [attempt3[1], Number(attempt3[2])];
    }
}

function isInternalFrame(stackLine) {
    var fileNameAndLineNumber = getFileNameAndLineNumber(stackLine);

    if (!fileNameAndLineNumber) {
        return false;
    }

    var fileName = fileNameAndLineNumber[0];
    var lineNumber = fileNameAndLineNumber[1];

    return fileName === qFileName &&
        lineNumber >= qStartingLine &&
        lineNumber <= qEndingLine;
}

// discover own file name and line number range for filtering stack
// traces
function captureLine() {
    if (!hasStacks) {
        return;
    }

    try {
        throw new Error();
    } catch (e) {
        var lines = e.stack.split("\n");
        var firstLine = lines[0].indexOf("@") > 0 ? lines[1] : lines[2];
        var fileNameAndLineNumber = getFileNameAndLineNumber(firstLine);
        if (!fileNameAndLineNumber) {
            return;
        }

        qFileName = fileNameAndLineNumber[0];
        return fileNameAndLineNumber[1];
    }
}

function deprecate(callback, name, alternative) {
    return function () {
        if (typeof console !== "undefined" &&
            typeof console.warn === "function") {
            console.warn(name + " is deprecated, use " + alternative +
                         " instead.", new Error("").stack);
        }
        return callback.apply(callback, arguments);
    };
}

// end of shims
// beginning of real work

/**
 * Constructs a promise for an immediate reference, passes promises through, or
 * coerces promises from different systems.
 * @param value immediate reference or promise
 */
function Q(value) {
    // If the object is already a Promise, return it directly.  This enables
    // the resolve function to both be used to created references from objects,
    // but to tolerably coerce non-promises to promises.
    if (value instanceof Promise) {
        return value;
    }

    // assimilate thenables
    if (isPromiseAlike(value)) {
        return coerce(value);
    } else {
        return fulfill(value);
    }
}
Q.resolve = Q;

/**
 * Performs a task in a future turn of the event loop.
 * @param {Function} task
 */
Q.nextTick = nextTick;

/**
 * Controls whether or not long stack traces will be on
 */
Q.longStackSupport = false;

// enable long stacks if Q_DEBUG is set
if (typeof process === "object" && process && process.env && process.env.Q_DEBUG) {
    Q.longStackSupport = true;
}

/**
 * Constructs a {promise, resolve, reject} object.
 *
 * `resolve` is a callback to invoke with a more resolved value for the
 * promise. To fulfill the promise, invoke `resolve` with any value that is
 * not a thenable. To reject the promise, invoke `resolve` with a rejected
 * thenable, or invoke `reject` with the reason directly. To resolve the
 * promise to another thenable, thus putting it in the same state, invoke
 * `resolve` with that other thenable.
 */
Q.defer = defer;
function defer() {
    // if "messages" is an "Array", that indicates that the promise has not yet
    // been resolved.  If it is "undefined", it has been resolved.  Each
    // element of the messages array is itself an array of complete arguments to
    // forward to the resolved promise.  We coerce the resolution value to a
    // promise using the `resolve` function because it handles both fully
    // non-thenable values and other thenables gracefully.
    var messages = [], progressListeners = [], resolvedPromise;

    var deferred = object_create(defer.prototype);
    var promise = object_create(Promise.prototype);

    promise.promiseDispatch = function (resolve, op, operands) {
        var args = array_slice(arguments);
        if (messages) {
            messages.push(args);
            if (op === "when" && operands[1]) { // progress operand
                progressListeners.push(operands[1]);
            }
        } else {
            Q.nextTick(function () {
                resolvedPromise.promiseDispatch.apply(resolvedPromise, args);
            });
        }
    };

    // XXX deprecated
    promise.valueOf = function () {
        if (messages) {
            return promise;
        }
        var nearerValue = nearer(resolvedPromise);
        if (isPromise(nearerValue)) {
            resolvedPromise = nearerValue; // shorten chain
        }
        return nearerValue;
    };

    promise.inspect = function () {
        if (!resolvedPromise) {
            return { state: "pending" };
        }
        return resolvedPromise.inspect();
    };

    if (Q.longStackSupport && hasStacks) {
        try {
            throw new Error();
        } catch (e) {
            // NOTE: don't try to use `Error.captureStackTrace` or transfer the
            // accessor around; that causes memory leaks as per GH-111. Just
            // reify the stack trace as a string ASAP.
            //
            // At the same time, cut off the first line; it's always just
            // "[object Promise]\n", as per the `toString`.
            promise.stack = e.stack.substring(e.stack.indexOf("\n") + 1);
        }
    }

    // NOTE: we do the checks for `resolvedPromise` in each method, instead of
    // consolidating them into `become`, since otherwise we'd create new
    // promises with the lines `become(whatever(value))`. See e.g. GH-252.

    function become(newPromise) {
        resolvedPromise = newPromise;

        if (Q.longStackSupport && hasStacks) {
            // Only hold a reference to the new promise if long stacks
            // are enabled to reduce memory usage
            promise.source = newPromise;
        }

        array_reduce(messages, function (undefined, message) {
            Q.nextTick(function () {
                newPromise.promiseDispatch.apply(newPromise, message);
            });
        }, void 0);

        messages = void 0;
        progressListeners = void 0;
    }

    deferred.promise = promise;
    deferred.resolve = function (value) {
        if (resolvedPromise) {
            return;
        }

        become(Q(value));
    };

    deferred.fulfill = function (value) {
        if (resolvedPromise) {
            return;
        }

        become(fulfill(value));
    };
    deferred.reject = function (reason) {
        if (resolvedPromise) {
            return;
        }

        become(reject(reason));
    };
    deferred.notify = function (progress) {
        if (resolvedPromise) {
            return;
        }

        array_reduce(progressListeners, function (undefined, progressListener) {
            Q.nextTick(function () {
                progressListener(progress);
            });
        }, void 0);
    };

    return deferred;
}

/**
 * Creates a Node-style callback that will resolve or reject the deferred
 * promise.
 * @returns a nodeback
 */
defer.prototype.makeNodeResolver = function () {
    var self = this;
    return function (error, value) {
        if (error) {
            self.reject(error);
        } else if (arguments.length > 2) {
            self.resolve(array_slice(arguments, 1));
        } else {
            self.resolve(value);
        }
    };
};

/**
 * @param resolver {Function} a function that returns nothing and accepts
 * the resolve, reject, and notify functions for a deferred.
 * @returns a promise that may be resolved with the given resolve and reject
 * functions, or rejected by a thrown exception in resolver
 */
Q.Promise = promise; // ES6
Q.promise = promise;
function promise(resolver) {
    if (typeof resolver !== "function") {
        throw new TypeError("resolver must be a function.");
    }
    var deferred = defer();
    try {
        resolver(deferred.resolve, deferred.reject, deferred.notify);
    } catch (reason) {
        deferred.reject(reason);
    }
    return deferred.promise;
}

promise.race = race; // ES6
promise.all = all; // ES6
promise.reject = reject; // ES6
promise.resolve = Q; // ES6

// XXX experimental.  This method is a way to denote that a local value is
// serializable and should be immediately dispatched to a remote upon request,
// instead of passing a reference.
Q.passByCopy = function (object) {
    //freeze(object);
    //passByCopies.set(object, true);
    return object;
};

Promise.prototype.passByCopy = function () {
    //freeze(object);
    //passByCopies.set(object, true);
    return this;
};

/**
 * If two promises eventually fulfill to the same value, promises that value,
 * but otherwise rejects.
 * @param x {Any*}
 * @param y {Any*}
 * @returns {Any*} a promise for x and y if they are the same, but a rejection
 * otherwise.
 *
 */
Q.join = function (x, y) {
    return Q(x).join(y);
};

Promise.prototype.join = function (that) {
    return Q([this, that]).spread(function (x, y) {
        if (x === y) {
            // TODO: "===" should be Object.is or equiv
            return x;
        } else {
            throw new Error("Q can't join: not the same: " + x + " " + y);
        }
    });
};

/**
 * Returns a promise for the first of an array of promises to become settled.
 * @param answers {Array[Any*]} promises to race
 * @returns {Any*} the first promise to be settled
 */
Q.race = race;
function race(answerPs) {
    return promise(function (resolve, reject) {
        // Switch to this once we can assume at least ES5
        // answerPs.forEach(function (answerP) {
        //     Q(answerP).then(resolve, reject);
        // });
        // Use this in the meantime
        for (var i = 0, len = answerPs.length; i < len; i++) {
            Q(answerPs[i]).then(resolve, reject);
        }
    });
}

Promise.prototype.race = function () {
    return this.then(Q.race);
};

/**
 * Constructs a Promise with a promise descriptor object and optional fallback
 * function.  The descriptor contains methods like when(rejected), get(name),
 * set(name, value), post(name, args), and delete(name), which all
 * return either a value, a promise for a value, or a rejection.  The fallback
 * accepts the operation name, a resolver, and any further arguments that would
 * have been forwarded to the appropriate method above had a method been
 * provided with the proper name.  The API makes no guarantees about the nature
 * of the returned object, apart from that it is usable whereever promises are
 * bought and sold.
 */
Q.makePromise = Promise;
function Promise(descriptor, fallback, inspect) {
    if (fallback === void 0) {
        fallback = function (op) {
            return reject(new Error(
                "Promise does not support operation: " + op
            ));
        };
    }
    if (inspect === void 0) {
        inspect = function () {
            return {state: "unknown"};
        };
    }

    var promise = object_create(Promise.prototype);

    promise.promiseDispatch = function (resolve, op, args) {
        var result;
        try {
            if (descriptor[op]) {
                result = descriptor[op].apply(promise, args);
            } else {
                result = fallback.call(promise, op, args);
            }
        } catch (exception) {
            result = reject(exception);
        }
        if (resolve) {
            resolve(result);
        }
    };

    promise.inspect = inspect;

    // XXX deprecated `valueOf` and `exception` support
    if (inspect) {
        var inspected = inspect();
        if (inspected.state === "rejected") {
            promise.exception = inspected.reason;
        }

        promise.valueOf = function () {
            var inspected = inspect();
            if (inspected.state === "pending" ||
                inspected.state === "rejected") {
                return promise;
            }
            return inspected.value;
        };
    }

    return promise;
}

Promise.prototype.toString = function () {
    return "[object Promise]";
};

Promise.prototype.then = function (fulfilled, rejected, progressed) {
    var self = this;
    var deferred = defer();
    var done = false;   // ensure the untrusted promise makes at most a
                        // single call to one of the callbacks

    function _fulfilled(value) {
        try {
            return typeof fulfilled === "function" ? fulfilled(value) : value;
        } catch (exception) {
            return reject(exception);
        }
    }

    function _rejected(exception) {
        if (typeof rejected === "function") {
            makeStackTraceLong(exception, self);
            try {
                return rejected(exception);
            } catch (newException) {
                return reject(newException);
            }
        }
        return reject(exception);
    }

    function _progressed(value) {
        return typeof progressed === "function" ? progressed(value) : value;
    }

    Q.nextTick(function () {
        self.promiseDispatch(function (value) {
            if (done) {
                return;
            }
            done = true;

            deferred.resolve(_fulfilled(value));
        }, "when", [function (exception) {
            if (done) {
                return;
            }
            done = true;

            deferred.resolve(_rejected(exception));
        }]);
    });

    // Progress propagator need to be attached in the current tick.
    self.promiseDispatch(void 0, "when", [void 0, function (value) {
        var newValue;
        var threw = false;
        try {
            newValue = _progressed(value);
        } catch (e) {
            threw = true;
            if (Q.onerror) {
                Q.onerror(e);
            } else {
                throw e;
            }
        }

        if (!threw) {
            deferred.notify(newValue);
        }
    }]);

    return deferred.promise;
};

Q.tap = function (promise, callback) {
    return Q(promise).tap(callback);
};

/**
 * Works almost like "finally", but not called for rejections.
 * Original resolution value is passed through callback unaffected.
 * Callback may return a promise that will be awaited for.
 * @param {Function} callback
 * @returns {Q.Promise}
 * @example
 * doSomething()
 *   .then(...)
 *   .tap(console.log)
 *   .then(...);
 */
Promise.prototype.tap = function (callback) {
    callback = Q(callback);

    return this.then(function (value) {
        return callback.fcall(value).thenResolve(value);
    });
};

/**
 * Registers an observer on a promise.
 *
 * Guarantees:
 *
 * 1. that fulfilled and rejected will be called only once.
 * 2. that either the fulfilled callback or the rejected callback will be
 *    called, but not both.
 * 3. that fulfilled and rejected will not be called in this turn.
 *
 * @param value      promise or immediate reference to observe
 * @param fulfilled  function to be called with the fulfilled value
 * @param rejected   function to be called with the rejection exception
 * @param progressed function to be called on any progress notifications
 * @return promise for the return value from the invoked callback
 */
Q.when = when;
function when(value, fulfilled, rejected, progressed) {
    return Q(value).then(fulfilled, rejected, progressed);
}

Promise.prototype.thenResolve = function (value) {
    return this.then(function () { return value; });
};

Q.thenResolve = function (promise, value) {
    return Q(promise).thenResolve(value);
};

Promise.prototype.thenReject = function (reason) {
    return this.then(function () { throw reason; });
};

Q.thenReject = function (promise, reason) {
    return Q(promise).thenReject(reason);
};

/**
 * If an object is not a promise, it is as "near" as possible.
 * If a promise is rejected, it is as "near" as possible too.
 * If it’s a fulfilled promise, the fulfillment value is nearer.
 * If it’s a deferred promise and the deferred has been resolved, the
 * resolution is "nearer".
 * @param object
 * @returns most resolved (nearest) form of the object
 */

// XXX should we re-do this?
Q.nearer = nearer;
function nearer(value) {
    if (isPromise(value)) {
        var inspected = value.inspect();
        if (inspected.state === "fulfilled") {
            return inspected.value;
        }
    }
    return value;
}

/**
 * @returns whether the given object is a promise.
 * Otherwise it is a fulfilled value.
 */
Q.isPromise = isPromise;
function isPromise(object) {
    return object instanceof Promise;
}

Q.isPromiseAlike = isPromiseAlike;
function isPromiseAlike(object) {
    return isObject(object) && typeof object.then === "function";
}

/**
 * @returns whether the given object is a pending promise, meaning not
 * fulfilled or rejected.
 */
Q.isPending = isPending;
function isPending(object) {
    return isPromise(object) && object.inspect().state === "pending";
}

Promise.prototype.isPending = function () {
    return this.inspect().state === "pending";
};

/**
 * @returns whether the given object is a value or fulfilled
 * promise.
 */
Q.isFulfilled = isFulfilled;
function isFulfilled(object) {
    return !isPromise(object) || object.inspect().state === "fulfilled";
}

Promise.prototype.isFulfilled = function () {
    return this.inspect().state === "fulfilled";
};

/**
 * @returns whether the given object is a rejected promise.
 */
Q.isRejected = isRejected;
function isRejected(object) {
    return isPromise(object) && object.inspect().state === "rejected";
}

Promise.prototype.isRejected = function () {
    return this.inspect().state === "rejected";
};

//// BEGIN UNHANDLED REJECTION TRACKING

// This promise library consumes exceptions thrown in handlers so they can be
// handled by a subsequent promise.  The exceptions get added to this array when
// they are created, and removed when they are handled.  Note that in ES6 or
// shimmed environments, this would naturally be a `Set`.
var unhandledReasons = [];
var unhandledRejections = [];
var reportedUnhandledRejections = [];
var trackUnhandledRejections = true;

function resetUnhandledRejections() {
    unhandledReasons.length = 0;
    unhandledRejections.length = 0;

    if (!trackUnhandledRejections) {
        trackUnhandledRejections = true;
    }
}

function trackRejection(promise, reason) {
    if (!trackUnhandledRejections) {
        return;
    }
    if (typeof process === "object" && typeof process.emit === "function") {
        Q.nextTick.runAfter(function () {
            if (array_indexOf(unhandledRejections, promise) !== -1) {
                process.emit("unhandledRejection", reason, promise);
                reportedUnhandledRejections.push(promise);
            }
        });
    }

    unhandledRejections.push(promise);
    if (reason && typeof reason.stack !== "undefined") {
        unhandledReasons.push(reason.stack);
    } else {
        unhandledReasons.push("(no stack) " + reason);
    }
}

function untrackRejection(promise) {
    if (!trackUnhandledRejections) {
        return;
    }

    var at = array_indexOf(unhandledRejections, promise);
    if (at !== -1) {
        if (typeof process === "object" && typeof process.emit === "function") {
            Q.nextTick.runAfter(function () {
                var atReport = array_indexOf(reportedUnhandledRejections, promise);
                if (atReport !== -1) {
                    process.emit("rejectionHandled", unhandledReasons[at], promise);
                    reportedUnhandledRejections.splice(atReport, 1);
                }
            });
        }
        unhandledRejections.splice(at, 1);
        unhandledReasons.splice(at, 1);
    }
}

Q.resetUnhandledRejections = resetUnhandledRejections;

Q.getUnhandledReasons = function () {
    // Make a copy so that consumers can't interfere with our internal state.
    return unhandledReasons.slice();
};

Q.stopUnhandledRejectionTracking = function () {
    resetUnhandledRejections();
    trackUnhandledRejections = false;
};

resetUnhandledRejections();

//// END UNHANDLED REJECTION TRACKING

/**
 * Constructs a rejected promise.
 * @param reason value describing the failure
 */
Q.reject = reject;
function reject(reason) {
    var rejection = Promise({
        "when": function (rejected) {
            // note that the error has been handled
            if (rejected) {
                untrackRejection(this);
            }
            return rejected ? rejected(reason) : this;
        }
    }, function fallback() {
        return this;
    }, function inspect() {
        return { state: "rejected", reason: reason };
    });

    // Note that the reason has not been handled.
    trackRejection(rejection, reason);

    return rejection;
}

/**
 * Constructs a fulfilled promise for an immediate reference.
 * @param value immediate reference
 */
Q.fulfill = fulfill;
function fulfill(value) {
    return Promise({
        "when": function () {
            return value;
        },
        "get": function (name) {
            return value[name];
        },
        "set": function (name, rhs) {
            value[name] = rhs;
        },
        "delete": function (name) {
            delete value[name];
        },
        "post": function (name, args) {
            // Mark Miller proposes that post with no name should apply a
            // promised function.
            if (name === null || name === void 0) {
                return value.apply(void 0, args);
            } else {
                return value[name].apply(value, args);
            }
        },
        "apply": function (thisp, args) {
            return value.apply(thisp, args);
        },
        "keys": function () {
            return object_keys(value);
        }
    }, void 0, function inspect() {
        return { state: "fulfilled", value: value };
    });
}

/**
 * Converts thenables to Q promises.
 * @param promise thenable promise
 * @returns a Q promise
 */
function coerce(promise) {
    var deferred = defer();
    Q.nextTick(function () {
        try {
            promise.then(deferred.resolve, deferred.reject, deferred.notify);
        } catch (exception) {
            deferred.reject(exception);
        }
    });
    return deferred.promise;
}

/**
 * Annotates an object such that it will never be
 * transferred away from this process over any promise
 * communication channel.
 * @param object
 * @returns promise a wrapping of that object that
 * additionally responds to the "isDef" message
 * without a rejection.
 */
Q.master = master;
function master(object) {
    return Promise({
        "isDef": function () {}
    }, function fallback(op, args) {
        return dispatch(object, op, args);
    }, function () {
        return Q(object).inspect();
    });
}

/**
 * Spreads the values of a promised array of arguments into the
 * fulfillment callback.
 * @param fulfilled callback that receives variadic arguments from the
 * promised array
 * @param rejected callback that receives the exception if the promise
 * is rejected.
 * @returns a promise for the return value or thrown exception of
 * either callback.
 */
Q.spread = spread;
function spread(value, fulfilled, rejected) {
    return Q(value).spread(fulfilled, rejected);
}

Promise.prototype.spread = function (fulfilled, rejected) {
    return this.all().then(function (array) {
        return fulfilled.apply(void 0, array);
    }, rejected);
};

/**
 * The async function is a decorator for generator functions, turning
 * them into asynchronous generators.  Although generators are only part
 * of the newest ECMAScript 6 drafts, this code does not cause syntax
 * errors in older engines.  This code should continue to work and will
 * in fact improve over time as the language improves.
 *
 * ES6 generators are currently part of V8 version 3.19 with the
 * --harmony-generators runtime flag enabled.  SpiderMonkey has had them
 * for longer, but under an older Python-inspired form.  This function
 * works on both kinds of generators.
 *
 * Decorates a generator function such that:
 *  - it may yield promises
 *  - execution will continue when that promise is fulfilled
 *  - the value of the yield expression will be the fulfilled value
 *  - it returns a promise for the return value (when the generator
 *    stops iterating)
 *  - the decorated function returns a promise for the return value
 *    of the generator or the first rejected promise among those
 *    yielded.
 *  - if an error is thrown in the generator, it propagates through
 *    every following yield until it is caught, or until it escapes
 *    the generator function altogether, and is translated into a
 *    rejection for the promise returned by the decorated generator.
 */
Q.async = async;
function async(makeGenerator) {
    return function () {
        // when verb is "send", arg is a value
        // when verb is "throw", arg is an exception
        function continuer(verb, arg) {
            var result;

            // Until V8 3.19 / Chromium 29 is released, SpiderMonkey is the only
            // engine that has a deployed base of browsers that support generators.
            // However, SM's generators use the Python-inspired semantics of
            // outdated ES6 drafts.  We would like to support ES6, but we'd also
            // like to make it possible to use generators in deployed browsers, so
            // we also support Python-style generators.  At some point we can remove
            // this block.

            if (typeof StopIteration === "undefined") {
                // ES6 Generators
                try {
                    result = generator[verb](arg);
                } catch (exception) {
                    return reject(exception);
                }
                if (result.done) {
                    return Q(result.value);
                } else {
                    return when(result.value, callback, errback);
                }
            } else {
                // SpiderMonkey Generators
                // FIXME: Remove this case when SM does ES6 generators.
                try {
                    result = generator[verb](arg);
                } catch (exception) {
                    if (isStopIteration(exception)) {
                        return Q(exception.value);
                    } else {
                        return reject(exception);
                    }
                }
                return when(result, callback, errback);
            }
        }
        var generator = makeGenerator.apply(this, arguments);
        var callback = continuer.bind(continuer, "next");
        var errback = continuer.bind(continuer, "throw");
        return callback();
    };
}

/**
 * The spawn function is a small wrapper around async that immediately
 * calls the generator and also ends the promise chain, so that any
 * unhandled errors are thrown instead of forwarded to the error
 * handler. This is useful because it's extremely common to run
 * generators at the top-level to work with libraries.
 */
Q.spawn = spawn;
function spawn(makeGenerator) {
    Q.done(Q.async(makeGenerator)());
}

// FIXME: Remove this interface once ES6 generators are in SpiderMonkey.
/**
 * Throws a ReturnValue exception to stop an asynchronous generator.
 *
 * This interface is a stop-gap measure to support generator return
 * values in older Firefox/SpiderMonkey.  In browsers that support ES6
 * generators like Chromium 29, just use "return" in your generator
 * functions.
 *
 * @param value the return value for the surrounding generator
 * @throws ReturnValue exception with the value.
 * @example
 * // ES6 style
 * Q.async(function* () {
 *      var foo = yield getFooPromise();
 *      var bar = yield getBarPromise();
 *      return foo + bar;
 * })
 * // Older SpiderMonkey style
 * Q.async(function () {
 *      var foo = yield getFooPromise();
 *      var bar = yield getBarPromise();
 *      Q.return(foo + bar);
 * })
 */
Q["return"] = _return;
function _return(value) {
    throw new QReturnValue(value);
}

/**
 * The promised function decorator ensures that any promise arguments
 * are settled and passed as values (`this` is also settled and passed
 * as a value).  It will also ensure that the result of a function is
 * always a promise.
 *
 * @example
 * var add = Q.promised(function (a, b) {
 *     return a + b;
 * });
 * add(Q(a), Q(B));
 *
 * @param {function} callback The function to decorate
 * @returns {function} a function that has been decorated.
 */
Q.promised = promised;
function promised(callback) {
    return function () {
        return spread([this, all(arguments)], function (self, args) {
            return callback.apply(self, args);
        });
    };
}

/**
 * sends a message to a value in a future turn
 * @param object* the recipient
 * @param op the name of the message operation, e.g., "when",
 * @param args further arguments to be forwarded to the operation
 * @returns result {Promise} a promise for the result of the operation
 */
Q.dispatch = dispatch;
function dispatch(object, op, args) {
    return Q(object).dispatch(op, args);
}

Promise.prototype.dispatch = function (op, args) {
    var self = this;
    var deferred = defer();
    Q.nextTick(function () {
        self.promiseDispatch(deferred.resolve, op, args);
    });
    return deferred.promise;
};

/**
 * Gets the value of a property in a future turn.
 * @param object    promise or immediate reference for target object
 * @param name      name of property to get
 * @return promise for the property value
 */
Q.get = function (object, key) {
    return Q(object).dispatch("get", [key]);
};

Promise.prototype.get = function (key) {
    return this.dispatch("get", [key]);
};

/**
 * Sets the value of a property in a future turn.
 * @param object    promise or immediate reference for object object
 * @param name      name of property to set
 * @param value     new value of property
 * @return promise for the return value
 */
Q.set = function (object, key, value) {
    return Q(object).dispatch("set", [key, value]);
};

Promise.prototype.set = function (key, value) {
    return this.dispatch("set", [key, value]);
};

/**
 * Deletes a property in a future turn.
 * @param object    promise or immediate reference for target object
 * @param name      name of property to delete
 * @return promise for the return value
 */
Q.del = // XXX legacy
Q["delete"] = function (object, key) {
    return Q(object).dispatch("delete", [key]);
};

Promise.prototype.del = // XXX legacy
Promise.prototype["delete"] = function (key) {
    return this.dispatch("delete", [key]);
};

/**
 * Invokes a method in a future turn.
 * @param object    promise or immediate reference for target object
 * @param name      name of method to invoke
 * @param value     a value to post, typically an array of
 *                  invocation arguments for promises that
 *                  are ultimately backed with `resolve` values,
 *                  as opposed to those backed with URLs
 *                  wherein the posted value can be any
 *                  JSON serializable object.
 * @return promise for the return value
 */
// bound locally because it is used by other methods
Q.mapply = // XXX As proposed by "Redsandro"
Q.post = function (object, name, args) {
    return Q(object).dispatch("post", [name, args]);
};

Promise.prototype.mapply = // XXX As proposed by "Redsandro"
Promise.prototype.post = function (name, args) {
    return this.dispatch("post", [name, args]);
};

/**
 * Invokes a method in a future turn.
 * @param object    promise or immediate reference for target object
 * @param name      name of method to invoke
 * @param ...args   array of invocation arguments
 * @return promise for the return value
 */
Q.send = // XXX Mark Miller's proposed parlance
Q.mcall = // XXX As proposed by "Redsandro"
Q.invoke = function (object, name /*...args*/) {
    return Q(object).dispatch("post", [name, array_slice(arguments, 2)]);
};

Promise.prototype.send = // XXX Mark Miller's proposed parlance
Promise.prototype.mcall = // XXX As proposed by "Redsandro"
Promise.prototype.invoke = function (name /*...args*/) {
    return this.dispatch("post", [name, array_slice(arguments, 1)]);
};

/**
 * Applies the promised function in a future turn.
 * @param object    promise or immediate reference for target function
 * @param args      array of application arguments
 */
Q.fapply = function (object, args) {
    return Q(object).dispatch("apply", [void 0, args]);
};

Promise.prototype.fapply = function (args) {
    return this.dispatch("apply", [void 0, args]);
};

/**
 * Calls the promised function in a future turn.
 * @param object    promise or immediate reference for target function
 * @param ...args   array of application arguments
 */
Q["try"] =
Q.fcall = function (object /* ...args*/) {
    return Q(object).dispatch("apply", [void 0, array_slice(arguments, 1)]);
};

Promise.prototype.fcall = function (/*...args*/) {
    return this.dispatch("apply", [void 0, array_slice(arguments)]);
};

/**
 * Binds the promised function, transforming return values into a fulfilled
 * promise and thrown errors into a rejected one.
 * @param object    promise or immediate reference for target function
 * @param ...args   array of application arguments
 */
Q.fbind = function (object /*...args*/) {
    var promise = Q(object);
    var args = array_slice(arguments, 1);
    return function fbound() {
        return promise.dispatch("apply", [
            this,
            args.concat(array_slice(arguments))
        ]);
    };
};
Promise.prototype.fbind = function (/*...args*/) {
    var promise = this;
    var args = array_slice(arguments);
    return function fbound() {
        return promise.dispatch("apply", [
            this,
            args.concat(array_slice(arguments))
        ]);
    };
};

/**
 * Requests the names of the owned properties of a promised
 * object in a future turn.
 * @param object    promise or immediate reference for target object
 * @return promise for the keys of the eventually settled object
 */
Q.keys = function (object) {
    return Q(object).dispatch("keys", []);
};

Promise.prototype.keys = function () {
    return this.dispatch("keys", []);
};

/**
 * Turns an array of promises into a promise for an array.  If any of
 * the promises gets rejected, the whole array is rejected immediately.
 * @param {Array*} an array (or promise for an array) of values (or
 * promises for values)
 * @returns a promise for an array of the corresponding values
 */
// By Mark Miller
// http://wiki.ecmascript.org/doku.php?id=strawman:concurrency&rev=1308776521#allfulfilled
Q.all = all;
function all(promises) {
    return when(promises, function (promises) {
        var pendingCount = 0;
        var deferred = defer();
        array_reduce(promises, function (undefined, promise, index) {
            var snapshot;
            if (
                isPromise(promise) &&
                (snapshot = promise.inspect()).state === "fulfilled"
            ) {
                promises[index] = snapshot.value;
            } else {
                ++pendingCount;
                when(
                    promise,
                    function (value) {
                        promises[index] = value;
                        if (--pendingCount === 0) {
                            deferred.resolve(promises);
                        }
                    },
                    deferred.reject,
                    function (progress) {
                        deferred.notify({ index: index, value: progress });
                    }
                );
            }
        }, void 0);
        if (pendingCount === 0) {
            deferred.resolve(promises);
        }
        return deferred.promise;
    });
}

Promise.prototype.all = function () {
    return all(this);
};

/**
 * Returns the first resolved promise of an array. Prior rejected promises are
 * ignored.  Rejects only if all promises are rejected.
 * @param {Array*} an array containing values or promises for values
 * @returns a promise fulfilled with the value of the first resolved promise,
 * or a rejected promise if all promises are rejected.
 */
Q.any = any;

function any(promises) {
    if (promises.length === 0) {
        return Q.resolve();
    }

    var deferred = Q.defer();
    var pendingCount = 0;
    array_reduce(promises, function (prev, current, index) {
        var promise = promises[index];

        pendingCount++;

        when(promise, onFulfilled, onRejected, onProgress);
        function onFulfilled(result) {
            deferred.resolve(result);
        }
        function onRejected(err) {
            pendingCount--;
            if (pendingCount === 0) {
                err.message = ("Q can't get fulfillment value from any promise, all " +
                    "promises were rejected. Last error message: " + err.message);
                deferred.reject(err);
            }
        }
        function onProgress(progress) {
            deferred.notify({
                index: index,
                value: progress
            });
        }
    }, undefined);

    return deferred.promise;
}

Promise.prototype.any = function () {
    return any(this);
};

/**
 * Waits for all promises to be settled, either fulfilled or
 * rejected.  This is distinct from `all` since that would stop
 * waiting at the first rejection.  The promise returned by
 * `allResolved` will never be rejected.
 * @param promises a promise for an array (or an array) of promises
 * (or values)
 * @return a promise for an array of promises
 */
Q.allResolved = deprecate(allResolved, "allResolved", "allSettled");
function allResolved(promises) {
    return when(promises, function (promises) {
        promises = array_map(promises, Q);
        return when(all(array_map(promises, function (promise) {
            return when(promise, noop, noop);
        })), function () {
            return promises;
        });
    });
}

Promise.prototype.allResolved = function () {
    return allResolved(this);
};

/**
 * @see Promise#allSettled
 */
Q.allSettled = allSettled;
function allSettled(promises) {
    return Q(promises).allSettled();
}

/**
 * Turns an array of promises into a promise for an array of their states (as
 * returned by `inspect`) when they have all settled.
 * @param {Array[Any*]} values an array (or promise for an array) of values (or
 * promises for values)
 * @returns {Array[State]} an array of states for the respective values.
 */
Promise.prototype.allSettled = function () {
    return this.then(function (promises) {
        return all(array_map(promises, function (promise) {
            promise = Q(promise);
            function regardless() {
                return promise.inspect();
            }
            return promise.then(regardless, regardless);
        }));
    });
};

/**
 * Captures the failure of a promise, giving an oportunity to recover
 * with a callback.  If the given promise is fulfilled, the returned
 * promise is fulfilled.
 * @param {Any*} promise for something
 * @param {Function} callback to fulfill the returned promise if the
 * given promise is rejected
 * @returns a promise for the return value of the callback
 */
Q.fail = // XXX legacy
Q["catch"] = function (object, rejected) {
    return Q(object).then(void 0, rejected);
};

Promise.prototype.fail = // XXX legacy
Promise.prototype["catch"] = function (rejected) {
    return this.then(void 0, rejected);
};

/**
 * Attaches a listener that can respond to progress notifications from a
 * promise's originating deferred. This listener receives the exact arguments
 * passed to ``deferred.notify``.
 * @param {Any*} promise for something
 * @param {Function} callback to receive any progress notifications
 * @returns the given promise, unchanged
 */
Q.progress = progress;
function progress(object, progressed) {
    return Q(object).then(void 0, void 0, progressed);
}

Promise.prototype.progress = function (progressed) {
    return this.then(void 0, void 0, progressed);
};

/**
 * Provides an opportunity to observe the settling of a promise,
 * regardless of whether the promise is fulfilled or rejected.  Forwards
 * the resolution to the returned promise when the callback is done.
 * The callback can return a promise to defer completion.
 * @param {Any*} promise
 * @param {Function} callback to observe the resolution of the given
 * promise, takes no arguments.
 * @returns a promise for the resolution of the given promise when
 * ``fin`` is done.
 */
Q.fin = // XXX legacy
Q["finally"] = function (object, callback) {
    return Q(object)["finally"](callback);
};

Promise.prototype.fin = // XXX legacy
Promise.prototype["finally"] = function (callback) {
    if (!callback || typeof callback.apply !== "function") {
        throw new Error("Q can't apply finally callback");
    }
    callback = Q(callback);
    return this.then(function (value) {
        return callback.fcall().then(function () {
            return value;
        });
    }, function (reason) {
        // TODO attempt to recycle the rejection with "this".
        return callback.fcall().then(function () {
            throw reason;
        });
    });
};

/**
 * Terminates a chain of promises, forcing rejections to be
 * thrown as exceptions.
 * @param {Any*} promise at the end of a chain of promises
 * @returns nothing
 */
Q.done = function (object, fulfilled, rejected, progress) {
    return Q(object).done(fulfilled, rejected, progress);
};

Promise.prototype.done = function (fulfilled, rejected, progress) {
    var onUnhandledError = function (error) {
        // forward to a future turn so that ``when``
        // does not catch it and turn it into a rejection.
        Q.nextTick(function () {
            makeStackTraceLong(error, promise);
            if (Q.onerror) {
                Q.onerror(error);
            } else {
                throw error;
            }
        });
    };

    // Avoid unnecessary `nextTick`ing via an unnecessary `when`.
    var promise = fulfilled || rejected || progress ?
        this.then(fulfilled, rejected, progress) :
        this;

    if (typeof process === "object" && process && process.domain) {
        onUnhandledError = process.domain.bind(onUnhandledError);
    }

    promise.then(void 0, onUnhandledError);
};

/**
 * Causes a promise to be rejected if it does not get fulfilled before
 * some milliseconds time out.
 * @param {Any*} promise
 * @param {Number} milliseconds timeout
 * @param {Any*} custom error message or Error object (optional)
 * @returns a promise for the resolution of the given promise if it is
 * fulfilled before the timeout, otherwise rejected.
 */
Q.timeout = function (object, ms, error) {
    return Q(object).timeout(ms, error);
};

Promise.prototype.timeout = function (ms, error) {
    var deferred = defer();
    var timeoutId = setTimeout(function () {
        if (!error || "string" === typeof error) {
            error = new Error(error || "Timed out after " + ms + " ms");
            error.code = "ETIMEDOUT";
        }
        deferred.reject(error);
    }, ms);

    this.then(function (value) {
        clearTimeout(timeoutId);
        deferred.resolve(value);
    }, function (exception) {
        clearTimeout(timeoutId);
        deferred.reject(exception);
    }, deferred.notify);

    return deferred.promise;
};

/**
 * Returns a promise for the given value (or promised value), some
 * milliseconds after it resolved. Passes rejections immediately.
 * @param {Any*} promise
 * @param {Number} milliseconds
 * @returns a promise for the resolution of the given promise after milliseconds
 * time has elapsed since the resolution of the given promise.
 * If the given promise rejects, that is passed immediately.
 */
Q.delay = function (object, timeout) {
    if (timeout === void 0) {
        timeout = object;
        object = void 0;
    }
    return Q(object).delay(timeout);
};

Promise.prototype.delay = function (timeout) {
    return this.then(function (value) {
        var deferred = defer();
        setTimeout(function () {
            deferred.resolve(value);
        }, timeout);
        return deferred.promise;
    });
};

/**
 * Passes a continuation to a Node function, which is called with the given
 * arguments provided as an array, and returns a promise.
 *
 *      Q.nfapply(FS.readFile, [__filename])
 *      .then(function (content) {
 *      })
 *
 */
Q.nfapply = function (callback, args) {
    return Q(callback).nfapply(args);
};

Promise.prototype.nfapply = function (args) {
    var deferred = defer();
    var nodeArgs = array_slice(args);
    nodeArgs.push(deferred.makeNodeResolver());
    this.fapply(nodeArgs).fail(deferred.reject);
    return deferred.promise;
};

/**
 * Passes a continuation to a Node function, which is called with the given
 * arguments provided individually, and returns a promise.
 * @example
 * Q.nfcall(FS.readFile, __filename)
 * .then(function (content) {
 * })
 *
 */
Q.nfcall = function (callback /*...args*/) {
    var args = array_slice(arguments, 1);
    return Q(callback).nfapply(args);
};

Promise.prototype.nfcall = function (/*...args*/) {
    var nodeArgs = array_slice(arguments);
    var deferred = defer();
    nodeArgs.push(deferred.makeNodeResolver());
    this.fapply(nodeArgs).fail(deferred.reject);
    return deferred.promise;
};

/**
 * Wraps a NodeJS continuation passing function and returns an equivalent
 * version that returns a promise.
 * @example
 * Q.nfbind(FS.readFile, __filename)("utf-8")
 * .then(console.log)
 * .done()
 */
Q.nfbind =
Q.denodeify = function (callback /*...args*/) {
    if (callback === undefined) {
        throw new Error("Q can't wrap an undefined function");
    }
    var baseArgs = array_slice(arguments, 1);
    return function () {
        var nodeArgs = baseArgs.concat(array_slice(arguments));
        var deferred = defer();
        nodeArgs.push(deferred.makeNodeResolver());
        Q(callback).fapply(nodeArgs).fail(deferred.reject);
        return deferred.promise;
    };
};

Promise.prototype.nfbind =
Promise.prototype.denodeify = function (/*...args*/) {
    var args = array_slice(arguments);
    args.unshift(this);
    return Q.denodeify.apply(void 0, args);
};

Q.nbind = function (callback, thisp /*...args*/) {
    var baseArgs = array_slice(arguments, 2);
    return function () {
        var nodeArgs = baseArgs.concat(array_slice(arguments));
        var deferred = defer();
        nodeArgs.push(deferred.makeNodeResolver());
        function bound() {
            return callback.apply(thisp, arguments);
        }
        Q(bound).fapply(nodeArgs).fail(deferred.reject);
        return deferred.promise;
    };
};

Promise.prototype.nbind = function (/*thisp, ...args*/) {
    var args = array_slice(arguments, 0);
    args.unshift(this);
    return Q.nbind.apply(void 0, args);
};

/**
 * Calls a method of a Node-style object that accepts a Node-style
 * callback with a given array of arguments, plus a provided callback.
 * @param object an object that has the named method
 * @param {String} name name of the method of object
 * @param {Array} args arguments to pass to the method; the callback
 * will be provided by Q and appended to these arguments.
 * @returns a promise for the value or error
 */
Q.nmapply = // XXX As proposed by "Redsandro"
Q.npost = function (object, name, args) {
    return Q(object).npost(name, args);
};

Promise.prototype.nmapply = // XXX As proposed by "Redsandro"
Promise.prototype.npost = function (name, args) {
    var nodeArgs = array_slice(args || []);
    var deferred = defer();
    nodeArgs.push(deferred.makeNodeResolver());
    this.dispatch("post", [name, nodeArgs]).fail(deferred.reject);
    return deferred.promise;
};

/**
 * Calls a method of a Node-style object that accepts a Node-style
 * callback, forwarding the given variadic arguments, plus a provided
 * callback argument.
 * @param object an object that has the named method
 * @param {String} name name of the method of object
 * @param ...args arguments to pass to the method; the callback will
 * be provided by Q and appended to these arguments.
 * @returns a promise for the value or error
 */
Q.nsend = // XXX Based on Mark Miller's proposed "send"
Q.nmcall = // XXX Based on "Redsandro's" proposal
Q.ninvoke = function (object, name /*...args*/) {
    var nodeArgs = array_slice(arguments, 2);
    var deferred = defer();
    nodeArgs.push(deferred.makeNodeResolver());
    Q(object).dispatch("post", [name, nodeArgs]).fail(deferred.reject);
    return deferred.promise;
};

Promise.prototype.nsend = // XXX Based on Mark Miller's proposed "send"
Promise.prototype.nmcall = // XXX Based on "Redsandro's" proposal
Promise.prototype.ninvoke = function (name /*...args*/) {
    var nodeArgs = array_slice(arguments, 1);
    var deferred = defer();
    nodeArgs.push(deferred.makeNodeResolver());
    this.dispatch("post", [name, nodeArgs]).fail(deferred.reject);
    return deferred.promise;
};

/**
 * If a function would like to support both Node continuation-passing-style and
 * promise-returning-style, it can end its internal promise chain with
 * `nodeify(nodeback)`, forwarding the optional nodeback argument.  If the user
 * elects to use a nodeback, the result will be sent there.  If they do not
 * pass a nodeback, they will receive the result promise.
 * @param object a result (or a promise for a result)
 * @param {Function} nodeback a Node.js-style callback
 * @returns either the promise or nothing
 */
Q.nodeify = nodeify;
function nodeify(object, nodeback) {
    return Q(object).nodeify(nodeback);
}

Promise.prototype.nodeify = function (nodeback) {
    if (nodeback) {
        this.then(function (value) {
            Q.nextTick(function () {
                nodeback(null, value);
            });
        }, function (error) {
            Q.nextTick(function () {
                nodeback(error);
            });
        });
    } else {
        return this;
    }
};

Q.noConflict = function() {
    throw new Error("Q.noConflict only works when Q is used as a global");
};

// All code before this point will be filtered from stack traces.
var qEndingLine = captureLine();

return Q;

});

TorrentStream.Q = Q.noConflict();
/*! jQuery UI - v1.12.0 - 2016-08-16
* http://jqueryui.com
* Includes: widget.js, data.js, scroll-parent.js, widgets/sortable.js, widgets/mouse.js
* Copyright jQuery Foundation and other contributors; Licensed MIT */

(function(t){"function"==typeof define&&define.amd?define(["jquery"],t):t(TorrentStream.jQuery)})(function(t){t.ui=t.ui||{},t.ui.version="1.12.0";var e=0,i=Array.prototype.slice;t.cleanData=function(e){return function(i){var s,n,o;for(o=0;null!=(n=i[o]);o++)try{s=t._data(n,"events"),s&&s.remove&&t(n).triggerHandler("remove")}catch(a){}e(i)}}(t.cleanData),t.widget=function(e,i,s){var n,o,a,r={},l=e.split(".")[0];e=e.split(".")[1];var h=l+"-"+e;return s||(s=i,i=t.Widget),t.isArray(s)&&(s=t.extend.apply(null,[{}].concat(s))),t.expr[":"][h.toLowerCase()]=function(e){return!!t.data(e,h)},t[l]=t[l]||{},n=t[l][e],o=t[l][e]=function(t,e){return this._createWidget?(arguments.length&&this._createWidget(t,e),void 0):new o(t,e)},t.extend(o,n,{version:s.version,_proto:t.extend({},s),_childConstructors:[]}),a=new i,a.options=t.widget.extend({},a.options),t.each(s,function(e,s){return t.isFunction(s)?(r[e]=function(){function t(){return i.prototype[e].apply(this,arguments)}function n(t){return i.prototype[e].apply(this,t)}return function(){var e,i=this._super,o=this._superApply;return this._super=t,this._superApply=n,e=s.apply(this,arguments),this._super=i,this._superApply=o,e}}(),void 0):(r[e]=s,void 0)}),o.prototype=t.widget.extend(a,{widgetEventPrefix:n?a.widgetEventPrefix||e:e},r,{constructor:o,namespace:l,widgetName:e,widgetFullName:h}),n?(t.each(n._childConstructors,function(e,i){var s=i.prototype;t.widget(s.namespace+"."+s.widgetName,o,i._proto)}),delete n._childConstructors):i._childConstructors.push(o),t.widget.bridge(e,o),o},t.widget.extend=function(e){for(var s,n,o=i.call(arguments,1),a=0,r=o.length;r>a;a++)for(s in o[a])n=o[a][s],o[a].hasOwnProperty(s)&&void 0!==n&&(e[s]=t.isPlainObject(n)?t.isPlainObject(e[s])?t.widget.extend({},e[s],n):t.widget.extend({},n):n);return e},t.widget.bridge=function(e,s){var n=s.prototype.widgetFullName||e;t.fn[e]=function(o){var a="string"==typeof o,r=i.call(arguments,1),l=this;return a?this.each(function(){var i,s=t.data(this,n);return"instance"===o?(l=s,!1):s?t.isFunction(s[o])&&"_"!==o.charAt(0)?(i=s[o].apply(s,r),i!==s&&void 0!==i?(l=i&&i.jquery?l.pushStack(i.get()):i,!1):void 0):t.error("no such method '"+o+"' for "+e+" widget instance"):t.error("cannot call methods on "+e+" prior to initialization; "+"attempted to call method '"+o+"'")}):(r.length&&(o=t.widget.extend.apply(null,[o].concat(r))),this.each(function(){var e=t.data(this,n);e?(e.option(o||{}),e._init&&e._init()):t.data(this,n,new s(o,this))})),l}},t.Widget=function(){},t.Widget._childConstructors=[],t.Widget.prototype={widgetName:"widget",widgetEventPrefix:"",defaultElement:"<div>",options:{classes:{},disabled:!1,create:null},_createWidget:function(i,s){s=t(s||this.defaultElement||this)[0],this.element=t(s),this.uuid=e++,this.eventNamespace="."+this.widgetName+this.uuid,this.bindings=t(),this.hoverable=t(),this.focusable=t(),this.classesElementLookup={},s!==this&&(t.data(s,this.widgetFullName,this),this._on(!0,this.element,{remove:function(t){t.target===s&&this.destroy()}}),this.document=t(s.style?s.ownerDocument:s.document||s),this.window=t(this.document[0].defaultView||this.document[0].parentWindow)),this.options=t.widget.extend({},this.options,this._getCreateOptions(),i),this._create(),this.options.disabled&&this._setOptionDisabled(this.options.disabled),this._trigger("create",null,this._getCreateEventData()),this._init()},_getCreateOptions:function(){return{}},_getCreateEventData:t.noop,_create:t.noop,_init:t.noop,destroy:function(){var e=this;this._destroy(),t.each(this.classesElementLookup,function(t,i){e._removeClass(i,t)}),this.element.off(this.eventNamespace).removeData(this.widgetFullName),this.widget().off(this.eventNamespace).removeAttr("aria-disabled"),this.bindings.off(this.eventNamespace)},_destroy:t.noop,widget:function(){return this.element},option:function(e,i){var s,n,o,a=e;if(0===arguments.length)return t.widget.extend({},this.options);if("string"==typeof e)if(a={},s=e.split("."),e=s.shift(),s.length){for(n=a[e]=t.widget.extend({},this.options[e]),o=0;s.length-1>o;o++)n[s[o]]=n[s[o]]||{},n=n[s[o]];if(e=s.pop(),1===arguments.length)return void 0===n[e]?null:n[e];n[e]=i}else{if(1===arguments.length)return void 0===this.options[e]?null:this.options[e];a[e]=i}return this._setOptions(a),this},_setOptions:function(t){var e;for(e in t)this._setOption(e,t[e]);return this},_setOption:function(t,e){return"classes"===t&&this._setOptionClasses(e),this.options[t]=e,"disabled"===t&&this._setOptionDisabled(e),this},_setOptionClasses:function(e){var i,s,n;for(i in e)n=this.classesElementLookup[i],e[i]!==this.options.classes[i]&&n&&n.length&&(s=t(n.get()),this._removeClass(n,i),s.addClass(this._classes({element:s,keys:i,classes:e,add:!0})))},_setOptionDisabled:function(t){this._toggleClass(this.widget(),this.widgetFullName+"-disabled",null,!!t),t&&(this._removeClass(this.hoverable,null,"ui-state-hover"),this._removeClass(this.focusable,null,"ui-state-focus"))},enable:function(){return this._setOptions({disabled:!1})},disable:function(){return this._setOptions({disabled:!0})},_classes:function(e){function i(i,o){var a,r;for(r=0;i.length>r;r++)a=n.classesElementLookup[i[r]]||t(),a=e.add?t(t.unique(a.get().concat(e.element.get()))):t(a.not(e.element).get()),n.classesElementLookup[i[r]]=a,s.push(i[r]),o&&e.classes[i[r]]&&s.push(e.classes[i[r]])}var s=[],n=this;return e=t.extend({element:this.element,classes:this.options.classes||{}},e),e.keys&&i(e.keys.match(/\S+/g)||[],!0),e.extra&&i(e.extra.match(/\S+/g)||[]),s.join(" ")},_removeClass:function(t,e,i){return this._toggleClass(t,e,i,!1)},_addClass:function(t,e,i){return this._toggleClass(t,e,i,!0)},_toggleClass:function(t,e,i,s){s="boolean"==typeof s?s:i;var n="string"==typeof t||null===t,o={extra:n?e:i,keys:n?t:e,element:n?this.element:t,add:s};return o.element.toggleClass(this._classes(o),s),this},_on:function(e,i,s){var n,o=this;"boolean"!=typeof e&&(s=i,i=e,e=!1),s?(i=n=t(i),this.bindings=this.bindings.add(i)):(s=i,i=this.element,n=this.widget()),t.each(s,function(s,a){function r(){return e||o.options.disabled!==!0&&!t(this).hasClass("ui-state-disabled")?("string"==typeof a?o[a]:a).apply(o,arguments):void 0}"string"!=typeof a&&(r.guid=a.guid=a.guid||r.guid||t.guid++);var l=s.match(/^([\w:-]*)\s*(.*)$/),h=l[1]+o.eventNamespace,c=l[2];c?n.on(h,c,r):i.on(h,r)})},_off:function(e,i){i=(i||"").split(" ").join(this.eventNamespace+" ")+this.eventNamespace,e.off(i).off(i),this.bindings=t(this.bindings.not(e).get()),this.focusable=t(this.focusable.not(e).get()),this.hoverable=t(this.hoverable.not(e).get())},_delay:function(t,e){function i(){return("string"==typeof t?s[t]:t).apply(s,arguments)}var s=this;return setTimeout(i,e||0)},_hoverable:function(e){this.hoverable=this.hoverable.add(e),this._on(e,{mouseenter:function(e){this._addClass(t(e.currentTarget),null,"ui-state-hover")},mouseleave:function(e){this._removeClass(t(e.currentTarget),null,"ui-state-hover")}})},_focusable:function(e){this.focusable=this.focusable.add(e),this._on(e,{focusin:function(e){this._addClass(t(e.currentTarget),null,"ui-state-focus")},focusout:function(e){this._removeClass(t(e.currentTarget),null,"ui-state-focus")}})},_trigger:function(e,i,s){var n,o,a=this.options[e];if(s=s||{},i=t.Event(i),i.type=(e===this.widgetEventPrefix?e:this.widgetEventPrefix+e).toLowerCase(),i.target=this.element[0],o=i.originalEvent)for(n in o)n in i||(i[n]=o[n]);return this.element.trigger(i,s),!(t.isFunction(a)&&a.apply(this.element[0],[i].concat(s))===!1||i.isDefaultPrevented())}},t.each({show:"fadeIn",hide:"fadeOut"},function(e,i){t.Widget.prototype["_"+e]=function(s,n,o){"string"==typeof n&&(n={effect:n});var a,r=n?n===!0||"number"==typeof n?i:n.effect||i:e;n=n||{},"number"==typeof n&&(n={duration:n}),a=!t.isEmptyObject(n),n.complete=o,n.delay&&s.delay(n.delay),a&&t.effects&&t.effects.effect[r]?s[e](n):r!==e&&s[r]?s[r](n.duration,n.easing,o):s.queue(function(i){t(this)[e](),o&&o.call(s[0]),i()})}}),t.widget,t.extend(t.expr[":"],{data:t.expr.createPseudo?t.expr.createPseudo(function(e){return function(i){return!!t.data(i,e)}}):function(e,i,s){return!!t.data(e,s[3])}}),t.fn.scrollParent=function(e){var i=this.css("position"),s="absolute"===i,n=e?/(auto|scroll|hidden)/:/(auto|scroll)/,o=this.parents().filter(function(){var e=t(this);return s&&"static"===e.css("position")?!1:n.test(e.css("overflow")+e.css("overflow-y")+e.css("overflow-x"))}).eq(0);return"fixed"!==i&&o.length?o:t(this[0].ownerDocument||document)},t.ui.ie=!!/msie [\w.]+/.exec(navigator.userAgent.toLowerCase());var s=!1;t(document).on("mouseup",function(){s=!1}),t.widget("ui.mouse",{version:"1.12.0",options:{cancel:"input, textarea, button, select, option",distance:1,delay:0},_mouseInit:function(){var e=this;this.element.on("mousedown."+this.widgetName,function(t){return e._mouseDown(t)}).on("click."+this.widgetName,function(i){return!0===t.data(i.target,e.widgetName+".preventClickEvent")?(t.removeData(i.target,e.widgetName+".preventClickEvent"),i.stopImmediatePropagation(),!1):void 0}),this.started=!1},_mouseDestroy:function(){this.element.off("."+this.widgetName),this._mouseMoveDelegate&&this.document.off("mousemove."+this.widgetName,this._mouseMoveDelegate).off("mouseup."+this.widgetName,this._mouseUpDelegate)},_mouseDown:function(e){if(!s){this._mouseMoved=!1,this._mouseStarted&&this._mouseUp(e),this._mouseDownEvent=e;var i=this,n=1===e.which,o="string"==typeof this.options.cancel&&e.target.nodeName?t(e.target).closest(this.options.cancel).length:!1;return n&&!o&&this._mouseCapture(e)?(this.mouseDelayMet=!this.options.delay,this.mouseDelayMet||(this._mouseDelayTimer=setTimeout(function(){i.mouseDelayMet=!0},this.options.delay)),this._mouseDistanceMet(e)&&this._mouseDelayMet(e)&&(this._mouseStarted=this._mouseStart(e)!==!1,!this._mouseStarted)?(e.preventDefault(),!0):(!0===t.data(e.target,this.widgetName+".preventClickEvent")&&t.removeData(e.target,this.widgetName+".preventClickEvent"),this._mouseMoveDelegate=function(t){return i._mouseMove(t)},this._mouseUpDelegate=function(t){return i._mouseUp(t)},this.document.on("mousemove."+this.widgetName,this._mouseMoveDelegate).on("mouseup."+this.widgetName,this._mouseUpDelegate),e.preventDefault(),s=!0,!0)):!0}},_mouseMove:function(e){if(this._mouseMoved){if(t.ui.ie&&(!document.documentMode||9>document.documentMode)&&!e.button)return this._mouseUp(e);if(!e.which)if(e.originalEvent.altKey||e.originalEvent.ctrlKey||e.originalEvent.metaKey||e.originalEvent.shiftKey)this.ignoreMissingWhich=!0;else if(!this.ignoreMissingWhich)return this._mouseUp(e)}return(e.which||e.button)&&(this._mouseMoved=!0),this._mouseStarted?(this._mouseDrag(e),e.preventDefault()):(this._mouseDistanceMet(e)&&this._mouseDelayMet(e)&&(this._mouseStarted=this._mouseStart(this._mouseDownEvent,e)!==!1,this._mouseStarted?this._mouseDrag(e):this._mouseUp(e)),!this._mouseStarted)},_mouseUp:function(e){this.document.off("mousemove."+this.widgetName,this._mouseMoveDelegate).off("mouseup."+this.widgetName,this._mouseUpDelegate),this._mouseStarted&&(this._mouseStarted=!1,e.target===this._mouseDownEvent.target&&t.data(e.target,this.widgetName+".preventClickEvent",!0),this._mouseStop(e)),this._mouseDelayTimer&&(clearTimeout(this._mouseDelayTimer),delete this._mouseDelayTimer),this.ignoreMissingWhich=!1,s=!1,e.preventDefault()},_mouseDistanceMet:function(t){return Math.max(Math.abs(this._mouseDownEvent.pageX-t.pageX),Math.abs(this._mouseDownEvent.pageY-t.pageY))>=this.options.distance},_mouseDelayMet:function(){return this.mouseDelayMet},_mouseStart:function(){},_mouseDrag:function(){},_mouseStop:function(){},_mouseCapture:function(){return!0}}),t.widget("ui.sortable",t.ui.mouse,{version:"1.12.0",widgetEventPrefix:"sort",ready:!1,options:{appendTo:"parent",axis:!1,connectWith:!1,containment:!1,cursor:"auto",cursorAt:!1,dropOnEmpty:!0,forcePlaceholderSize:!1,forceHelperSize:!1,grid:!1,handle:!1,helper:"original",items:"> *",opacity:!1,placeholder:!1,revert:!1,scroll:!0,scrollSensitivity:20,scrollSpeed:20,scope:"default",tolerance:"intersect",zIndex:1e3,activate:null,beforeStop:null,change:null,deactivate:null,out:null,over:null,receive:null,remove:null,sort:null,start:null,stop:null,update:null},_isOverAxis:function(t,e,i){return t>=e&&e+i>t},_isFloating:function(t){return/left|right/.test(t.css("float"))||/inline|table-cell/.test(t.css("display"))},_create:function(){this.containerCache={},this._addClass("ui-sortable"),this.refresh(),this.offset=this.element.offset(),this._mouseInit(),this._setHandleClassName(),this.ready=!0},_setOption:function(t,e){this._super(t,e),"handle"===t&&this._setHandleClassName()},_setHandleClassName:function(){var e=this;this._removeClass(this.element.find(".ui-sortable-handle"),"ui-sortable-handle"),t.each(this.items,function(){e._addClass(this.instance.options.handle?this.item.find(this.instance.options.handle):this.item,"ui-sortable-handle")})},_destroy:function(){this._mouseDestroy();for(var t=this.items.length-1;t>=0;t--)this.items[t].item.removeData(this.widgetName+"-item");return this},_mouseCapture:function(e,i){var s=null,n=!1,o=this;return this.reverting?!1:this.options.disabled||"static"===this.options.type?!1:(this._refreshItems(e),t(e.target).parents().each(function(){return t.data(this,o.widgetName+"-item")===o?(s=t(this),!1):void 0}),t.data(e.target,o.widgetName+"-item")===o&&(s=t(e.target)),s?!this.options.handle||i||(t(this.options.handle,s).find("*").addBack().each(function(){this===e.target&&(n=!0)}),n)?(this.currentItem=s,this._removeCurrentsFromItems(),!0):!1:!1)},_mouseStart:function(e,i,s){var n,o,a=this.options;if(this.currentContainer=this,this.refreshPositions(),this.helper=this._createHelper(e),this._cacheHelperProportions(),this._cacheMargins(),this.scrollParent=this.helper.scrollParent(),this.offset=this.currentItem.offset(),this.offset={top:this.offset.top-this.margins.top,left:this.offset.left-this.margins.left},t.extend(this.offset,{click:{left:e.pageX-this.offset.left,top:e.pageY-this.offset.top},parent:this._getParentOffset(),relative:this._getRelativeOffset()}),this.helper.css("position","absolute"),this.cssPosition=this.helper.css("position"),this.originalPosition=this._generatePosition(e),this.originalPageX=e.pageX,this.originalPageY=e.pageY,a.cursorAt&&this._adjustOffsetFromHelper(a.cursorAt),this.domPosition={prev:this.currentItem.prev()[0],parent:this.currentItem.parent()[0]},this.helper[0]!==this.currentItem[0]&&this.currentItem.hide(),this._createPlaceholder(),a.containment&&this._setContainment(),a.cursor&&"auto"!==a.cursor&&(o=this.document.find("body"),this.storedCursor=o.css("cursor"),o.css("cursor",a.cursor),this.storedStylesheet=t("<style>*{ cursor: "+a.cursor+" !important; }</style>").appendTo(o)),a.opacity&&(this.helper.css("opacity")&&(this._storedOpacity=this.helper.css("opacity")),this.helper.css("opacity",a.opacity)),a.zIndex&&(this.helper.css("zIndex")&&(this._storedZIndex=this.helper.css("zIndex")),this.helper.css("zIndex",a.zIndex)),this.scrollParent[0]!==this.document[0]&&"HTML"!==this.scrollParent[0].tagName&&(this.overflowOffset=this.scrollParent.offset()),this._trigger("start",e,this._uiHash()),this._preserveHelperProportions||this._cacheHelperProportions(),!s)for(n=this.containers.length-1;n>=0;n--)this.containers[n]._trigger("activate",e,this._uiHash(this));return t.ui.ddmanager&&(t.ui.ddmanager.current=this),t.ui.ddmanager&&!a.dropBehaviour&&t.ui.ddmanager.prepareOffsets(this,e),this.dragging=!0,this._addClass(this.helper,"ui-sortable-helper"),this._mouseDrag(e),!0},_mouseDrag:function(e){var i,s,n,o,a=this.options,r=!1;for(this.position=this._generatePosition(e),this.positionAbs=this._convertPositionTo("absolute"),this.lastPositionAbs||(this.lastPositionAbs=this.positionAbs),this.options.scroll&&(this.scrollParent[0]!==this.document[0]&&"HTML"!==this.scrollParent[0].tagName?(this.overflowOffset.top+this.scrollParent[0].offsetHeight-e.pageY<a.scrollSensitivity?this.scrollParent[0].scrollTop=r=this.scrollParent[0].scrollTop+a.scrollSpeed:e.pageY-this.overflowOffset.top<a.scrollSensitivity&&(this.scrollParent[0].scrollTop=r=this.scrollParent[0].scrollTop-a.scrollSpeed),this.overflowOffset.left+this.scrollParent[0].offsetWidth-e.pageX<a.scrollSensitivity?this.scrollParent[0].scrollLeft=r=this.scrollParent[0].scrollLeft+a.scrollSpeed:e.pageX-this.overflowOffset.left<a.scrollSensitivity&&(this.scrollParent[0].scrollLeft=r=this.scrollParent[0].scrollLeft-a.scrollSpeed)):(e.pageY-this.document.scrollTop()<a.scrollSensitivity?r=this.document.scrollTop(this.document.scrollTop()-a.scrollSpeed):this.window.height()-(e.pageY-this.document.scrollTop())<a.scrollSensitivity&&(r=this.document.scrollTop(this.document.scrollTop()+a.scrollSpeed)),e.pageX-this.document.scrollLeft()<a.scrollSensitivity?r=this.document.scrollLeft(this.document.scrollLeft()-a.scrollSpeed):this.window.width()-(e.pageX-this.document.scrollLeft())<a.scrollSensitivity&&(r=this.document.scrollLeft(this.document.scrollLeft()+a.scrollSpeed))),r!==!1&&t.ui.ddmanager&&!a.dropBehaviour&&t.ui.ddmanager.prepareOffsets(this,e)),this.positionAbs=this._convertPositionTo("absolute"),this.options.axis&&"y"===this.options.axis||(this.helper[0].style.left=this.position.left+"px"),this.options.axis&&"x"===this.options.axis||(this.helper[0].style.top=this.position.top+"px"),i=this.items.length-1;i>=0;i--)if(s=this.items[i],n=s.item[0],o=this._intersectsWithPointer(s),o&&s.instance===this.currentContainer&&n!==this.currentItem[0]&&this.placeholder[1===o?"next":"prev"]()[0]!==n&&!t.contains(this.placeholder[0],n)&&("semi-dynamic"===this.options.type?!t.contains(this.element[0],n):!0)){if(this.direction=1===o?"down":"up","pointer"!==this.options.tolerance&&!this._intersectsWithSides(s))break;this._rearrange(e,s),this._trigger("change",e,this._uiHash());break}return this._contactContainers(e),t.ui.ddmanager&&t.ui.ddmanager.drag(this,e),this._trigger("sort",e,this._uiHash()),this.lastPositionAbs=this.positionAbs,!1},_mouseStop:function(e,i){if(e){if(t.ui.ddmanager&&!this.options.dropBehaviour&&t.ui.ddmanager.drop(this,e),this.options.revert){var s=this,n=this.placeholder.offset(),o=this.options.axis,a={};o&&"x"!==o||(a.left=n.left-this.offset.parent.left-this.margins.left+(this.offsetParent[0]===this.document[0].body?0:this.offsetParent[0].scrollLeft)),o&&"y"!==o||(a.top=n.top-this.offset.parent.top-this.margins.top+(this.offsetParent[0]===this.document[0].body?0:this.offsetParent[0].scrollTop)),this.reverting=!0,t(this.helper).animate(a,parseInt(this.options.revert,10)||500,function(){s._clear(e)})}else this._clear(e,i);return!1}},cancel:function(){if(this.dragging){this._mouseUp({target:null}),"original"===this.options.helper?(this.currentItem.css(this._storedCSS),this._removeClass(this.currentItem,"ui-sortable-helper")):this.currentItem.show();for(var e=this.containers.length-1;e>=0;e--)this.containers[e]._trigger("deactivate",null,this._uiHash(this)),this.containers[e].containerCache.over&&(this.containers[e]._trigger("out",null,this._uiHash(this)),this.containers[e].containerCache.over=0)}return this.placeholder&&(this.placeholder[0].parentNode&&this.placeholder[0].parentNode.removeChild(this.placeholder[0]),"original"!==this.options.helper&&this.helper&&this.helper[0].parentNode&&this.helper.remove(),t.extend(this,{helper:null,dragging:!1,reverting:!1,_noFinalSort:null}),this.domPosition.prev?t(this.domPosition.prev).after(this.currentItem):t(this.domPosition.parent).prepend(this.currentItem)),this},serialize:function(e){var i=this._getItemsAsjQuery(e&&e.connected),s=[];return e=e||{},t(i).each(function(){var i=(t(e.item||this).attr(e.attribute||"id")||"").match(e.expression||/(.+)[\-=_](.+)/);i&&s.push((e.key||i[1]+"[]")+"="+(e.key&&e.expression?i[1]:i[2]))}),!s.length&&e.key&&s.push(e.key+"="),s.join("&")},toArray:function(e){var i=this._getItemsAsjQuery(e&&e.connected),s=[];return e=e||{},i.each(function(){s.push(t(e.item||this).attr(e.attribute||"id")||"")}),s},_intersectsWith:function(t){var e=this.positionAbs.left,i=e+this.helperProportions.width,s=this.positionAbs.top,n=s+this.helperProportions.height,o=t.left,a=o+t.width,r=t.top,l=r+t.height,h=this.offset.click.top,c=this.offset.click.left,u="x"===this.options.axis||s+h>r&&l>s+h,d="y"===this.options.axis||e+c>o&&a>e+c,p=u&&d;return"pointer"===this.options.tolerance||this.options.forcePointerForContainers||"pointer"!==this.options.tolerance&&this.helperProportions[this.floating?"width":"height"]>t[this.floating?"width":"height"]?p:e+this.helperProportions.width/2>o&&a>i-this.helperProportions.width/2&&s+this.helperProportions.height/2>r&&l>n-this.helperProportions.height/2},_intersectsWithPointer:function(t){var e,i,s="x"===this.options.axis||this._isOverAxis(this.positionAbs.top+this.offset.click.top,t.top,t.height),n="y"===this.options.axis||this._isOverAxis(this.positionAbs.left+this.offset.click.left,t.left,t.width),o=s&&n;return o?(e=this._getDragVerticalDirection(),i=this._getDragHorizontalDirection(),this.floating?"right"===i||"down"===e?2:1:e&&("down"===e?2:1)):!1},_intersectsWithSides:function(t){var e=this._isOverAxis(this.positionAbs.top+this.offset.click.top,t.top+t.height/2,t.height),i=this._isOverAxis(this.positionAbs.left+this.offset.click.left,t.left+t.width/2,t.width),s=this._getDragVerticalDirection(),n=this._getDragHorizontalDirection();return this.floating&&n?"right"===n&&i||"left"===n&&!i:s&&("down"===s&&e||"up"===s&&!e)},_getDragVerticalDirection:function(){var t=this.positionAbs.top-this.lastPositionAbs.top;return 0!==t&&(t>0?"down":"up")},_getDragHorizontalDirection:function(){var t=this.positionAbs.left-this.lastPositionAbs.left;return 0!==t&&(t>0?"right":"left")},refresh:function(t){return this._refreshItems(t),this._setHandleClassName(),this.refreshPositions(),this},_connectWith:function(){var t=this.options;return t.connectWith.constructor===String?[t.connectWith]:t.connectWith},_getItemsAsjQuery:function(e){function i(){r.push(this)}var s,n,o,a,r=[],l=[],h=this._connectWith();if(h&&e)for(s=h.length-1;s>=0;s--)for(o=t(h[s],this.document[0]),n=o.length-1;n>=0;n--)a=t.data(o[n],this.widgetFullName),a&&a!==this&&!a.options.disabled&&l.push([t.isFunction(a.options.items)?a.options.items.call(a.element):t(a.options.items,a.element).not(".ui-sortable-helper").not(".ui-sortable-placeholder"),a]);for(l.push([t.isFunction(this.options.items)?this.options.items.call(this.element,null,{options:this.options,item:this.currentItem}):t(this.options.items,this.element).not(".ui-sortable-helper").not(".ui-sortable-placeholder"),this]),s=l.length-1;s>=0;s--)l[s][0].each(i);return t(r)},_removeCurrentsFromItems:function(){var e=this.currentItem.find(":data("+this.widgetName+"-item)");this.items=t.grep(this.items,function(t){for(var i=0;e.length>i;i++)if(e[i]===t.item[0])return!1;return!0})},_refreshItems:function(e){this.items=[],this.containers=[this];var i,s,n,o,a,r,l,h,c=this.items,u=[[t.isFunction(this.options.items)?this.options.items.call(this.element[0],e,{item:this.currentItem}):t(this.options.items,this.element),this]],d=this._connectWith();if(d&&this.ready)for(i=d.length-1;i>=0;i--)for(n=t(d[i],this.document[0]),s=n.length-1;s>=0;s--)o=t.data(n[s],this.widgetFullName),o&&o!==this&&!o.options.disabled&&(u.push([t.isFunction(o.options.items)?o.options.items.call(o.element[0],e,{item:this.currentItem}):t(o.options.items,o.element),o]),this.containers.push(o));for(i=u.length-1;i>=0;i--)for(a=u[i][1],r=u[i][0],s=0,h=r.length;h>s;s++)l=t(r[s]),l.data(this.widgetName+"-item",a),c.push({item:l,instance:a,width:0,height:0,left:0,top:0})},refreshPositions:function(e){this.floating=this.items.length?"x"===this.options.axis||this._isFloating(this.items[0].item):!1,this.offsetParent&&this.helper&&(this.offset.parent=this._getParentOffset());var i,s,n,o;for(i=this.items.length-1;i>=0;i--)s=this.items[i],s.instance!==this.currentContainer&&this.currentContainer&&s.item[0]!==this.currentItem[0]||(n=this.options.toleranceElement?t(this.options.toleranceElement,s.item):s.item,e||(s.width=n.outerWidth(),s.height=n.outerHeight()),o=n.offset(),s.left=o.left,s.top=o.top);if(this.options.custom&&this.options.custom.refreshContainers)this.options.custom.refreshContainers.call(this);else for(i=this.containers.length-1;i>=0;i--)o=this.containers[i].element.offset(),this.containers[i].containerCache.left=o.left,this.containers[i].containerCache.top=o.top,this.containers[i].containerCache.width=this.containers[i].element.outerWidth(),this.containers[i].containerCache.height=this.containers[i].element.outerHeight();return this},_createPlaceholder:function(e){e=e||this;var i,s=e.options;s.placeholder&&s.placeholder.constructor!==String||(i=s.placeholder,s.placeholder={element:function(){var s=e.currentItem[0].nodeName.toLowerCase(),n=t("<"+s+">",e.document[0]);return e._addClass(n,"ui-sortable-placeholder",i||e.currentItem[0].className)._removeClass(n,"ui-sortable-helper"),"tbody"===s?e._createTrPlaceholder(e.currentItem.find("tr").eq(0),t("<tr>",e.document[0]).appendTo(n)):"tr"===s?e._createTrPlaceholder(e.currentItem,n):"img"===s&&n.attr("src",e.currentItem.attr("src")),i||n.css("visibility","hidden"),n},update:function(t,n){(!i||s.forcePlaceholderSize)&&(n.height()||n.height(e.currentItem.innerHeight()-parseInt(e.currentItem.css("paddingTop")||0,10)-parseInt(e.currentItem.css("paddingBottom")||0,10)),n.width()||n.width(e.currentItem.innerWidth()-parseInt(e.currentItem.css("paddingLeft")||0,10)-parseInt(e.currentItem.css("paddingRight")||0,10)))}}),e.placeholder=t(s.placeholder.element.call(e.element,e.currentItem)),e.currentItem.after(e.placeholder),s.placeholder.update(e,e.placeholder)},_createTrPlaceholder:function(e,i){var s=this;e.children().each(function(){t("<td>&#160;</td>",s.document[0]).attr("colspan",t(this).attr("colspan")||1).appendTo(i)})},_contactContainers:function(e){var i,s,n,o,a,r,l,h,c,u,d=null,p=null;for(i=this.containers.length-1;i>=0;i--)if(!t.contains(this.currentItem[0],this.containers[i].element[0]))if(this._intersectsWith(this.containers[i].containerCache)){if(d&&t.contains(this.containers[i].element[0],d.element[0]))continue;d=this.containers[i],p=i}else this.containers[i].containerCache.over&&(this.containers[i]._trigger("out",e,this._uiHash(this)),this.containers[i].containerCache.over=0);if(d)if(1===this.containers.length)this.containers[p].containerCache.over||(this.containers[p]._trigger("over",e,this._uiHash(this)),this.containers[p].containerCache.over=1);else{for(n=1e4,o=null,c=d.floating||this._isFloating(this.currentItem),a=c?"left":"top",r=c?"width":"height",u=c?"pageX":"pageY",s=this.items.length-1;s>=0;s--)t.contains(this.containers[p].element[0],this.items[s].item[0])&&this.items[s].item[0]!==this.currentItem[0]&&(l=this.items[s].item.offset()[a],h=!1,e[u]-l>this.items[s][r]/2&&(h=!0),n>Math.abs(e[u]-l)&&(n=Math.abs(e[u]-l),o=this.items[s],this.direction=h?"up":"down"));if(!o&&!this.options.dropOnEmpty)return;if(this.currentContainer===this.containers[p])return this.currentContainer.containerCache.over||(this.containers[p]._trigger("over",e,this._uiHash()),this.currentContainer.containerCache.over=1),void 0;o?this._rearrange(e,o,null,!0):this._rearrange(e,null,this.containers[p].element,!0),this._trigger("change",e,this._uiHash()),this.containers[p]._trigger("change",e,this._uiHash(this)),this.currentContainer=this.containers[p],this.options.placeholder.update(this.currentContainer,this.placeholder),this.containers[p]._trigger("over",e,this._uiHash(this)),this.containers[p].containerCache.over=1}},_createHelper:function(e){var i=this.options,s=t.isFunction(i.helper)?t(i.helper.apply(this.element[0],[e,this.currentItem])):"clone"===i.helper?this.currentItem.clone():this.currentItem;return s.parents("body").length||t("parent"!==i.appendTo?i.appendTo:this.currentItem[0].parentNode)[0].appendChild(s[0]),s[0]===this.currentItem[0]&&(this._storedCSS={width:this.currentItem[0].style.width,height:this.currentItem[0].style.height,position:this.currentItem.css("position"),top:this.currentItem.css("top"),left:this.currentItem.css("left")}),(!s[0].style.width||i.forceHelperSize)&&s.width(this.currentItem.width()),(!s[0].style.height||i.forceHelperSize)&&s.height(this.currentItem.height()),s},_adjustOffsetFromHelper:function(e){"string"==typeof e&&(e=e.split(" ")),t.isArray(e)&&(e={left:+e[0],top:+e[1]||0}),"left"in e&&(this.offset.click.left=e.left+this.margins.left),"right"in e&&(this.offset.click.left=this.helperProportions.width-e.right+this.margins.left),"top"in e&&(this.offset.click.top=e.top+this.margins.top),"bottom"in e&&(this.offset.click.top=this.helperProportions.height-e.bottom+this.margins.top)},_getParentOffset:function(){this.offsetParent=this.helper.offsetParent();var e=this.offsetParent.offset();return"absolute"===this.cssPosition&&this.scrollParent[0]!==this.document[0]&&t.contains(this.scrollParent[0],this.offsetParent[0])&&(e.left+=this.scrollParent.scrollLeft(),e.top+=this.scrollParent.scrollTop()),(this.offsetParent[0]===this.document[0].body||this.offsetParent[0].tagName&&"html"===this.offsetParent[0].tagName.toLowerCase()&&t.ui.ie)&&(e={top:0,left:0}),{top:e.top+(parseInt(this.offsetParent.css("borderTopWidth"),10)||0),left:e.left+(parseInt(this.offsetParent.css("borderLeftWidth"),10)||0)}},_getRelativeOffset:function(){if("relative"===this.cssPosition){var t=this.currentItem.position();return{top:t.top-(parseInt(this.helper.css("top"),10)||0)+this.scrollParent.scrollTop(),left:t.left-(parseInt(this.helper.css("left"),10)||0)+this.scrollParent.scrollLeft()}}return{top:0,left:0}},_cacheMargins:function(){this.margins={left:parseInt(this.currentItem.css("marginLeft"),10)||0,top:parseInt(this.currentItem.css("marginTop"),10)||0}},_cacheHelperProportions:function(){this.helperProportions={width:this.helper.outerWidth(),height:this.helper.outerHeight()}},_setContainment:function(){var e,i,s,n=this.options;"parent"===n.containment&&(n.containment=this.helper[0].parentNode),("document"===n.containment||"window"===n.containment)&&(this.containment=[0-this.offset.relative.left-this.offset.parent.left,0-this.offset.relative.top-this.offset.parent.top,"document"===n.containment?this.document.width():this.window.width()-this.helperProportions.width-this.margins.left,("document"===n.containment?this.document.height()||document.body.parentNode.scrollHeight:this.window.height()||this.document[0].body.parentNode.scrollHeight)-this.helperProportions.height-this.margins.top]),/^(document|window|parent)$/.test(n.containment)||(e=t(n.containment)[0],i=t(n.containment).offset(),s="hidden"!==t(e).css("overflow"),this.containment=[i.left+(parseInt(t(e).css("borderLeftWidth"),10)||0)+(parseInt(t(e).css("paddingLeft"),10)||0)-this.margins.left,i.top+(parseInt(t(e).css("borderTopWidth"),10)||0)+(parseInt(t(e).css("paddingTop"),10)||0)-this.margins.top,i.left+(s?Math.max(e.scrollWidth,e.offsetWidth):e.offsetWidth)-(parseInt(t(e).css("borderLeftWidth"),10)||0)-(parseInt(t(e).css("paddingRight"),10)||0)-this.helperProportions.width-this.margins.left,i.top+(s?Math.max(e.scrollHeight,e.offsetHeight):e.offsetHeight)-(parseInt(t(e).css("borderTopWidth"),10)||0)-(parseInt(t(e).css("paddingBottom"),10)||0)-this.helperProportions.height-this.margins.top])},_convertPositionTo:function(e,i){i||(i=this.position);var s="absolute"===e?1:-1,n="absolute"!==this.cssPosition||this.scrollParent[0]!==this.document[0]&&t.contains(this.scrollParent[0],this.offsetParent[0])?this.scrollParent:this.offsetParent,o=/(html|body)/i.test(n[0].tagName);return{top:i.top+this.offset.relative.top*s+this.offset.parent.top*s-("fixed"===this.cssPosition?-this.scrollParent.scrollTop():o?0:n.scrollTop())*s,left:i.left+this.offset.relative.left*s+this.offset.parent.left*s-("fixed"===this.cssPosition?-this.scrollParent.scrollLeft():o?0:n.scrollLeft())*s}},_generatePosition:function(e){var i,s,n=this.options,o=e.pageX,a=e.pageY,r="absolute"!==this.cssPosition||this.scrollParent[0]!==this.document[0]&&t.contains(this.scrollParent[0],this.offsetParent[0])?this.scrollParent:this.offsetParent,l=/(html|body)/i.test(r[0].tagName);
return"relative"!==this.cssPosition||this.scrollParent[0]!==this.document[0]&&this.scrollParent[0]!==this.offsetParent[0]||(this.offset.relative=this._getRelativeOffset()),this.originalPosition&&(this.containment&&(e.pageX-this.offset.click.left<this.containment[0]&&(o=this.containment[0]+this.offset.click.left),e.pageY-this.offset.click.top<this.containment[1]&&(a=this.containment[1]+this.offset.click.top),e.pageX-this.offset.click.left>this.containment[2]&&(o=this.containment[2]+this.offset.click.left),e.pageY-this.offset.click.top>this.containment[3]&&(a=this.containment[3]+this.offset.click.top)),n.grid&&(i=this.originalPageY+Math.round((a-this.originalPageY)/n.grid[1])*n.grid[1],a=this.containment?i-this.offset.click.top>=this.containment[1]&&i-this.offset.click.top<=this.containment[3]?i:i-this.offset.click.top>=this.containment[1]?i-n.grid[1]:i+n.grid[1]:i,s=this.originalPageX+Math.round((o-this.originalPageX)/n.grid[0])*n.grid[0],o=this.containment?s-this.offset.click.left>=this.containment[0]&&s-this.offset.click.left<=this.containment[2]?s:s-this.offset.click.left>=this.containment[0]?s-n.grid[0]:s+n.grid[0]:s)),{top:a-this.offset.click.top-this.offset.relative.top-this.offset.parent.top+("fixed"===this.cssPosition?-this.scrollParent.scrollTop():l?0:r.scrollTop()),left:o-this.offset.click.left-this.offset.relative.left-this.offset.parent.left+("fixed"===this.cssPosition?-this.scrollParent.scrollLeft():l?0:r.scrollLeft())}},_rearrange:function(t,e,i,s){i?i[0].appendChild(this.placeholder[0]):e.item[0].parentNode.insertBefore(this.placeholder[0],"down"===this.direction?e.item[0]:e.item[0].nextSibling),this.counter=this.counter?++this.counter:1;var n=this.counter;this._delay(function(){n===this.counter&&this.refreshPositions(!s)})},_clear:function(t,e){function i(t,e,i){return function(s){i._trigger(t,s,e._uiHash(e))}}this.reverting=!1;var s,n=[];if(!this._noFinalSort&&this.currentItem.parent().length&&this.placeholder.before(this.currentItem),this._noFinalSort=null,this.helper[0]===this.currentItem[0]){for(s in this._storedCSS)("auto"===this._storedCSS[s]||"static"===this._storedCSS[s])&&(this._storedCSS[s]="");this.currentItem.css(this._storedCSS),this._removeClass(this.currentItem,"ui-sortable-helper")}else this.currentItem.show();for(this.fromOutside&&!e&&n.push(function(t){this._trigger("receive",t,this._uiHash(this.fromOutside))}),!this.fromOutside&&this.domPosition.prev===this.currentItem.prev().not(".ui-sortable-helper")[0]&&this.domPosition.parent===this.currentItem.parent()[0]||e||n.push(function(t){this._trigger("update",t,this._uiHash())}),this!==this.currentContainer&&(e||(n.push(function(t){this._trigger("remove",t,this._uiHash())}),n.push(function(t){return function(e){t._trigger("receive",e,this._uiHash(this))}}.call(this,this.currentContainer)),n.push(function(t){return function(e){t._trigger("update",e,this._uiHash(this))}}.call(this,this.currentContainer)))),s=this.containers.length-1;s>=0;s--)e||n.push(i("deactivate",this,this.containers[s])),this.containers[s].containerCache.over&&(n.push(i("out",this,this.containers[s])),this.containers[s].containerCache.over=0);if(this.storedCursor&&(this.document.find("body").css("cursor",this.storedCursor),this.storedStylesheet.remove()),this._storedOpacity&&this.helper.css("opacity",this._storedOpacity),this._storedZIndex&&this.helper.css("zIndex","auto"===this._storedZIndex?"":this._storedZIndex),this.dragging=!1,e||this._trigger("beforeStop",t,this._uiHash()),this.placeholder[0].parentNode.removeChild(this.placeholder[0]),this.cancelHelperRemoval||(this.helper[0]!==this.currentItem[0]&&this.helper.remove(),this.helper=null),!e){for(s=0;n.length>s;s++)n[s].call(this,t);this._trigger("stop",t,this._uiHash())}return this.fromOutside=!1,!this.cancelHelperRemoval},_trigger:function(){t.Widget.prototype._trigger.apply(this,arguments)===!1&&this.cancel()},_uiHash:function(e){var i=e||this;return{helper:i.helper,placeholder:i.placeholder||t([]),position:i.position,originalPosition:i.originalPosition,offset:i.positionAbs,item:i.currentItem,sender:e?e.element:null}}})});/*!
 * EventEmitter2
 * https://github.com/hij1nx/EventEmitter2
 *
 * Copyright (c) 2013 hij1nx
 * Licensed under the MIT license.
 */
;!function(undefined) {

  var isArray = Array.isArray ? Array.isArray : function _isArray(obj) {
    return Object.prototype.toString.call(obj) === "[object Array]";
  };
  var defaultMaxListeners = 10;

  function init() {
    this._events = {};
    if (this._conf) {
      configure.call(this, this._conf);
    }
  }

  function configure(conf) {
    if (conf) {

      this._conf = conf;

      conf.delimiter && (this.delimiter = conf.delimiter);
      conf.maxListeners && (this._events.maxListeners = conf.maxListeners);
      conf.wildcard && (this.wildcard = conf.wildcard);
      conf.newListener && (this.newListener = conf.newListener);

      if (this.wildcard) {
        this.listenerTree = {};
      }
    }
  }

  function EventEmitter(conf) {
    this._events = {};
    this.newListener = false;
    configure.call(this, conf);
  }
  EventEmitter.EventEmitter2 = EventEmitter; // backwards compatibility for exporting EventEmitter property

  //
  // Attention, function return type now is array, always !
  // It has zero elements if no any matches found and one or more
  // elements (leafs) if there are matches
  //
  function searchListenerTree(handlers, type, tree, i) {
    if (!tree) {
      return [];
    }
    var listeners=[], leaf, len, branch, xTree, xxTree, isolatedBranch, endReached,
        typeLength = type.length, currentType = type[i], nextType = type[i+1];
    if (i === typeLength && tree._listeners) {
      //
      // If at the end of the event(s) list and the tree has listeners
      // invoke those listeners.
      //
      if (typeof tree._listeners === 'function') {
        handlers && handlers.push(tree._listeners);
        return [tree];
      } else {
        for (leaf = 0, len = tree._listeners.length; leaf < len; leaf++) {
          handlers && handlers.push(tree._listeners[leaf]);
        }
        return [tree];
      }
    }

    if ((currentType === '*' || currentType === '**') || tree[currentType]) {
      //
      // If the event emitted is '*' at this part
      // or there is a concrete match at this patch
      //
      if (currentType === '*') {
        for (branch in tree) {
          if (branch !== '_listeners' && tree.hasOwnProperty(branch)) {
            listeners = listeners.concat(searchListenerTree(handlers, type, tree[branch], i+1));
          }
        }
        return listeners;
      } else if(currentType === '**') {
        endReached = (i+1 === typeLength || (i+2 === typeLength && nextType === '*'));
        if(endReached && tree._listeners) {
          // The next element has a _listeners, add it to the handlers.
          listeners = listeners.concat(searchListenerTree(handlers, type, tree, typeLength));
        }

        for (branch in tree) {
          if (branch !== '_listeners' && tree.hasOwnProperty(branch)) {
            if(branch === '*' || branch === '**') {
              if(tree[branch]._listeners && !endReached) {
                listeners = listeners.concat(searchListenerTree(handlers, type, tree[branch], typeLength));
              }
              listeners = listeners.concat(searchListenerTree(handlers, type, tree[branch], i));
            } else if(branch === nextType) {
              listeners = listeners.concat(searchListenerTree(handlers, type, tree[branch], i+2));
            } else {
              // No match on this one, shift into the tree but not in the type array.
              listeners = listeners.concat(searchListenerTree(handlers, type, tree[branch], i));
            }
          }
        }
        return listeners;
      }

      listeners = listeners.concat(searchListenerTree(handlers, type, tree[currentType], i+1));
    }

    xTree = tree['*'];
    if (xTree) {
      //
      // If the listener tree will allow any match for this part,
      // then recursively explore all branches of the tree
      //
      searchListenerTree(handlers, type, xTree, i+1);
    }

    xxTree = tree['**'];
    if(xxTree) {
      if(i < typeLength) {
        if(xxTree._listeners) {
          // If we have a listener on a '**', it will catch all, so add its handler.
          searchListenerTree(handlers, type, xxTree, typeLength);
        }

        // Build arrays of matching next branches and others.
        for(branch in xxTree) {
          if(branch !== '_listeners' && xxTree.hasOwnProperty(branch)) {
            if(branch === nextType) {
              // We know the next element will match, so jump twice.
              searchListenerTree(handlers, type, xxTree[branch], i+2);
            } else if(branch === currentType) {
              // Current node matches, move into the tree.
              searchListenerTree(handlers, type, xxTree[branch], i+1);
            } else {
              isolatedBranch = {};
              isolatedBranch[branch] = xxTree[branch];
              searchListenerTree(handlers, type, { '**': isolatedBranch }, i+1);
            }
          }
        }
      } else if(xxTree._listeners) {
        // We have reached the end and still on a '**'
        searchListenerTree(handlers, type, xxTree, typeLength);
      } else if(xxTree['*'] && xxTree['*']._listeners) {
        searchListenerTree(handlers, type, xxTree['*'], typeLength);
      }
    }

    return listeners;
  }

  function growListenerTree(type, listener) {

    type = typeof type === 'string' ? type.split(this.delimiter) : type.slice();

    //
    // Looks for two consecutive '**', if so, don't add the event at all.
    //
    for(var i = 0, len = type.length; i+1 < len; i++) {
      if(type[i] === '**' && type[i+1] === '**') {
        return;
      }
    }

    var tree = this.listenerTree;
    var name = type.shift();

    while (name) {

      if (!tree[name]) {
        tree[name] = {};
      }

      tree = tree[name];

      if (type.length === 0) {

        if (!tree._listeners) {
          tree._listeners = listener;
        }
        else if(typeof tree._listeners === 'function') {
          tree._listeners = [tree._listeners, listener];
        }
        else if (isArray(tree._listeners)) {

          tree._listeners.push(listener);

          if (!tree._listeners.warned) {

            var m = defaultMaxListeners;

            if (typeof this._events.maxListeners !== 'undefined') {
              m = this._events.maxListeners;
            }

            if (m > 0 && tree._listeners.length > m) {

              tree._listeners.warned = true;
              console.error('(node) warning: possible EventEmitter memory ' +
                            'leak detected. %d listeners added. ' +
                            'Use emitter.setMaxListeners() to increase limit.',
                            tree._listeners.length);
              if(console.trace){
                console.trace();
              }
            }
          }
        }
        return true;
      }
      name = type.shift();
    }
    return true;
  }

  // By default EventEmitters will print a warning if more than
  // 10 listeners are added to it. This is a useful default which
  // helps finding memory leaks.
  //
  // Obviously not all Emitters should be limited to 10. This function allows
  // that to be increased. Set to zero for unlimited.

  EventEmitter.prototype.delimiter = '.';

  EventEmitter.prototype.setMaxListeners = function(n) {
    this._events || init.call(this);
    this._events.maxListeners = n;
    if (!this._conf) this._conf = {};
    this._conf.maxListeners = n;
  };

  EventEmitter.prototype.event = '';

  EventEmitter.prototype.once = function(event, fn) {
    this.many(event, 1, fn);
    return this;
  };

  EventEmitter.prototype.many = function(event, ttl, fn) {
    var self = this;

    if (typeof fn !== 'function') {
      throw new Error('many only accepts instances of Function');
    }

    function listener() {
      if (--ttl === 0) {
        self.off(event, listener);
      }
      fn.apply(this, arguments);
    }

    listener._origin = fn;

    this.on(event, listener);

    return self;
  };

  EventEmitter.prototype.emit = function() {

    this._events || init.call(this);

    var type = arguments[0];

    if (type === 'newListener' && !this.newListener) {
      if (!this._events.newListener) {
        return false;
      }
    }

    var al = arguments.length;
    var args,l,i,j;
    var handler;

    if (this._all && this._all.length) {
      handler = this._all.slice();
      if (al > 3) {
        args = new Array(al);
        for (j = 0; j < al; j++) args[j] = arguments[j];
      }

      for (i = 0, l = handler.length; i < l; i++) {
        this.event = type;
        switch (al) {
        case 1:
          handler[i].call(this, type);
          break;
        case 2:
          handler[i].call(this, type, arguments[1]);
          break;
        case 3:
          handler[i].call(this, type, arguments[1], arguments[2]);
          break;
        default:
          handler[i].apply(this, args);
        }
      }
    }

    if (this.wildcard) {
      handler = [];
      var ns = typeof type === 'string' ? type.split(this.delimiter) : type.slice();
      searchListenerTree.call(this, handler, ns, this.listenerTree, 0);
    } else {
      handler = this._events[type];
      if (typeof handler === 'function') {
        this.event = type;
        switch (al) {
        case 1:
          handler.call(this);
          break;
        case 2:
          handler.call(this, arguments[1]);
          break;
        case 3:
          handler.call(this, arguments[1], arguments[2]);
          break;
        default:
          args = new Array(al - 1);
          for (j = 1; j < al; j++) args[j - 1] = arguments[j];
          handler.apply(this, args);
        }
        return true;
      } else if (handler) {
        // need to make copy of handlers because list can change in the middle
        // of emit call
        handler = handler.slice();
      }
    }

    if (handler && handler.length) {
      if (al > 3) {
        args = new Array(al - 1);
        for (j = 1; j < al; j++) args[j - 1] = arguments[j];
      }
      for (i = 0, l = handler.length; i < l; i++) {
        this.event = type;
        switch (al) {
        case 1:
          handler[i].call(this);
          break;
        case 2:
          handler[i].call(this, arguments[1]);
          break;
        case 3:
          handler[i].call(this, arguments[1], arguments[2]);
          break;
        default:
          handler[i].apply(this, args);
        }
      }
      return true;
    } else if (!this._all && type === 'error') {
      if (arguments[1] instanceof Error) {
        throw arguments[1]; // Unhandled 'error' event
      } else {
        throw new Error("Uncaught, unspecified 'error' event.");
      }
      return false;
    }

    return !!this._all;
  };

  EventEmitter.prototype.emitAsync = function() {

    this._events || init.call(this);

    var type = arguments[0];

    if (type === 'newListener' && !this.newListener) {
        if (!this._events.newListener) { return Promise.resolve([false]); }
    }

    var promises= [];

    var al = arguments.length;
    var args,l,i,j;
    var handler;

    if (this._all) {
      if (al > 3) {
        args = new Array(al);
        for (j = 1; j < al; j++) args[j] = arguments[j];
      }
      for (i = 0, l = this._all.length; i < l; i++) {
        this.event = type;
        switch (al) {
        case 1:
          promises.push(this._all[i].call(this, type));
          break;
        case 2:
          promises.push(this._all[i].call(this, type, arguments[1]));
          break;
        case 3:
          promises.push(this._all[i].call(this, type, arguments[1], arguments[2]));
          break;
        default:
          promises.push(this._all[i].apply(this, args));
        }
      }
    }

    if (this.wildcard) {
      handler = [];
      var ns = typeof type === 'string' ? type.split(this.delimiter) : type.slice();
      searchListenerTree.call(this, handler, ns, this.listenerTree, 0);
    } else {
      handler = this._events[type];
    }

    if (typeof handler === 'function') {
      this.event = type;
      switch (al) {
      case 1:
        promises.push(handler.call(this));
        break;
      case 2:
        promises.push(handler.call(this, arguments[1]));
        break;
      case 3:
        promises.push(handler.call(this, arguments[1], arguments[2]));
        break;
      default:
        args = new Array(al - 1);
        for (j = 1; j < al; j++) args[j - 1] = arguments[j];
        promises.push(handler.apply(this, args));
      }
    } else if (handler && handler.length) {
      if (al > 3) {
        args = new Array(al - 1);
        for (j = 1; j < al; j++) args[j - 1] = arguments[j];
      }
      for (i = 0, l = handler.length; i < l; i++) {
        this.event = type;
        switch (al) {
        case 1:
          promises.push(handler[i].call(this));
          break;
        case 2:
          promises.push(handler[i].call(this, arguments[1]));
          break;
        case 3:
          promises.push(handler[i].call(this, arguments[1], arguments[2]));
          break;
        default:
          promises.push(handler[i].apply(this, args));
        }
      }
    } else if (!this._all && type === 'error') {
      if (arguments[1] instanceof Error) {
        return Promise.reject(arguments[1]); // Unhandled 'error' event
      } else {
        return Promise.reject("Uncaught, unspecified 'error' event.");
      }
    }

    return Promise.all(promises);
  };

  EventEmitter.prototype.on = function(type, listener) {

    if (typeof type === 'function') {
      this.onAny(type);
      return this;
    }

    if (typeof listener !== 'function') {
      throw new Error('on only accepts instances of Function');
    }
    this._events || init.call(this);

    // To avoid recursion in the case that type == "newListeners"! Before
    // adding it to the listeners, first emit "newListeners".
    this.emit('newListener', type, listener);

    if(this.wildcard) {
      growListenerTree.call(this, type, listener);
      return this;
    }

    if (!this._events[type]) {
      // Optimize the case of one listener. Don't need the extra array object.
      this._events[type] = listener;
    }
    else if(typeof this._events[type] === 'function') {
      // Adding the second element, need to change to array.
      this._events[type] = [this._events[type], listener];
    }
    else if (isArray(this._events[type])) {
      // If we've already got an array, just append.
      this._events[type].push(listener);

      // Check for listener leak
      if (!this._events[type].warned) {

        var m = defaultMaxListeners;

        if (typeof this._events.maxListeners !== 'undefined') {
          m = this._events.maxListeners;
        }

        if (m > 0 && this._events[type].length > m) {

          this._events[type].warned = true;
          console.error('(node) warning: possible EventEmitter memory ' +
                        'leak detected. %d listeners added. ' +
                        'Use emitter.setMaxListeners() to increase limit.',
                        this._events[type].length);
          if(console.trace){
            console.trace();
          }
        }
      }
    }
    return this;
  };

  EventEmitter.prototype.onAny = function(fn) {

    if (typeof fn !== 'function') {
      throw new Error('onAny only accepts instances of Function');
    }

    if(!this._all) {
      this._all = [];
    }

    // Add the function to the event listener collection.
    this._all.push(fn);
    return this;
  };

  EventEmitter.prototype.addListener = EventEmitter.prototype.on;

  EventEmitter.prototype.off = function(type, listener) {
    if (typeof listener !== 'function') {
      throw new Error('removeListener only takes instances of Function');
    }

    var handlers,leafs=[];

    if(this.wildcard) {
      var ns = typeof type === 'string' ? type.split(this.delimiter) : type.slice();
      leafs = searchListenerTree.call(this, null, ns, this.listenerTree, 0);
    }
    else {
      // does not use listeners(), so no side effect of creating _events[type]
      if (!this._events[type]) return this;
      handlers = this._events[type];
      leafs.push({_listeners:handlers});
    }

    for (var iLeaf=0; iLeaf<leafs.length; iLeaf++) {
      var leaf = leafs[iLeaf];
      handlers = leaf._listeners;
      if (isArray(handlers)) {

        var position = -1;

        for (var i = 0, length = handlers.length; i < length; i++) {
          if (handlers[i] === listener ||
            (handlers[i].listener && handlers[i].listener === listener) ||
            (handlers[i]._origin && handlers[i]._origin === listener)) {
            position = i;
            break;
          }
        }

        if (position < 0) {
          continue;
        }

        if(this.wildcard) {
          leaf._listeners.splice(position, 1);
        }
        else {
          this._events[type].splice(position, 1);
        }

        if (handlers.length === 0) {
          if(this.wildcard) {
            delete leaf._listeners;
          }
          else {
            delete this._events[type];
          }
        }

        this.emit("removeListener", type, listener);

        return this;
      }
      else if (handlers === listener ||
        (handlers.listener && handlers.listener === listener) ||
        (handlers._origin && handlers._origin === listener)) {
        if(this.wildcard) {
          delete leaf._listeners;
        }
        else {
          delete this._events[type];
        }

        this.emit("removeListener", type, listener);
      }
    }

    function recursivelyGarbageCollect(root) {
      if (root === undefined) {
        return;
      }
      var keys = Object.keys(root);
      for (var i in keys) {
        var key = keys[i];
        var obj = root[key];
        if ((obj instanceof Function) || (typeof obj !== "object"))
          continue;
        if (Object.keys(obj).length > 0) {
          recursivelyGarbageCollect(root[key]);
        }
        if (Object.keys(obj).length === 0) {
          delete root[key];
        }
      }
    }
    recursivelyGarbageCollect(this.listenerTree);

    return this;
  };

  EventEmitter.prototype.offAny = function(fn) {
    var i = 0, l = 0, fns;
    if (fn && this._all && this._all.length > 0) {
      fns = this._all;
      for(i = 0, l = fns.length; i < l; i++) {
        if(fn === fns[i]) {
          fns.splice(i, 1);
          this.emit("removeListenerAny", fn);
          return this;
        }
      }
    } else {
      fns = this._all;
      for(i = 0, l = fns.length; i < l; i++)
        this.emit("removeListenerAny", fns[i]);
      this._all = [];
    }
    return this;
  };

  EventEmitter.prototype.removeListener = EventEmitter.prototype.off;

  EventEmitter.prototype.removeAllListeners = function(type) {
    if (arguments.length === 0) {
      !this._events || init.call(this);
      return this;
    }

    if(this.wildcard) {
      var ns = typeof type === 'string' ? type.split(this.delimiter) : type.slice();
      var leafs = searchListenerTree.call(this, null, ns, this.listenerTree, 0);

      for (var iLeaf=0; iLeaf<leafs.length; iLeaf++) {
        var leaf = leafs[iLeaf];
        leaf._listeners = null;
      }
    }
    else {
      if (!this._events || !this._events[type]) return this;
      this._events[type] = null;
    }
    return this;
  };

  EventEmitter.prototype.listeners = function(type) {
    if(this.wildcard) {
      var handlers = [];
      var ns = typeof type === 'string' ? type.split(this.delimiter) : type.slice();
      searchListenerTree.call(this, handlers, ns, this.listenerTree, 0);
      return handlers;
    }

    this._events || init.call(this);

    if (!this._events[type]) this._events[type] = [];
    if (!isArray(this._events[type])) {
      this._events[type] = [this._events[type]];
    }
    return this._events[type];
  };

  EventEmitter.prototype.listenerCount = function(type) {
    return this.listeners(type).length;
  };

  EventEmitter.prototype.listenersAny = function() {

    if(this._all) {
      return this._all;
    }
    else {
      return [];
    }

  };

  if (typeof define === 'function' && define.amd) {
     // AMD. Register as an anonymous module.
    define(function() {
      return EventEmitter;
    });
  } else if (typeof exports === 'object') {
    // CommonJS
    module.exports = EventEmitter;
  }
  else {
    // Browser global.
    window.EventEmitter2 = EventEmitter;
  }
}();
(function(){!function(a,b){return"function"==typeof define&&define.amd?define(function(){return b()}):"object"==typeof exports?module.exports=b():a.ifvisible=b()}(this,function(){var a,b,c,d,e,f,g,h,i,j,k,l,m,n;return i={},c=document,k=!1,l="active",g=6e4,f=!1,b=function(){var a,b,c,d,e,f,g;return a=function(){return(65536*(1+Math.random())|0).toString(16).substring(1)},e=function(){return a()+a()+"-"+a()+"-"+a()+"-"+a()+"-"+a()+a()+a()},f={},c="__ceGUID",b=function(a,b,d){return a[c]=void 0,a[c]||(a[c]="ifvisible.object.event.identifier"),f[a[c]]||(f[a[c]]={}),f[a[c]][b]||(f[a[c]][b]=[]),f[a[c]][b].push(d)},d=function(a,b,d){var e,g,h,i,j;if(a[c]&&f[a[c]]&&f[a[c]][b]){for(i=f[a[c]][b],j=[],g=0,h=i.length;g<h;g++)e=i[g],j.push(e(d||{}));return j}},g=function(a,b,d){var e,g,h,i,j;if(d){if(a[c]&&f[a[c]]&&f[a[c]][b])for(j=f[a[c]][b],g=h=0,i=j.length;h<i;g=++h)if(e=j[g],e===d)return f[a[c]][b].splice(g,1),e}else if(a[c]&&f[a[c]]&&f[a[c]][b])return delete f[a[c]][b]},{add:b,remove:g,fire:d}}(),a=function(){var a;return a=!1,function(b,c,d){return a||(a=b.addEventListener?function(a,b,c){return a.addEventListener(b,c,!1)}:b.attachEvent?function(a,b,c){return a.attachEvent("on"+b,c,!1)}:function(a,b,c){return a["on"+b]=c}),a(b,c,d)}}(),d=function(a,b){var d;return c.createEventObject?a.fireEvent("on"+b,d):(d=c.createEvent("HTMLEvents"),d.initEvent(b,!0,!0),!a.dispatchEvent(d))},h=function(){var a,b,d,e,f;for(e=void 0,f=3,d=c.createElement("div"),a=d.getElementsByTagName("i"),b=function(){return d.innerHTML="<!--[if gt IE "+ ++f+"]><i></i><![endif]-->",a[0]};b(););return f>4?f:e}(),e=!1,n=void 0,"undefined"!=typeof c.hidden?(e="hidden",n="visibilitychange"):"undefined"!=typeof c.mozHidden?(e="mozHidden",n="mozvisibilitychange"):"undefined"!=typeof c.msHidden?(e="msHidden",n="msvisibilitychange"):"undefined"!=typeof c.webkitHidden&&(e="webkitHidden",n="webkitvisibilitychange"),m=function(){var b,d;return b=[],d=function(){return b.map(clearTimeout),"active"!==l&&i.wakeup(),f=+new Date,b.push(setTimeout(function(){if("active"===l)return i.idle()},g))},d(),a(c,"mousemove",d),a(c,"keyup",d),a(c,"touchstart",d),a(window,"scroll",d),i.focus(d),i.wakeup(d)},j=function(){var b;return!!k||(e===!1?(b="blur",h<9&&(b="focusout"),a(window,b,function(){return i.blur()}),a(window,"focus",function(){return i.focus()})):a(c,n,function(){return c[e]?i.blur():i.focus()},!1),k=!0,m())},i={setIdleDuration:function(a){return g=1e3*a},getIdleDuration:function(){return g},getIdleInfo:function(){var a,b;return a=+new Date,b={},"idle"===l?(b.isIdle=!0,b.idleFor=a-f,b.timeLeft=0,b.timeLeftPer=100):(b.isIdle=!1,b.idleFor=a-f,b.timeLeft=f+g-a,b.timeLeftPer=(100-100*b.timeLeft/g).toFixed(2)),b},focus:function(a){return"function"==typeof a?this.on("focus",a):(l="active",b.fire(this,"focus"),b.fire(this,"wakeup"),b.fire(this,"statusChanged",{status:l})),this},blur:function(a){return"function"==typeof a?this.on("blur",a):(l="hidden",b.fire(this,"blur"),b.fire(this,"idle"),b.fire(this,"statusChanged",{status:l})),this},idle:function(a){return"function"==typeof a?this.on("idle",a):(l="idle",b.fire(this,"idle"),b.fire(this,"statusChanged",{status:l})),this},wakeup:function(a){return"function"==typeof a?this.on("wakeup",a):(l="active",b.fire(this,"wakeup"),b.fire(this,"statusChanged",{status:l})),this},on:function(a,c){return j(),b.add(this,a,c),this},off:function(a,c){return j(),b.remove(this,a,c),this},onEvery:function(a,b){var c,d;return j(),c=!1,b&&(d=setInterval(function(){if("active"===l&&c===!1)return b()},1e3*a)),{stop:function(){return clearInterval(d)},pause:function(){return c=!0},resume:function(){return c=!1},code:d,callback:b}},now:function(a){return j(),l===(a||"active")}}})}).call(this);/** @suppress{suspiciousCode} */
!function() {
'use strict';

var ENGINE_PORT = 6878;
var DEBUG = true;
var MODULE_NAME = "engine-api";

//require
if(TorrentStream === undefined) {
    TorrentStream = {};
}
var Utils = TorrentStream.Utils;
var $ = TorrentStream.jQuery;
var Q = TorrentStream.Q;

function log() {
    if(DEBUG) {
        var args = Array.prototype.slice.call(arguments);
        args.unshift(MODULE_NAME + ":");
        console.log.apply(console, args);
    }
}

var EngineApi = {};

EngineApi.serverRequest = function(method, params) {
    params = params || {};
    Utils.extend(params, {method: method});
    var deferred = Q.defer();

    $.ajax({
        method: "GET",
        url: "http://127.0.0.1:" + ENGINE_PORT + "/server/api",
        data: params,
        dataType: "json",
        cache: false,
        error: function(request, error_string, exception) {
            log("serverRequest: error", error_string, exception);
            deferred.reject(error_string);
        },
        success: function(response) {
            log("serverRequest: success", response);
            if(response.error) {
                deferred.reject(error);
            }
            else if(response.result === undefined) {
                deferred.reject("missing response");
            }
            else {
                deferred.resolve(response.result);
            }
        }
    });

    return deferred.promise;
};

TorrentStream.EngineApi = EngineApi;
}();!function() {
    function Texture(gl, width, height) {
        this.gl = gl;
        this.width = width; this.height = height;
        this.texture = gl.createTexture();
        gl.bindTexture(gl.TEXTURE_2D, this.texture);
        gl.texImage2D(gl.TEXTURE_2D, 0, gl.LUMINANCE, width, height, 0, gl.LUMINANCE, gl.UNSIGNED_BYTE, null);

        gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
        gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);

        gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
        gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
    }
    Texture.prototype.bind = function (n, program, name) {
        var gl = this.gl;
        gl.activeTexture([gl.TEXTURE0, gl.TEXTURE1, gl.TEXTURE2][n]);
        gl.bindTexture(gl.TEXTURE_2D, this.texture);
        gl.uniform1i(gl.getUniformLocation(program, name), n);
    }
    Texture.prototype.fill = function (data) {
        var gl = this.gl;
        gl.bindTexture(gl.TEXTURE_2D, this.texture);
        gl.texImage2D(gl.TEXTURE_2D, 0, gl.LUMINANCE, this.width, this.height, 0, gl.LUMINANCE, gl.UNSIGNED_BYTE, data);
    }

    function render(canvas, videoFrame) {
        // if (!vlc.playing) return;
        var gl = canvas.gl;
        var len = videoFrame.length;

        videoFrame.y.fill(videoFrame.subarray(0, videoFrame.uOffset));
        videoFrame.u.fill(videoFrame.subarray(videoFrame.uOffset, videoFrame.vOffset));
        videoFrame.v.fill(videoFrame.subarray(videoFrame.vOffset, len));
        gl.drawArrays(gl.TRIANGLE_STRIP, 0, 4);
    }

    var renderFallback = function(canvas, videoFrame) {
        var buf = canvas.img.data;
        var width = videoFrame.width;
        var height = videoFrame.height;
        for (var i = 0; i < height; ++i) {
            for (var j = 0; j < width; ++j) {
                var o = (j + (width*i))*4;
                buf[o + 0] = videoFrame[o+2];
                buf[o + 1] = videoFrame[o+1];
                buf[o + 2] = videoFrame[o+0];
                buf[o + 3] = videoFrame[o+3];
            }
        };
        canvas.ctx.putImageData(canvas.img, 0, 0);
    }

    function setupCanvas(canvas, fallbackRenderer) {
        if (!fallbackRenderer) canvas.gl = canvas.getContext("webgl"); // Comment this line out to test fallback
        var gl = canvas.gl;
        if (!gl || fallbackRenderer) {
            console.log(fallbackRenderer ? "Fallback renderer forced, not using WebGL" : "Unable to initialize WebGL, falling back to canvas rendering");
            // vlc.pixelFormat = vlc.RV32;
            // canvas.ctx = canvas.getContext("2d");
            // delete canvas.gl; // in case of fallback renderer
            return;
        }

        // vlc.pixelFormat = vlc.I420;
        canvas.I420Program = gl.createProgram();
        var program = canvas.I420Program;
        var vertexShaderSource = [
            "attribute highp vec4 aVertexPosition;",
            "attribute vec2 aTextureCoord;",
            "varying highp vec2 vTextureCoord;",
            "void main(void) {",
            " gl_Position = aVertexPosition;",
            " vTextureCoord = aTextureCoord;",
            "}"].join("\n");
        var vertexShader = gl.createShader(gl.VERTEX_SHADER);
        gl.shaderSource(vertexShader, vertexShaderSource);
        gl.compileShader(vertexShader);
        var fragmentShaderSource = [
            "precision highp float;",
            "varying lowp vec2 vTextureCoord;",
            "uniform sampler2D YTexture;",
            "uniform sampler2D UTexture;",
            "uniform sampler2D VTexture;",
            "const mat4 YUV2RGB = mat4",
            "(",
            " 1.1643828125, 0, 1.59602734375, -.87078515625,",
            " 1.1643828125, -.39176171875, -.81296875, .52959375,",
            " 1.1643828125, 2.017234375, 0, -1.081390625,",
            " 0, 0, 0, 1",
            ");",
            "void main(void) {",
            " gl_FragColor = vec4( texture2D(YTexture, vTextureCoord).x, texture2D(UTexture, vTextureCoord).x, texture2D(VTexture, vTextureCoord).x, 1) * YUV2RGB;",
            "}"].join("\n");

        var fragmentShader = gl.createShader(gl.FRAGMENT_SHADER);
        gl.shaderSource(fragmentShader, fragmentShaderSource);
        gl.compileShader(fragmentShader);
        gl.attachShader(program, vertexShader);
        gl.attachShader(program, fragmentShader);
        gl.linkProgram(program);
        gl.useProgram(program);
        if(!gl.getProgramParameter(program, gl.LINK_STATUS)) {
            console.log("Shader link failed.");
        }
        var vertexPositionAttribute = gl.getAttribLocation(program, "aVertexPosition");
        gl.enableVertexAttribArray(vertexPositionAttribute);
        var textureCoordAttribute = gl.getAttribLocation(program, "aTextureCoord");
        gl.enableVertexAttribArray(textureCoordAttribute);

        var verticesBuffer = gl.createBuffer();
        gl.bindBuffer(gl.ARRAY_BUFFER, verticesBuffer);
        gl.bufferData(gl.ARRAY_BUFFER,
                      new Float32Array([1.0, 1.0, 0.0, -1.0, 1.0, 0.0, 1.0, -1.0, 0.0, -1.0, -1.0, 0.0]),
                      gl.STATIC_DRAW);
        gl.vertexAttribPointer(vertexPositionAttribute, 3, gl.FLOAT, false, 0, 0);
        var texCoordBuffer = gl.createBuffer();
        gl.bindBuffer(gl.ARRAY_BUFFER, texCoordBuffer);
        gl.bufferData(gl.ARRAY_BUFFER,
                      new Float32Array([1.0, 0.0, 0.0, 0.0, 1.0, 1.0, 0.0, 1.0]),
                      gl.STATIC_DRAW);
        gl.vertexAttribPointer(textureCoordAttribute, 2, gl.FLOAT, false, 0, 0);
    }

    function frameSetup(canvas, width, height, pixelFormat, videoFrame) {
        var gl = canvas.gl;
        canvas.width = width;
        canvas.height = height;
        console.log(gl);
        if (! gl) {
            canvas.img = canvas.ctx.createImageData(width, height);
            return;
        }
        var program = canvas.I420Program;
        gl.viewport(0, 0, gl.drawingBufferWidth, gl.drawingBufferHeight);
        videoFrame.y = new Texture(gl, width, height);
        videoFrame.u = new Texture(gl, width >> 1, height >> 1);
        videoFrame.v = new Texture(gl, width >> 1, height >> 1);
        videoFrame.y.bind(0, program, "YTexture");
        videoFrame.u.bind(1, program, "UTexture");
        videoFrame.v.bind(2, program, "VTexture");
    }

    function FrameRenderer(canvas, fallbackRenderer) {
        this.canvas = canvas;
        this.lastFrame = null;

        if (typeof canvas === 'string') {
            setupCanvas(window.document.querySelector(canvas), fallbackRenderer);
        }
        else {
            setupCanvas(canvas, fallbackRenderer);
        }
    }

    FrameRenderer.prototype.setup = function(width, height, pixelFormat, videoFrame) {
        frameSetup(this.canvas, width, height, pixelFormat, videoFrame);

        canvas.addEventListener("webglcontextlost", function(event) {
            event.preventDefault();
            console.log("webgl context lost");
        }, false);

        canvas.addEventListener("webglcontextrestored", function(self,w,h,p,v) {
            return function(event) {
                setupCanvas(self.canvas);
                frameSetup(self.canvas, w, h, p, v);
                console.log("webgl context restored");
            }
        }(this,width,height,pixelFormat,videoFrame), false);

    };

    FrameRenderer.prototype.onFrameReady = function(videoFrame) {
        (canvas.gl ? render : renderFallback)(canvas, videoFrame);
        this.lastFrame = videoFrame;
    };

    FrameRenderer.prototype.clearCanvas = function() {
        if (this.lastFrame) {
            var gl = this.canvas.gl,
                arr1 = new Uint8Array(this.lastFrame.uOffset),
                arr2 = new Uint8Array(this.lastFrame.vOffset - this.lastFrame.uOffset);

            for (var i = 0; i < arr2.length; ++i) arr2[i] = 128;

            this.lastFrame.y.fill(arr1);
            this.lastFrame.u.fill(arr2);
            this.lastFrame.v.fill(arr2);

            gl.drawArrays(gl.TRIANGLE_STRIP, 0, 4);
        }
    };

    window.FrameRenderer = FrameRenderer;
}();/** @suppress{suspiciousCode} */
!function() {
    "use strict";

    var DEBUG = true;
    var VERBOSE = false;
    var MODULE_NAME = "mse-renderer";

    function log() {
        if(DEBUG) {
            var args = Array.prototype.slice.call(arguments);
            args.unshift(MODULE_NAME + ":");
            console.log.apply(console, args);
        }
    }

    function verbose() {
        if(VERBOSE) {
            var args = Array.prototype.slice.call(arguments);
            args.unshift(MODULE_NAME + ":");
            console.log.apply(console, args);
        }
    }

    function logevent(event) {
        console.log(event.type);
    };

    function MSERenderer(video, player, playbackUrl) {
        var self = this;

        this.events = new EventEmitter2();
        this.video = video;
        this.player = player;
        this.buffer = null;
        this.playbackUrl = playbackUrl;
        this.pendingChunks = [];

        this.dataBuffers = [[]];
        this.readBuffer = 0;
        this.writeBuffer = 0;
        this.chunksInBuffer = 0;

        if(playbackUrl) {
            this.useMSE = false;
        }
        else {
            this.useMSE = true;
        }

        this.minBufferChunksToStart = 3;
        this.seeking = false;
        this.stopped = true;
        this.timeOffset = 0;
        this.reset();

        if(this.useMSE) {
            this.timer = window.setInterval(this.updatePlayback.bind(this), 500);
        }

        this.onplay = function() {
            console.log("mse: onplay");
            self.events.emit("play");
        };

        this.onpause = function() {
            console.log("mse: onpause");
            self.events.emit("pause");
        };

        this.onstop = function() {
            console.log("onstop");
            self.stopped = true;
            self.events.emit("stop");
        };

        this.ondurationchange = function() {
            log("ondurationchange: duration=" + self.video.duration + " mse=" + self.useMSE);
            if(!self.useMSE) {
                self.events.emit("duration", self.getDuration());
            }
        };

        this.onended = function() {
            log("onended");
            self.stopped = true;
            self.events.emit("ended");
        };

        this.ontimeupdate = function() {
            var time;

            verbose("ontimeupdate: current=" + self.video.currentTime + " offset=" + self.timeOffset + " mse=" + self.useMSE);

            if(self.useMSE) {
                time = Math.round((self.video.currentTime + self.timeOffset) * 1000);
            }
            else {
                time = self.video.currentTime * 1000;
            }
            self.events.emit("time", time);
        };

        this.onerror = function() {
            self.stopped = true;
            self.events.emit("error");
        };

        // setup video events
        //NOTE: don't forget to remove listeners in |shutdown|
        self.video.addEventListener('error', this.onerror);
        self.video.addEventListener('play', this.onplay);
        self.video.addEventListener('pause', this.onpause);
        self.video.addEventListener('stop', this.onstop);
        self.video.addEventListener('ended', this.onended);
        self.video.addEventListener('durationchange', this.ondurationchange);
        self.video.addEventListener('timeupdate', this.ontimeupdate);
    }

    MSERenderer.prototype.getDuration = function() {
        return Math.round(this.video.duration * 1000);
    };

    MSERenderer.prototype.prepareSourceBuffer = function(callback) {
        var self = this;

        if(!self.useMSE) {
            self.video.src = self.playbackUrl;
            self.video.play();
        }
        else {
            self.buffer = null;
            self.mediaSource = new MediaSource();
            self.video.src = URL.createObjectURL(self.mediaSource);

            self.mediaSource.addEventListener('error', logevent);
            self.mediaSource.addEventListener('opened', logevent);
            self.mediaSource.addEventListener('closed', logevent);
            self.mediaSource.addEventListener('sourceended', logevent);

            self.mediaSource.addEventListener('sourceopen', function () {
                self.mediaSource.duration = 0;
                self.buffer = self.mediaSource.addSourceBuffer('video/mp4;codecs=avc1.640028,mp4a.40.2');

                self.buffer.addEventListener('updatestart', logevent);
                self.buffer.addEventListener('updateend', function(event) {
                    console.log("updateend: pending=" + self.pendingChunks.length);
                    var remainDuration = self.getRemainDuration();
                    if(remainDuration < 45) {
                        self.loadChunkFromBuffer();
                    }
                    // if(self.pendingChunks.length) {
                        // self.buffer.appendBuffer(self.pendingChunks.shift());
                    // }
                });
                self.buffer.addEventListener('error', logevent);

                if(typeof callback === "function") {
                    callback();
                }
            });
        }
    };

    MSERenderer.prototype.loadChunk = function(chunkId, cb) {
        var xhr = new XMLHttpRequest(),
            url = "http://127.0.0.1:6880/get_chunk?client_id=" + this.player._clientId + "&id=" + chunkId;

        console.log("loadChunk", url);

        xhr.open('get', url);
        xhr.responseType = 'arraybuffer';
        xhr.onload = function () {
            if(this.status == 200) {
                cb(xhr.response);
            }
        };
        xhr.send();
    }

    MSERenderer.prototype.loadNextChunk = function() {
        var self = this;

        if(self.stopped) {
            log("loadNextChunk: stopped");
            return;
        }

        if(self.availableChunks[self.nextChunk] === undefined) {
            log("loadNextChunk: missing next: " + self.nextChunk);
        }
        else if(self.availableChunks[self.nextChunk].loading) {
            log("loadNextChunk: next is loading: " + self.nextChunk);
        }
        else {
            // mark as loading
            self.availableChunks[self.nextChunk].loading = true;
            self.loadChunk(self.nextChunk, function(response) {
                log("chunk loaded: id=" + self.nextChunk + " data=" + JSON.stringify(self.availableChunks[self.nextChunk]));

                if(self.availableChunks[self.nextChunk] === undefined) {
                    // chunk data was reset while loading
                    return;
                }

                if(self.availableChunks[self.nextChunk].discontinuity) {
                    self.discontinuity = true;
                    console.log("set discontinuity flag");
                }
                else if(self.discontinuity) {
                    console.log("got discontinuity flag");
                    self.pendingChunks.push(response);
                }

                // push to data buffer
                self.dataBuffers[self.writeBuffer].push(response);
                ++self.chunksInBuffer;

                delete self.availableChunks[self.nextChunk];
                ++self.nextChunk;

                if(self.chunksInBuffer < 3) {
                    self.loadNextChunk();
                }
            });
        }
    };

    MSERenderer.prototype.loadChunkFromBuffer = function() {
        var self = this,
            buf = self.dataBuffers[self.readBuffer],
            updating = self.buffer && self.buffer.updating;

        if(buf.length && !updating) {

            if(self.firstData && self.chunksInBuffer < self.minBufferChunksToStart) {
                log("loadChunkFromBuffer: wait for chunks: have=" + self.chunksInBuffer + " want=" + self.minBufferChunksToStart);
                return;
            }

            if(self.seeking) {
                self.prepareSourceBuffer();
                self.seeking = false;
                self.events.emit("seekend");
            }
            else if(self.buffer) {
                self.buffer.appendBuffer(buf.shift());
                --self.chunksInBuffer;
                log("loadChunkFromBuffer: chunksInBuffer=" + self.chunksInBuffer);

                if(self.firstData) {
                    self.firstData = false;
                    self.video.play();
                }
            }
            else {
                log("loadChunkFromBuffer: no source buffer");
            }
        }
    };

    MSERenderer.prototype.gotChunk = function(chunkId, discontinuity) {
        var self = this;

        log("mse: got chunk: id=" + chunkId + " discontinuity=" + discontinuity);
        self.availableChunks[chunkId] = {
            loading: false,
            discontinuity: discontinuity
        };

        // immediatelly load first chunk
        // if(chunkId == 0) {
        //     self.loadNextChunk();
        // }
    };

    MSERenderer.prototype.resetSourceBuffer = function(callback) {
        var self = this;

        if(this.useMSE) {
            this.mediaSource.endOfStream();
            this.mediaSource.removeSourceBuffer(this.buffer);
            //self.buffer = self.mediaSource.addSourceBuffer('video/mp4;codecs=avc1.640028,mp4a.40.2');

            //self.buffer.addEventListener('updatestart', logevent);
            //self.buffer.addEventListener('updateend', logevent);
            //self.buffer.addEventListener('error', logevent);
            //callback();
            this.mediaSource = null;
            this.buffer = null;
            //this.video.removeAttribute("src");
        }
        this.prepareSourceBuffer(callback);
    };

    MSERenderer.prototype.getRemainDuration = function() {
        var self = this,
            remainDuration = 0;

        if(!self.useMSE) {
            return 0;
        }

        if(!self.buffer) {
            return 0;
        }

        if(self.buffer.buffered.length == 0) {
            return 0;
        }

        remainDuration = self.buffer.buffered.end(0) - self.video.currentTime;
        return remainDuration;
    };

    MSERenderer.prototype.updatePlayback = function() {
        var self = this;

        if(self.useMSE) {
            if(!self.buffer) {
                return;
            }

            var remainDuration = 0;

            // always update buffer when seeking
            if(!self.seeking) {
                remainDuration = self.getRemainDuration();
            }

            if(remainDuration < 45) {
                self.loadChunkFromBuffer();
            }

            if(self.chunksInBuffer < 3) {
                self.loadNextChunk();
            }

            //console.log("remain", remainDuration, "paused", self.video.paused, "discontinuity", self.discontinuity);

            // if(self.discontinuity && remainDuration <= 1) {
            //     self.resetSourceBuffer(function() {
            //             self.discontinuity = false;
            //             if(self.pendingChunks.length) {
            //                 self.buffer.appendBuffer(self.pendingChunks.shift());
            //             }
            //             self.video.play();
            //     });
            // }
        }
    };

    MSERenderer.prototype.reset = function(seek) {
        if(seek) {
            this.video.pause();
        }
        else {
            this.stop();
        }

        this.seeking = !!seek;
        this.firstData = true;
        this.stopped = false;
        this.nextChunk = 0;
        this.chunksInBuffer = 0;
        this.dataBuffers = [[]];
        this.writeBuffer = 0;
        this.readBuffer = 0;
        this.availableChunks = {};

        if(this.seeking) {
            this.events.emit("seekstart");
        }
        else {
            this.prepareSourceBuffer();
        }
    };

    MSERenderer.prototype.stop = function() {
        log("stop: stopped=" + this.stopped);
        if(!this.stopped) {
            this.stopped = true;
            if(this.useMSE) {
                this.mediaSource.endOfStream();
                this.mediaSource.removeSourceBuffer(this.buffer);
                this.mediaSource = null;
                this.buffer = null;
                //this.video.src = URL.createObjectURL(new MediaSource());
                this.video.removeAttribute("src");
            }
            this.events.emit("stop");
        }
    };

    MSERenderer.prototype.shutdown = function() {
        var self = this;

        this.stop();

        // remove video events
        self.video.removeEventListener('play', this.onplay);
        self.video.removeEventListener('pause', this.onpause);
        self.video.removeEventListener('stop', this.onstop);
        self.video.removeEventListener('error', this.onerror);
        self.video.removeEventListener('ended', this.onended);
        self.video.removeEventListener('durationchange', this.ondurationchange);
        self.video.removeEventListener('timeupdate', this.ontimeupdate);

        // stop playback timer
        if(self.timer) {
            window.clearInterval(self.timer);
        }
    };

    MSERenderer.prototype.setup = function(width, height) {
        this.width = width;
        this.height = height;
        this.video.width = width;
        this.video.height = height;
    }

    TorrentStream.MSERenderer = MSERenderer;
}();(function(window){ 'use strict';

// jsmpeg by Dominic Szablewski - phoboslab.org, github.com/phoboslab
//
// Consider this to be under MIT license. It's largely based an an Open Source
// Decoder for Java under GPL, while I looked at another Decoder from Nokia
// (under no particular license?) for certain aspects.
// I'm not sure if this work is "derivative" enough to have a different license
// but then again, who still cares about MPEG1?
//
// Based on "Java MPEG-1 Video Decoder and Player" by Korandi Zoltan:
// http://sourceforge.net/projects/javampeg1video/
//
// Inspired by "MPEG Decoder in Java ME" by Nokia:
// http://www.developer.nokia.com/Community/Wiki/MPEG_decoder_in_Java_ME


var requestAnimFrame = (function(){
    return window.requestAnimationFrame ||
        window.webkitRequestAnimationFrame ||
        window.mozRequestAnimationFrame ||
        function( callback ){
            window.setTimeout(callback, 1000 / 60);
        };
})();

var VERBOSE = false;

var jsmpeg = TorrentStream.MPEGRenderer = function(canvas, player, opts) {
    this.canvas = canvas;
    this.player = player;

    opts = opts || {};
    this.progressive = (opts.progressive !== false);
    this.benchmark = !!opts.benchmark;
    this.autoplay = !!opts.autoplay;
    this.wantsToPlay = this.autoplay;
    this.loop = !!opts.loop;
    this.seekable = !!opts.seekable;
    this.externalLoadCallback = opts.onload || null;
    this.externalFinishedCallback = opts.onfinished || null;
    this.customIntraQuantMatrix = new Uint8Array(64);
    this.customNonIntraQuantMatrix = new Uint8Array(64);
    this.blockData = new Int32Array(64);
    this.zeroBlockData = new Int32Array(64);
    this.fillArray(this.zeroBlockData, 0);

    this.gotFirstPacket = false;
    this.stopped = true;

    // use WebGL for YCbCrToRGBA conversion if possible (much faster)
    if( !opts.forceCanvas2D && this.initWebGL() ) {
        this.renderFrame = this.renderFrameGL;
    } else {
        this.canvasContext = this.canvas.getContext('2d');
        this.renderFrame = this.renderFrame2D;
    }

    this.initSocketClient();
};

// ----------------------------------------------------------------------------
// Streaming over WebSockets

jsmpeg.prototype.waitForIntraFrame = true;
//TODO: set buffer size dynamically?
jsmpeg.prototype.socketBufferSize = 20 * 1024 * 1024; // 20 Mb

jsmpeg.prototype.initSocketClient = function() {
    this.buffer = new BitReader(new ArrayBuffer(this.socketBufferSize));

    // this.nextPictureBuffer = new BitReader(new ArrayBuffer(this.socketBufferSize));
    // this.nextPictureBuffer.writePos = 0;
    // this.nextPictureBuffer.chunkBegin = 0;
    // this.nextPictureBuffer.lastWriteBeforeWrap = 0;

    // this.client.binaryType = 'arraybuffer';
    // this.client.onmessage = this.receiveSocketMessage2.bind(this);
};

jsmpeg.prototype.setup = function(width, height) {
    this.width = width;
    this.height = height;
    this.initBuffers();
    this.buffer.writePos = 0;
}

jsmpeg.prototype.onVideoPacket = function(messageData) {
    var buf = this.buffer;

    if(this.stopped) {
        return;
    }

    // decode header
    // if( !this.sequenceStarted ) {
    //     buf.writePos = 0;
    //     this.decodeSocketHeader(messageData);
    //     return;
    // }

    // add data to the end of the buffer
    // if( buf.writePos + messageData.length > buf.length ) {
    //     console.log("buffer overflow, truncate: msglen=" + messageData.length + " writepos=" + buf.writePos + " buflen=" + buf.length);

    //     // free processed data
    //     buf.truncate();
    // }

    // if( buf.writePos + messageData.length > buf.length ) {
    //     console.log("buffer overflow, error");
    //     return false;
    // }

    // buf.bytes.set( messageData, buf.writePos );
    // buf.writePos += messageData.length;

    if(!buf.write(messageData)) {
        // possibly buffer overflow
        return;
    }

    if(!this.gotFirstPacket) {
        console.log("start playing");

        var startCode = buf.findNextMPEGStartCode();
        if(startCode === BitReader.NOT_FOUND) {
            // wait
            if(VERBOSE) {
                console.log("start code not found on start, wait");
            }
            buf.index = Math.max((buf.writePos-3), 0) << 3;
            return;
        }

        if(VERBOSE) {
            console.log("found start code: " + startCode);
        }
        this.buffer.rewind(32);

        // Load the first frame
        this.nextFrame();

        // play
        this.gotFirstPacket = true;

        this.play();
    }

    return true;
}

// ----------------------------------------------------------------------------
// Loading via Ajax

jsmpeg.prototype.currentFrameNumber = -1;
jsmpeg.prototype.currentFrame = -1;
jsmpeg.prototype.currentTime = 0;
jsmpeg.prototype.frameCount = 0;
jsmpeg.prototype.duration = 0;
jsmpeg.prototype.progressiveMinSize = 128 * 1024;

jsmpeg.prototype.start = function() {
    this.stopped = false;
};

jsmpeg.prototype.play = function() {
    console.log("jsmpeg: play");

    if( this.playing ) { return; }
    this.targetTime = this.now();
    this.playing = true;
    this.wantsToPlay = true;
    this.scheduleNextFrame();
};

jsmpeg.prototype.pause = function() {
    console.log("mpeg_renderer: pause");
    this.playing = false;
    this.wantsToPlay = false;
};

jsmpeg.prototype.stop = function() {
    this.currentFrame = -1;
    if( this.buffer ) {
        this.buffer.index = this.firstSequenceHeader;
    }
    this.playing = false;
    this.gotFirstPacket = false;
    this.stopped = true;
    if( this.client ) {
        this.client.close();
        this.client = null;
    }
    this.wantsToPlay = false;
    if(this.buffer) {
        this.buffer.reset();
    }
};

jsmpeg.prototype.shutdown = function() {
    this.stop();
    this.buffer = null;
};

// ----------------------------------------------------------------------------
// Utilities

jsmpeg.prototype.readCode = function(codeTable) {
    var state = 0;
    do {
        state = codeTable[state + this.buffer.getBits(1)];
    } while( state >= 0 && codeTable[state] !== 0 );
    return codeTable[state+2];
};

jsmpeg.prototype.findStartCode = function( code ) {
    var current = 0;
    while( true ) {
        current = this.buffer.findNextMPEGStartCode();
        if( current === code || current === BitReader.NOT_FOUND ) {
            return current;
        }
    }
    return BitReader.NOT_FOUND;
};

jsmpeg.prototype.fillArray = function(a, value) {
    for( var i = 0, length = a.length; i < length; i++ ) {
        a[i] = value;
    }
};



// ----------------------------------------------------------------------------
// Sequence Layer

jsmpeg.prototype.pictureRate = 24;
jsmpeg.prototype.lateTime = 0;
jsmpeg.prototype.firstSequenceHeader = 0;
jsmpeg.prototype.targetTime = 0;

jsmpeg.prototype.benchmark = false;
jsmpeg.prototype.benchFrame = 0;
jsmpeg.prototype.benchDecodeTimes = 0;
jsmpeg.prototype.benchAvgFrameTime = 0;

jsmpeg.prototype.now = function() {
    return window.performance
        ? window.performance.now()
        : Date.now();
};

jsmpeg.prototype.nextFrame = function() {
    if( !this.buffer ) { return; }

    var frameStart = this.now();
    while(true) {
        var code = this.buffer.findNextMPEGStartCode();

        if( code === START_SEQUENCE ) {
            this.decodeSequenceHeader();
        }
        else if( code === START_PICTURE ) {
            // if( this.progressive && this.buffer.index >= this.lastFrameIndex ) {
            //     // Starved
            //     this.playing = false;
            //     return;
            // }
            // if( this.playing ) {
                this.scheduleNextFrame();
            // }
            this.decodePicture();
            this.benchDecodeTimes += this.now() - frameStart;
            return this.canvas;
        }
        else if(code === START_FRAME_NUMBER) {
            this.currentFrameNumber = this.buffer.getBits(32);
            //console.log("currentFrameNumber", this.currentFrameNumber);
        }
        else if( code === BitReader.NOT_FOUND ) {
            // for testing
            console.log("start code not found: playing=" + this.playing);
            if( this.playing ) {
                this.scheduleNextFrame();
            }
            return;
        }
        else {
            // ignore (GROUP, USER_DATA, EXTENSION, SLICES...)
        }
    }
};

jsmpeg.prototype.scheduleNextFrame = function() {
    this.lateTime = this.now() - this.targetTime;
    var wait = Math.max(0, (1000/this.pictureRate) - this.lateTime);
    this.targetTime = this.now() + wait;

    if( this.benchmark ) {
        this.benchFrame++;
        if( this.benchFrame >= 120 ) {
            this.benchAvgFrameTime = this.benchDecodeTimes / this.benchFrame;
            this.benchFrame = 0;
            this.benchDecodeTimes = 0;
            if( window.console ) { console.log('Average time per frame:', this.benchAvgFrameTime, 'ms'); }
        }
        setTimeout( this.nextFrame.bind(this), 0);
    }
    else if( wait < 18) {
        console.log("wait=" + wait);
        this.scheduleAnimation();
    }
    else {
        setTimeout( this.scheduleAnimation.bind(this), wait );
    }
};

jsmpeg.prototype.scheduleAnimation = function() {
    requestAnimFrame( this.nextFrame.bind(this), this.canvas );
};

jsmpeg.prototype.decodeSequenceHeader = function() {
    this.width = this.buffer.getBits(12);
    this.height = this.buffer.getBits(12);
    this.buffer.advance(4); // skip pixel aspect ratio
    this.pictureRate = PICTURE_RATE[this.buffer.getBits(4)];
    this.buffer.advance(18 + 1 + 10 + 1); // skip bitRate, marker, bufferSize and constrained bit

    this.initBuffers();

    var i;

    if( this.buffer.getBits(1) ) { // load custom intra quant matrix?
        for( i = 0; i < 64; i++ ) {
            this.customIntraQuantMatrix[ZIG_ZAG[i]] = this.buffer.getBits(8);
        }
        this.intraQuantMatrix = this.customIntraQuantMatrix;
    }

    if( this.buffer.getBits(1) ) { // load custom non intra quant matrix?
        for( i = 0; i < 64; i++ ) {
            this.customNonIntraQuantMatrix[ZIG_ZAG[i]] = this.buffer.getBits(8);
        }
        this.nonIntraQuantMatrix = this.customNonIntraQuantMatrix;
    }
};

jsmpeg.prototype.initBuffers = function() {
    this.intraQuantMatrix = DEFAULT_INTRA_QUANT_MATRIX;
    this.nonIntraQuantMatrix = DEFAULT_NON_INTRA_QUANT_MATRIX;

    this.mbWidth = (this.width + 15) >> 4;
    this.mbHeight = (this.height + 15) >> 4;
    this.mbSize = this.mbWidth * this.mbHeight;

    this.codedWidth = this.mbWidth << 4;
    this.codedHeight = this.mbHeight << 4;
    this.codedSize = this.codedWidth * this.codedHeight;

    this.halfWidth = this.mbWidth << 3;
    this.halfHeight = this.mbHeight << 3;
    this.quarterSize = this.codedSize >> 2;

    // Sequence already started? Don't allocate buffers again
    if( this.sequenceStarted ) { return; }
    this.sequenceStarted = true;


    // Manually clamp values when writing macroblocks for shitty browsers
    // that don't support Uint8ClampedArray
    var MaybeClampedUint8Array = window.Uint8ClampedArray || window.Uint8Array;
    if( !window.Uint8ClampedArray ) {
        this.copyBlockToDestination = this.copyBlockToDestinationClamp;
        this.addBlockToDestination = this.addBlockToDestinationClamp;
    }

    // Allocated buffers and resize the canvas
    this.currentY = new MaybeClampedUint8Array(this.codedSize);
    this.currentY32 = new Uint32Array(this.currentY.buffer);

    this.currentCr = new MaybeClampedUint8Array(this.codedSize >> 2);
    this.currentCr32 = new Uint32Array(this.currentCr.buffer);

    this.currentCb = new MaybeClampedUint8Array(this.codedSize >> 2);
    this.currentCb32 = new Uint32Array(this.currentCb.buffer);


    this.forwardY = new MaybeClampedUint8Array(this.codedSize);
    this.forwardY32 = new Uint32Array(this.forwardY.buffer);

    this.forwardCr = new MaybeClampedUint8Array(this.codedSize >> 2);
    this.forwardCr32 = new Uint32Array(this.forwardCr.buffer);

    this.forwardCb = new MaybeClampedUint8Array(this.codedSize >> 2);
    this.forwardCb32 = new Uint32Array(this.forwardCb.buffer);

    this.canvas.width = this.width;
    this.canvas.height = this.height;

    if( this.gl ) {
        this.gl.useProgram(this.program);
        this.gl.viewport(0, 0, this.width, this.height);
    }
    else {
        this.currentRGBA = this.canvasContext.getImageData(0, 0, this.width, this.height);
        this.fillArray(this.currentRGBA.data, 255);
    }
};




// ----------------------------------------------------------------------------
// Picture Layer

jsmpeg.prototype.currentY = null;
jsmpeg.prototype.currentCr = null;
jsmpeg.prototype.currentCb = null;

jsmpeg.prototype.currentRGBA = null;

jsmpeg.prototype.pictureCodingType = 0;

// Buffers for motion compensation
jsmpeg.prototype.forwardY = null;
jsmpeg.prototype.forwardCr = null;
jsmpeg.prototype.forwardCb = null;

jsmpeg.prototype.fullPelForward = false;
jsmpeg.prototype.forwardFCode = 0;
jsmpeg.prototype.forwardRSize = 0;
jsmpeg.prototype.forwardF = 0;


jsmpeg.prototype.decodePicture = function(skipOutput) {
    this.currentFrame++;
    this.currentTime = this.currentFrame / this.pictureRate;

    this.buffer.advance(10); // skip temporalReference
    this.pictureCodingType = this.buffer.getBits(3);
    this.buffer.advance(16); // skip vbv_delay

    // Skip B and D frames or unknown coding type
    if( this.pictureCodingType <= 0 || this.pictureCodingType >= PICTURE_TYPE_B ) {
        return;
    }

    // full_pel_forward, forward_f_code
    if( this.pictureCodingType === PICTURE_TYPE_P ) {
        this.fullPelForward = this.buffer.getBits(1);
        this.forwardFCode = this.buffer.getBits(3);
        if( this.forwardFCode === 0 ) {
            // Ignore picture with zero forward_f_code
            return;
        }
        this.forwardRSize = this.forwardFCode - 1;
        this.forwardF = 1 << this.forwardRSize;
    }

    var code = 0;
    do {
        code = this.buffer.findNextMPEGStartCode();
    } while( code === START_EXTENSION || code === START_USER_DATA );

    while( code >= START_SLICE_FIRST && code <= START_SLICE_LAST ) {
        this.decodeSlice( (code & 0x000000FF) );
        code = this.buffer.findNextMPEGStartCode();
    }

    // We found the next start code; rewind 32bits and let the main loop handle it.
    this.buffer.rewind(32);

    if( skipOutput !== DECODE_SKIP_OUTPUT ) {
        this.renderFrame();
        if(this.currentFrameNumber !== -1) {
            this.player.onFrameRendered(this.currentFrameNumber);
        }
    }

    // If this is a reference picutre then rotate the prediction pointers
    if( this.pictureCodingType === PICTURE_TYPE_I || this.pictureCodingType === PICTURE_TYPE_P ) {
        var
            tmpY = this.forwardY,
            tmpY32 = this.forwardY32,
            tmpCr = this.forwardCr,
            tmpCr32 = this.forwardCr32,
            tmpCb = this.forwardCb,
            tmpCb32 = this.forwardCb32;

        this.forwardY = this.currentY;
        this.forwardY32 = this.currentY32;
        this.forwardCr = this.currentCr;
        this.forwardCr32 = this.currentCr32;
        this.forwardCb = this.currentCb;
        this.forwardCb32 = this.currentCb32;

        this.currentY = tmpY;
        this.currentY32 = tmpY32;
        this.currentCr = tmpCr;
        this.currentCr32 = tmpCr32;
        this.currentCb = tmpCb;
        this.currentCb32 = tmpCb32;
    }
};

jsmpeg.prototype.YCbCrToRGBA = function() {
    var pY = this.currentY;
    var pCb = this.currentCb;
    var pCr = this.currentCr;
    var pRGBA = this.currentRGBA.data;

    // Chroma values are the same for each block of 4 pixels, so we proccess
    // 2 lines at a time, 2 neighboring pixels each.
    // I wish we could use 32bit writes to the RGBA buffer instead of writing
    // each byte separately, but we need the automatic clamping of the RGBA
    // buffer.

    var yIndex1 = 0;
    var yIndex2 = this.codedWidth;
    var yNext2Lines = this.codedWidth + (this.codedWidth - this.width);

    var cIndex = 0;
    var cNextLine = this.halfWidth - (this.width >> 1);

    var rgbaIndex1 = 0;
    var rgbaIndex2 = this.width * 4;
    var rgbaNext2Lines = this.width * 4;

    var cols = this.width >> 1;
    var rows = this.height >> 1;

    var cb, cr, r, g, b;

    for( var row = 0; row < rows; row++ ) {
        for( var col = 0; col < cols; col++ ) {
            cb = pCb[cIndex];
            cr = pCr[cIndex];
            cIndex++;

            r = (cr + ((cr * 103) >> 8)) - 179;
            g = ((cb * 88) >> 8) - 44 + ((cr * 183) >> 8) - 91;
            b = (cb + ((cb * 198) >> 8)) - 227;

            // Line 1
            var y1 = pY[yIndex1++];
            var y2 = pY[yIndex1++];
            pRGBA[rgbaIndex1]   = y1 + r;
            pRGBA[rgbaIndex1+1] = y1 - g;
            pRGBA[rgbaIndex1+2] = y1 + b;
            pRGBA[rgbaIndex1+4] = y2 + r;
            pRGBA[rgbaIndex1+5] = y2 - g;
            pRGBA[rgbaIndex1+6] = y2 + b;
            rgbaIndex1 += 8;

            // Line 2
            var y3 = pY[yIndex2++];
            var y4 = pY[yIndex2++];
            pRGBA[rgbaIndex2]   = y3 + r;
            pRGBA[rgbaIndex2+1] = y3 - g;
            pRGBA[rgbaIndex2+2] = y3 + b;
            pRGBA[rgbaIndex2+4] = y4 + r;
            pRGBA[rgbaIndex2+5] = y4 - g;
            pRGBA[rgbaIndex2+6] = y4 + b;
            rgbaIndex2 += 8;
        }

        yIndex1 += yNext2Lines;
        yIndex2 += yNext2Lines;
        rgbaIndex1 += rgbaNext2Lines;
        rgbaIndex2 += rgbaNext2Lines;
        cIndex += cNextLine;
    }
};

jsmpeg.prototype.renderFrame2D = function() {
    this.YCbCrToRGBA();
    this.canvasContext.putImageData(this.currentRGBA, 0, 0);
};


// ----------------------------------------------------------------------------
// Accelerated WebGL YCbCrToRGBA conversion

jsmpeg.prototype.gl = null;
jsmpeg.prototype.program = null;
jsmpeg.prototype.YTexture = null;
jsmpeg.prototype.CBTexture = null;
jsmpeg.prototype.CRTexture = null;

jsmpeg.prototype.createTexture = function(index, name) {
    var gl = this.gl;
    var texture = gl.createTexture();

    gl.bindTexture(gl.TEXTURE_2D, texture);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
    gl.uniform1i(gl.getUniformLocation(this.program, name), index);

    return texture;
};

jsmpeg.prototype.compileShader = function(type, source) {
    var gl = this.gl;
    var shader = gl.createShader(type);
    gl.shaderSource(shader, source);
    gl.compileShader(shader);

    if( !gl.getShaderParameter(shader, gl.COMPILE_STATUS) ) {
        throw new Error(gl.getShaderInfoLog(shader));
    }

    return shader;
};

jsmpeg.prototype.initWebGL = function() {
    var gl;

    // attempt to get a webgl context
    try {
        gl = this.gl = this.canvas.getContext('webgl') || this.canvas.getContext('experimental-webgl');
    } catch (e) {
        return false;
    }

    if (!gl) {
        return false;
    }

    // init buffers
    var buffer = gl.createBuffer();
    gl.bindBuffer(gl.ARRAY_BUFFER, buffer);
    gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([0, 0, 0, 1, 1, 0, 1, 1]), gl.STATIC_DRAW);

    // The main YCbCrToRGBA Shader
    this.program = gl.createProgram();
    gl.attachShader(this.program, this.compileShader(gl.VERTEX_SHADER, SHADER_VERTEX_IDENTITY));
    gl.attachShader(this.program, this.compileShader(gl.FRAGMENT_SHADER, SHADER_FRAGMENT_YCBCRTORGBA));
    gl.linkProgram(this.program);

    if( !gl.getProgramParameter(this.program, gl.LINK_STATUS) ) {
        throw new Error(gl.getProgramInfoLog(this.program));
    }

    gl.useProgram(this.program);

    // setup textures
    this.YTexture = this.createTexture(0, 'YTexture');
    this.CBTexture = this.createTexture(1, 'CBTexture');
    this.CRTexture = this.createTexture(2, 'CRTexture');

    var vertexAttr = gl.getAttribLocation(this.program, 'vertex');
    gl.enableVertexAttribArray(vertexAttr);
    gl.vertexAttribPointer(vertexAttr, 2, gl.FLOAT, false, 0, 0);


    // Shader for the loading screen
    this.loadingProgram = gl.createProgram();
    gl.attachShader(this.loadingProgram, this.compileShader(gl.VERTEX_SHADER, SHADER_VERTEX_IDENTITY));
    gl.attachShader(this.loadingProgram, this.compileShader(gl.FRAGMENT_SHADER, SHADER_FRAGMENT_LOADING));
    gl.linkProgram(this.loadingProgram);

    gl.useProgram(this.loadingProgram);

    vertexAttr = gl.getAttribLocation(this.loadingProgram, 'vertex');
    gl.enableVertexAttribArray(vertexAttr);
    gl.vertexAttribPointer(vertexAttr, 2, gl.FLOAT, false, 0, 0);

    return true;
};

jsmpeg.prototype.renderFrameGL = function() {
    var gl = this.gl;

    // WebGL doesn't like Uint8ClampedArrays, so we have to create a Uint8Array view for
    // each plane
    var uint8Y = new Uint8Array(this.currentY.buffer),
        uint8Cr = new Uint8Array(this.currentCr.buffer),
        uint8Cb = new Uint8Array(this.currentCb.buffer);

    // return;

    gl.activeTexture(gl.TEXTURE0);
    gl.bindTexture(gl.TEXTURE_2D, this.YTexture);

    gl.texImage2D(gl.TEXTURE_2D, 0, gl.LUMINANCE, this.codedWidth, this.height, 0, gl.LUMINANCE, gl.UNSIGNED_BYTE, uint8Y);

    gl.activeTexture(gl.TEXTURE1);
    gl.bindTexture(gl.TEXTURE_2D, this.CBTexture);
    gl.texImage2D(gl.TEXTURE_2D, 0, gl.LUMINANCE, this.halfWidth, this.height/2, 0, gl.LUMINANCE, gl.UNSIGNED_BYTE, uint8Cr);

    gl.activeTexture(gl.TEXTURE2);
    gl.bindTexture(gl.TEXTURE_2D, this.CRTexture);
    gl.texImage2D(gl.TEXTURE_2D, 0, gl.LUMINANCE, this.halfWidth, this.height/2, 0, gl.LUMINANCE, gl.UNSIGNED_BYTE, uint8Cb);

    gl.drawArrays(gl.TRIANGLE_STRIP, 0, 4);
};


// ----------------------------------------------------------------------------
// Slice Layer

jsmpeg.prototype.quantizerScale = 0;
jsmpeg.prototype.sliceBegin = false;

jsmpeg.prototype.decodeSlice = function(slice) {
    this.sliceBegin = true;
    this.macroblockAddress = (slice - 1) * this.mbWidth - 1;

    // Reset motion vectors and DC predictors
    this.motionFwH = this.motionFwHPrev = 0;
    this.motionFwV = this.motionFwVPrev = 0;
    this.dcPredictorY  = 128;
    this.dcPredictorCr = 128;
    this.dcPredictorCb = 128;

    this.quantizerScale = this.buffer.getBits(5);

    // skip extra bits
    while( this.buffer.getBits(1) ) {
        this.buffer.advance(8);
    }

    do {
        this.decodeMacroblock();
        // We may have to ignore Video Stream Start Codes here (0xE0)!?
    } while( !this.buffer.nextBytesAreStartCode() );
};


// ----------------------------------------------------------------------------
// Macroblock Layer

jsmpeg.prototype.macroblockAddress = 0;
jsmpeg.prototype.mbRow = 0;
jsmpeg.prototype.mbCol = 0;

jsmpeg.prototype.macroblockType = 0;
jsmpeg.prototype.macroblockIntra = false;
jsmpeg.prototype.macroblockMotFw = false;

jsmpeg.prototype.motionFwH = 0;
jsmpeg.prototype.motionFwV = 0;
jsmpeg.prototype.motionFwHPrev = 0;
jsmpeg.prototype.motionFwVPrev = 0;

jsmpeg.prototype.decodeMacroblock = function() {
    // Decode macroblock_address_increment
    var
        increment = 0,
        t = this.readCode(MACROBLOCK_ADDRESS_INCREMENT);

    while( t === 34 ) {
        // macroblock_stuffing
        t = this.readCode(MACROBLOCK_ADDRESS_INCREMENT);
    }
    while( t === 35 ) {
        // macroblock_escape
        increment += 33;
        t = this.readCode(MACROBLOCK_ADDRESS_INCREMENT);
    }
    increment += t;

    // Process any skipped macroblocks
    if( this.sliceBegin ) {
        // The first macroblock_address_increment of each slice is relative
        // to beginning of the preverious row, not the preverious macroblock
        this.sliceBegin = false;
        this.macroblockAddress += increment;
    }
    else {
        if( this.macroblockAddress + increment >= this.mbSize ) {
            // Illegal (too large) macroblock_address_increment
            return;
        }
        if( increment > 1 ) {
            // Skipped macroblocks reset DC predictors
            this.dcPredictorY  = 128;
            this.dcPredictorCr = 128;
            this.dcPredictorCb = 128;

            // Skipped macroblocks in P-pictures reset motion vectors
            if( this.pictureCodingType === PICTURE_TYPE_P ) {
                this.motionFwH = this.motionFwHPrev = 0;
                this.motionFwV = this.motionFwVPrev = 0;
            }
        }

        // Predict skipped macroblocks
        while( increment > 1) {
            this.macroblockAddress++;
            this.mbRow = (this.macroblockAddress / this.mbWidth)|0;
            this.mbCol = this.macroblockAddress % this.mbWidth;
            this.copyMacroblock(this.motionFwH, this.motionFwV, this.forwardY, this.forwardCr, this.forwardCb);
            increment--;
        }
        this.macroblockAddress++;
    }
    this.mbRow = (this.macroblockAddress / this.mbWidth)|0;
    this.mbCol = this.macroblockAddress % this.mbWidth;

    // Process the current macroblock
    this.macroblockType = this.readCode(MACROBLOCK_TYPE_TABLES[this.pictureCodingType]);
    this.macroblockIntra = (this.macroblockType & 0x01);
    this.macroblockMotFw = (this.macroblockType & 0x08);

    // Quantizer scale
    if( (this.macroblockType & 0x10) !== 0 ) {
        this.quantizerScale = this.buffer.getBits(5);
    }

    if( this.macroblockIntra ) {
        // Intra-coded macroblocks reset motion vectors
        this.motionFwH = this.motionFwHPrev = 0;
        this.motionFwV = this.motionFwVPrev = 0;
    }
    else {
        // Non-intra macroblocks reset DC predictors
        this.dcPredictorY = 128;
        this.dcPredictorCr = 128;
        this.dcPredictorCb = 128;

        this.decodeMotionVectors();
        this.copyMacroblock(this.motionFwH, this.motionFwV, this.forwardY, this.forwardCr, this.forwardCb);
    }

    // Decode blocks
    var cbp = ((this.macroblockType & 0x02) !== 0)
        ? this.readCode(CODE_BLOCK_PATTERN)
        : (this.macroblockIntra ? 0x3f : 0);

    for( var block = 0, mask = 0x20; block < 6; block++ ) {
        if( (cbp & mask) !== 0 ) {
            this.decodeBlock(block);
        }
        mask >>= 1;
    }
};


jsmpeg.prototype.decodeMotionVectors = function() {
    var code, d, r = 0;

    // Forward
    if( this.macroblockMotFw ) {
        // Horizontal forward
        code = this.readCode(MOTION);
        if( (code !== 0) && (this.forwardF !== 1) ) {
            r = this.buffer.getBits(this.forwardRSize);
            d = ((Math.abs(code) - 1) << this.forwardRSize) + r + 1;
            if( code < 0 ) {
                d = -d;
            }
        }
        else {
            d = code;
        }

        this.motionFwHPrev += d;
        if( this.motionFwHPrev > (this.forwardF << 4) - 1 ) {
            this.motionFwHPrev -= this.forwardF << 5;
        }
        else if( this.motionFwHPrev < ((-this.forwardF) << 4) ) {
            this.motionFwHPrev += this.forwardF << 5;
        }

        this.motionFwH = this.motionFwHPrev;
        if( this.fullPelForward ) {
            this.motionFwH <<= 1;
        }

        // Vertical forward
        code = this.readCode(MOTION);
        if( (code !== 0) && (this.forwardF !== 1) ) {
            r = this.buffer.getBits(this.forwardRSize);
            d = ((Math.abs(code) - 1) << this.forwardRSize) + r + 1;
            if( code < 0 ) {
                d = -d;
            }
        }
        else {
            d = code;
        }

        this.motionFwVPrev += d;
        if( this.motionFwVPrev > (this.forwardF << 4) - 1 ) {
            this.motionFwVPrev -= this.forwardF << 5;
        }
        else if( this.motionFwVPrev < ((-this.forwardF) << 4) ) {
            this.motionFwVPrev += this.forwardF << 5;
        }

        this.motionFwV = this.motionFwVPrev;
        if( this.fullPelForward ) {
            this.motionFwV <<= 1;
        }
    }
    else if( this.pictureCodingType === PICTURE_TYPE_P ) {
        // No motion information in P-picture, reset vectors
        this.motionFwH = this.motionFwHPrev = 0;
        this.motionFwV = this.motionFwVPrev = 0;
    }
};

jsmpeg.prototype.copyMacroblock = function(motionH, motionV, sY, sCr, sCb ) {
    var
        width, scan,
        H, V, oddH, oddV,
        src, dest, last;

    // We use 32bit writes here
    var dY = this.currentY32;
    var dCb = this.currentCb32;
    var dCr = this.currentCr32;

    // Luminance
    width = this.codedWidth;
    scan = width - 16;

    H = motionH >> 1;
    V = motionV >> 1;
    oddH = (motionH & 1) === 1;
    oddV = (motionV & 1) === 1;

    src = ((this.mbRow << 4) + V) * width + (this.mbCol << 4) + H;
    dest = (this.mbRow * width + this.mbCol) << 2;
    last = dest + (width << 2);

    var x;
    var y1, y2, y;
    if( oddH ) {
        if( oddV ) {
            while( dest < last ) {
                y1 = sY[src] + sY[src+width]; src++;
                for( x = 0; x < 4; x++ ) {
                    y2 = sY[src] + sY[src+width]; src++;
                    y = (((y1 + y2 + 2) >> 2) & 0xff);

                    y1 = sY[src] + sY[src+width]; src++;
                    y |= (((y1 + y2 + 2) << 6) & 0xff00);

                    y2 = sY[src] + sY[src+width]; src++;
                    y |= (((y1 + y2 + 2) << 14) & 0xff0000);

                    y1 = sY[src] + sY[src+width]; src++;
                    y |= (((y1 + y2 + 2) << 22) & 0xff000000);

                    dY[dest++] = y;
                }
                dest += scan >> 2; src += scan-1;
            }
        }
        else {
            while( dest < last ) {
                y1 = sY[src++];
                for( x = 0; x < 4; x++ ) {
                    y2 = sY[src++];
                    y = (((y1 + y2 + 1) >> 1) & 0xff);

                    y1 = sY[src++];
                    y |= (((y1 + y2 + 1) << 7) & 0xff00);

                    y2 = sY[src++];
                    y |= (((y1 + y2 + 1) << 15) & 0xff0000);

                    y1 = sY[src++];
                    y |= (((y1 + y2 + 1) << 23) & 0xff000000);

                    dY[dest++] = y;
                }
                dest += scan >> 2; src += scan-1;
            }
        }
    }
    else {
        if( oddV ) {
            while( dest < last ) {
                for( x = 0; x < 4; x++ ) {
                    y = (((sY[src] + sY[src+width] + 1) >> 1) & 0xff); src++;
                    y |= (((sY[src] + sY[src+width] + 1) << 7) & 0xff00); src++;
                    y |= (((sY[src] + sY[src+width] + 1) << 15) & 0xff0000); src++;
                    y |= (((sY[src] + sY[src+width] + 1) << 23) & 0xff000000); src++;

                    dY[dest++] = y;
                }
                dest += scan >> 2; src += scan;
            }
        }
        else {
            while( dest < last ) {
                for( x = 0; x < 4; x++ ) {
                    y = sY[src]; src++;
                    y |= sY[src] << 8; src++;
                    y |= sY[src] << 16; src++;
                    y |= sY[src] << 24; src++;

                    dY[dest++] = y;
                }
                dest += scan >> 2; src += scan;
            }
        }
    }

    // Chrominance

    width = this.halfWidth;
    scan = width - 8;

    H = (motionH/2) >> 1;
    V = (motionV/2) >> 1;
    oddH = ((motionH/2) & 1) === 1;
    oddV = ((motionV/2) & 1) === 1;

    src = ((this.mbRow << 3) + V) * width + (this.mbCol << 3) + H;
    dest = (this.mbRow * width + this.mbCol) << 1;
    last = dest + (width << 1);

    var cr1, cr2, cr;
    var cb1, cb2, cb;
    if( oddH ) {
        if( oddV ) {
            while( dest < last ) {
                cr1 = sCr[src] + sCr[src+width];
                cb1 = sCb[src] + sCb[src+width];
                src++;
                for( x = 0; x < 2; x++ ) {
                    cr2 = sCr[src] + sCr[src+width];
                    cb2 = sCb[src] + sCb[src+width]; src++;
                    cr = (((cr1 + cr2 + 2) >> 2) & 0xff);
                    cb = (((cb1 + cb2 + 2) >> 2) & 0xff);

                    cr1 = sCr[src] + sCr[src+width];
                    cb1 = sCb[src] + sCb[src+width]; src++;
                    cr |= (((cr1 + cr2 + 2) << 6) & 0xff00);
                    cb |= (((cb1 + cb2 + 2) << 6) & 0xff00);

                    cr2 = sCr[src] + sCr[src+width];
                    cb2 = sCb[src] + sCb[src+width]; src++;
                    cr |= (((cr1 + cr2 + 2) << 14) & 0xff0000);
                    cb |= (((cb1 + cb2 + 2) << 14) & 0xff0000);

                    cr1 = sCr[src] + sCr[src+width];
                    cb1 = sCb[src] + sCb[src+width]; src++;
                    cr |= (((cr1 + cr2 + 2) << 22) & 0xff000000);
                    cb |= (((cb1 + cb2 + 2) << 22) & 0xff000000);

                    dCr[dest] = cr;
                    dCb[dest] = cb;
                    dest++;
                }
                dest += scan >> 2; src += scan-1;
            }
        }
        else {
            while( dest < last ) {
                cr1 = sCr[src];
                cb1 = sCb[src];
                src++;
                for( x = 0; x < 2; x++ ) {
                    cr2 = sCr[src];
                    cb2 = sCb[src++];
                    cr = (((cr1 + cr2 + 1) >> 1) & 0xff);
                    cb = (((cb1 + cb2 + 1) >> 1) & 0xff);

                    cr1 = sCr[src];
                    cb1 = sCb[src++];
                    cr |= (((cr1 + cr2 + 1) << 7) & 0xff00);
                    cb |= (((cb1 + cb2 + 1) << 7) & 0xff00);

                    cr2 = sCr[src];
                    cb2 = sCb[src++];
                    cr |= (((cr1 + cr2 + 1) << 15) & 0xff0000);
                    cb |= (((cb1 + cb2 + 1) << 15) & 0xff0000);

                    cr1 = sCr[src];
                    cb1 = sCb[src++];
                    cr |= (((cr1 + cr2 + 1) << 23) & 0xff000000);
                    cb |= (((cb1 + cb2 + 1) << 23) & 0xff000000);

                    dCr[dest] = cr;
                    dCb[dest] = cb;
                    dest++;
                }
                dest += scan >> 2; src += scan-1;
            }
        }
    }
    else {
        if( oddV ) {
            while( dest < last ) {
                for( x = 0; x < 2; x++ ) {
                    cr = (((sCr[src] + sCr[src+width] + 1) >> 1) & 0xff);
                    cb = (((sCb[src] + sCb[src+width] + 1) >> 1) & 0xff); src++;

                    cr |= (((sCr[src] + sCr[src+width] + 1) << 7) & 0xff00);
                    cb |= (((sCb[src] + sCb[src+width] + 1) << 7) & 0xff00); src++;

                    cr |= (((sCr[src] + sCr[src+width] + 1) << 15) & 0xff0000);
                    cb |= (((sCb[src] + sCb[src+width] + 1) << 15) & 0xff0000); src++;

                    cr |= (((sCr[src] + sCr[src+width] + 1) << 23) & 0xff000000);
                    cb |= (((sCb[src] + sCb[src+width] + 1) << 23) & 0xff000000); src++;

                    dCr[dest] = cr;
                    dCb[dest] = cb;
                    dest++;
                }
                dest += scan >> 2; src += scan;
            }
        }
        else {
            while( dest < last ) {
                for( x = 0; x < 2; x++ ) {
                    cr = sCr[src];
                    cb = sCb[src]; src++;

                    cr |= sCr[src] << 8;
                    cb |= sCb[src] << 8; src++;

                    cr |= sCr[src] << 16;
                    cb |= sCb[src] << 16; src++;

                    cr |= sCr[src] << 24;
                    cb |= sCb[src] << 24; src++;

                    dCr[dest] = cr;
                    dCb[dest] = cb;
                    dest++;
                }
                dest += scan >> 2; src += scan;
            }
        }
    }
};


// ----------------------------------------------------------------------------
// Block layer

//jsmpeg.prototype.dcPredictorY;
//jsmpeg.prototype.dcPredictorCr;
//jsmpeg.prototype.dcPredictorCb;

jsmpeg.prototype.blockData = null;
jsmpeg.prototype.decodeBlock = function(block) {

    var
        n = 0,
        quantMatrix;

    // Decode DC coefficient of intra-coded blocks
    if( this.macroblockIntra ) {
        var
            predictor,
            dctSize;

        // DC prediction

        if( block < 4 ) {
            predictor = this.dcPredictorY;
            dctSize = this.readCode(DCT_DC_SIZE_LUMINANCE);
        }
        else {
            predictor = (block === 4 ? this.dcPredictorCr : this.dcPredictorCb);
            dctSize = this.readCode(DCT_DC_SIZE_CHROMINANCE);
        }

        // Read DC coeff
        if( dctSize > 0 ) {
            var differential = this.buffer.getBits(dctSize);
            if( (differential & (1 << (dctSize - 1))) !== 0 ) {
                this.blockData[0] = predictor + differential;
            }
            else {
                this.blockData[0] = predictor + ((-1 << dctSize)|(differential+1));
            }
        }
        else {
            this.blockData[0] = predictor;
        }

        // Save predictor value
        if( block < 4 ) {
            this.dcPredictorY = this.blockData[0];
        }
        else if( block === 4 ) {
            this.dcPredictorCr = this.blockData[0];
        }
        else {
            this.dcPredictorCb = this.blockData[0];
        }

        // Dequantize + premultiply
        this.blockData[0] <<= (3 + 5);

        quantMatrix = this.intraQuantMatrix;
        n = 1;
    }
    else {
        quantMatrix = this.nonIntraQuantMatrix;
    }

    // Decode AC coefficients (+DC for non-intra)
    var level = 0;
    while( true ) {
        var
            run = 0,
            coeff = this.readCode(DCT_COEFF);

        if( (coeff === 0x0001) && (n > 0) && (this.buffer.getBits(1) === 0) ) {
            // end_of_block
            break;
        }
        if( coeff === 0xffff ) {
            // escape
            run = this.buffer.getBits(6);
            level = this.buffer.getBits(8);
            if( level === 0 ) {
                level = this.buffer.getBits(8);
            }
            else if( level === 128 ) {
                level = this.buffer.getBits(8) - 256;
            }
            else if( level > 128 ) {
                level = level - 256;
            }
        }
        else {
            run = coeff >> 8;
            level = coeff & 0xff;
            if( this.buffer.getBits(1) ) {
                level = -level;
            }
        }

        n += run;
        var dezigZagged = ZIG_ZAG[n];
        n++;

        // Dequantize, oddify, clip
        level <<= 1;
        if( !this.macroblockIntra ) {
            level += (level < 0 ? -1 : 1);
        }
        level = (level * this.quantizerScale * quantMatrix[dezigZagged]) >> 4;
        if( (level & 1) === 0 ) {
            level -= level > 0 ? 1 : -1;
        }
        if( level > 2047 ) {
            level = 2047;
        }
        else if( level < -2048 ) {
            level = -2048;
        }

        // Save premultiplied coefficient
        this.blockData[dezigZagged] = level * PREMULTIPLIER_MATRIX[dezigZagged];
    }

    // Move block to its place
    var
        destArray,
        destIndex,
        scan;

    if( block < 4 ) {
        destArray = this.currentY;
        scan = this.codedWidth - 8;
        destIndex = (this.mbRow * this.codedWidth + this.mbCol) << 4;
        if( (block & 1) !== 0 ) {
            destIndex += 8;
        }
        if( (block & 2) !== 0 ) {
            destIndex += this.codedWidth << 3;
        }
    }
    else {
        destArray = (block === 4) ? this.currentCb : this.currentCr;
        scan = (this.codedWidth >> 1) - 8;
        destIndex = ((this.mbRow * this.codedWidth) << 2) + (this.mbCol << 3);
    }

    if( this.macroblockIntra ) {
        // Overwrite (no prediction)
        if (n === 1) {
            this.copyValueToDestination((this.blockData[0] + 128) >> 8, destArray, destIndex, scan);
            this.blockData[0] = 0;
        } else {
            this.IDCT();
            this.copyBlockToDestination(this.blockData, destArray, destIndex, scan);
            this.blockData.set(this.zeroBlockData);
        }
    }
    else {
        // Add data to the predicted macroblock
        if (n === 1) {
            this.addValueToDestination((this.blockData[0] + 128) >> 8, destArray, destIndex, scan);
            this.blockData[0] = 0;
        } else {
            this.IDCT();
            this.addBlockToDestination(this.blockData, destArray, destIndex, scan);
            this.blockData.set(this.zeroBlockData);
        }
    }

    n = 0;
};

jsmpeg.prototype.copyBlockToDestination = function(blockData, destArray, destIndex, scan) {
    for( var n = 0; n < 64; n += 8, destIndex += scan+8 ) {
        destArray[destIndex+0] = blockData[n+0];
        destArray[destIndex+1] = blockData[n+1];
        destArray[destIndex+2] = blockData[n+2];
        destArray[destIndex+3] = blockData[n+3];
        destArray[destIndex+4] = blockData[n+4];
        destArray[destIndex+5] = blockData[n+5];
        destArray[destIndex+6] = blockData[n+6];
        destArray[destIndex+7] = blockData[n+7];
    }
};

jsmpeg.prototype.addBlockToDestination = function(blockData, destArray, destIndex, scan) {
    for( var n = 0; n < 64; n += 8, destIndex += scan+8 ) {
        destArray[destIndex+0] += blockData[n+0];
        destArray[destIndex+1] += blockData[n+1];
        destArray[destIndex+2] += blockData[n+2];
        destArray[destIndex+3] += blockData[n+3];
        destArray[destIndex+4] += blockData[n+4];
        destArray[destIndex+5] += blockData[n+5];
        destArray[destIndex+6] += blockData[n+6];
        destArray[destIndex+7] += blockData[n+7];
    }
};

jsmpeg.prototype.copyValueToDestination = function(value, destArray, destIndex, scan) {
    for( var n = 0; n < 64; n += 8, destIndex += scan+8 ) {
        destArray[destIndex+0] = value;
        destArray[destIndex+1] = value;
        destArray[destIndex+2] = value;
        destArray[destIndex+3] = value;
        destArray[destIndex+4] = value;
        destArray[destIndex+5] = value;
        destArray[destIndex+6] = value;
        destArray[destIndex+7] = value;
    }
};

jsmpeg.prototype.addValueToDestination = function(value, destArray, destIndex, scan) {
    for( var n = 0; n < 64; n += 8, destIndex += scan+8 ) {
        destArray[destIndex+0] += value;
        destArray[destIndex+1] += value;
        destArray[destIndex+2] += value;
        destArray[destIndex+3] += value;
        destArray[destIndex+4] += value;
        destArray[destIndex+5] += value;
        destArray[destIndex+6] += value;
        destArray[destIndex+7] += value;
    }
};

// Clamping version for shitty browsers (IE) that don't support Uint8ClampedArray
jsmpeg.prototype.copyBlockToDestinationClamp = function(blockData, destArray, destIndex, scan) {
    var n = 0;
    for( var i = 0; i < 8; i++ ) {
        for( var j = 0; j < 8; j++ ) {
            var p = blockData[n++];
            destArray[destIndex++] = p > 255 ? 255 : (p < 0 ? 0 : p);
        }
        destIndex += scan;
    }
};

jsmpeg.prototype.addBlockToDestinationClamp = function(blockData, destArray, destIndex, scan) {
    var n = 0;
    for( var i = 0; i < 8; i++ ) {
        for( var j = 0; j < 8; j++ ) {
            var p = blockData[n++] + destArray[destIndex];
            destArray[destIndex++] = p > 255 ? 255 : (p < 0 ? 0 : p);
        }
        destIndex += scan;
    }
};

jsmpeg.prototype.IDCT = function() {
    // See http://vsr.informatik.tu-chemnitz.de/~jan/MPEG/HTML/IDCT.html
    // for more info.

    var
        b1, b3, b4, b6, b7, tmp1, tmp2, m0,
        x0, x1, x2, x3, x4, y3, y4, y5, y6, y7,
        i,
        blockData = this.blockData;

    // Transform columns
    for( i = 0; i < 8; ++i ) {
        b1 =  blockData[4*8+i];
        b3 =  blockData[2*8+i] + blockData[6*8+i];
        b4 =  blockData[5*8+i] - blockData[3*8+i];
        tmp1 = blockData[1*8+i] + blockData[7*8+i];
        tmp2 = blockData[3*8+i] + blockData[5*8+i];
        b6 = blockData[1*8+i] - blockData[7*8+i];
        b7 = tmp1 + tmp2;
        m0 =  blockData[0*8+i];
        x4 =  ((b6*473 - b4*196 + 128) >> 8) - b7;
        x0 =  x4 - (((tmp1 - tmp2)*362 + 128) >> 8);
        x1 =  m0 - b1;
        x2 =  (((blockData[2*8+i] - blockData[6*8+i])*362 + 128) >> 8) - b3;
        x3 =  m0 + b1;
        y3 =  x1 + x2;
        y4 =  x3 + b3;
        y5 =  x1 - x2;
        y6 =  x3 - b3;
        y7 = -x0 - ((b4*473 + b6*196 + 128) >> 8);
        blockData[0*8+i] =  b7 + y4;
        blockData[1*8+i] =  x4 + y3;
        blockData[2*8+i] =  y5 - x0;
        blockData[3*8+i] =  y6 - y7;
        blockData[4*8+i] =  y6 + y7;
        blockData[5*8+i] =  x0 + y5;
        blockData[6*8+i] =  y3 - x4;
        blockData[7*8+i] =  y4 - b7;
    }

    // Transform rows
    for( i = 0; i < 64; i += 8 ) {
        b1 =  blockData[4+i];
        b3 =  blockData[2+i] + blockData[6+i];
        b4 =  blockData[5+i] - blockData[3+i];
        tmp1 = blockData[1+i] + blockData[7+i];
        tmp2 = blockData[3+i] + blockData[5+i];
        b6 = blockData[1+i] - blockData[7+i];
        b7 = tmp1 + tmp2;
        m0 =  blockData[0+i];
        x4 =  ((b6*473 - b4*196 + 128) >> 8) - b7;
        x0 =  x4 - (((tmp1 - tmp2)*362 + 128) >> 8);
        x1 =  m0 - b1;
        x2 =  (((blockData[2+i] - blockData[6+i])*362 + 128) >> 8) - b3;
        x3 =  m0 + b1;
        y3 =  x1 + x2;
        y4 =  x3 + b3;
        y5 =  x1 - x2;
        y6 =  x3 - b3;
        y7 = -x0 - ((b4*473 + b6*196 + 128) >> 8);
        blockData[0+i] =  (b7 + y4 + 128) >> 8;
        blockData[1+i] =  (x4 + y3 + 128) >> 8;
        blockData[2+i] =  (y5 - x0 + 128) >> 8;
        blockData[3+i] =  (y6 - y7 + 128) >> 8;
        blockData[4+i] =  (y6 + y7 + 128) >> 8;
        blockData[5+i] =  (x0 + y5 + 128) >> 8;
        blockData[6+i] =  (y3 - x4 + 128) >> 8;
        blockData[7+i] =  (y4 - b7 + 128) >> 8;
    }
};


// ----------------------------------------------------------------------------
// VLC Tables and Constants

var
    SOCKET_MAGIC_BYTES = 'jsmp',
    DECODE_SKIP_OUTPUT = 1,
    PICTURE_RATE = [
        0.000, 23.976, 24.000, 25.000, 29.970, 30.000, 50.000, 59.940,
        60.000,  0.000,  0.000,  0.000,  0.000,  0.000,  0.000,  0.000
    ],
    ZIG_ZAG = new Uint8Array([
         0,  1,  8, 16,  9,  2,  3, 10,
        17, 24, 32, 25, 18, 11,  4,  5,
        12, 19, 26, 33, 40, 48, 41, 34,
        27, 20, 13,  6,  7, 14, 21, 28,
        35, 42, 49, 56, 57, 50, 43, 36,
        29, 22, 15, 23, 30, 37, 44, 51,
        58, 59, 52, 45, 38, 31, 39, 46,
        53, 60, 61, 54, 47, 55, 62, 63
    ]),
    DEFAULT_INTRA_QUANT_MATRIX = new Uint8Array([
         8, 16, 19, 22, 26, 27, 29, 34,
        16, 16, 22, 24, 27, 29, 34, 37,
        19, 22, 26, 27, 29, 34, 34, 38,
        22, 22, 26, 27, 29, 34, 37, 40,
        22, 26, 27, 29, 32, 35, 40, 48,
        26, 27, 29, 32, 35, 40, 48, 58,
        26, 27, 29, 34, 38, 46, 56, 69,
        27, 29, 35, 38, 46, 56, 69, 83
    ]),
    DEFAULT_NON_INTRA_QUANT_MATRIX = new Uint8Array([
        16, 16, 16, 16, 16, 16, 16, 16,
        16, 16, 16, 16, 16, 16, 16, 16,
        16, 16, 16, 16, 16, 16, 16, 16,
        16, 16, 16, 16, 16, 16, 16, 16,
        16, 16, 16, 16, 16, 16, 16, 16,
        16, 16, 16, 16, 16, 16, 16, 16,
        16, 16, 16, 16, 16, 16, 16, 16,
        16, 16, 16, 16, 16, 16, 16, 16
    ]),

    PREMULTIPLIER_MATRIX = new Uint8Array([
        32, 44, 42, 38, 32, 25, 17,  9,
        44, 62, 58, 52, 44, 35, 24, 12,
        42, 58, 55, 49, 42, 33, 23, 12,
        38, 52, 49, 44, 38, 30, 20, 10,
        32, 44, 42, 38, 32, 25, 17,  9,
        25, 35, 33, 30, 25, 20, 14,  7,
        17, 24, 23, 20, 17, 14,  9,  5,
         9, 12, 12, 10,  9,  7,  5,  2
    ]),

    // MPEG-1 VLC

    //  macroblock_stuffing decodes as 34.
    //  macroblock_escape decodes as 35.

    MACROBLOCK_ADDRESS_INCREMENT = new Int16Array([
         1*3,  2*3,  0, //   0
         3*3,  4*3,  0, //   1  0
           0,    0,  1, //   2  1.
         5*3,  6*3,  0, //   3  00
         7*3,  8*3,  0, //   4  01
         9*3, 10*3,  0, //   5  000
        11*3, 12*3,  0, //   6  001
           0,    0,  3, //   7  010.
           0,    0,  2, //   8  011.
        13*3, 14*3,  0, //   9  0000
        15*3, 16*3,  0, //  10  0001
           0,    0,  5, //  11  0010.
           0,    0,  4, //  12  0011.
        17*3, 18*3,  0, //  13  0000 0
        19*3, 20*3,  0, //  14  0000 1
           0,    0,  7, //  15  0001 0.
           0,    0,  6, //  16  0001 1.
        21*3, 22*3,  0, //  17  0000 00
        23*3, 24*3,  0, //  18  0000 01
        25*3, 26*3,  0, //  19  0000 10
        27*3, 28*3,  0, //  20  0000 11
          -1, 29*3,  0, //  21  0000 000
          -1, 30*3,  0, //  22  0000 001
        31*3, 32*3,  0, //  23  0000 010
        33*3, 34*3,  0, //  24  0000 011
        35*3, 36*3,  0, //  25  0000 100
        37*3, 38*3,  0, //  26  0000 101
           0,    0,  9, //  27  0000 110.
           0,    0,  8, //  28  0000 111.
        39*3, 40*3,  0, //  29  0000 0001
        41*3, 42*3,  0, //  30  0000 0011
        43*3, 44*3,  0, //  31  0000 0100
        45*3, 46*3,  0, //  32  0000 0101
           0,    0, 15, //  33  0000 0110.
           0,    0, 14, //  34  0000 0111.
           0,    0, 13, //  35  0000 1000.
           0,    0, 12, //  36  0000 1001.
           0,    0, 11, //  37  0000 1010.
           0,    0, 10, //  38  0000 1011.
        47*3,   -1,  0, //  39  0000 0001 0
          -1, 48*3,  0, //  40  0000 0001 1
        49*3, 50*3,  0, //  41  0000 0011 0
        51*3, 52*3,  0, //  42  0000 0011 1
        53*3, 54*3,  0, //  43  0000 0100 0
        55*3, 56*3,  0, //  44  0000 0100 1
        57*3, 58*3,  0, //  45  0000 0101 0
        59*3, 60*3,  0, //  46  0000 0101 1
        61*3,   -1,  0, //  47  0000 0001 00
          -1, 62*3,  0, //  48  0000 0001 11
        63*3, 64*3,  0, //  49  0000 0011 00
        65*3, 66*3,  0, //  50  0000 0011 01
        67*3, 68*3,  0, //  51  0000 0011 10
        69*3, 70*3,  0, //  52  0000 0011 11
        71*3, 72*3,  0, //  53  0000 0100 00
        73*3, 74*3,  0, //  54  0000 0100 01
           0,    0, 21, //  55  0000 0100 10.
           0,    0, 20, //  56  0000 0100 11.
           0,    0, 19, //  57  0000 0101 00.
           0,    0, 18, //  58  0000 0101 01.
           0,    0, 17, //  59  0000 0101 10.
           0,    0, 16, //  60  0000 0101 11.
           0,    0, 35, //  61  0000 0001 000. -- macroblock_escape
           0,    0, 34, //  62  0000 0001 111. -- macroblock_stuffing
           0,    0, 33, //  63  0000 0011 000.
           0,    0, 32, //  64  0000 0011 001.
           0,    0, 31, //  65  0000 0011 010.
           0,    0, 30, //  66  0000 0011 011.
           0,    0, 29, //  67  0000 0011 100.
           0,    0, 28, //  68  0000 0011 101.
           0,    0, 27, //  69  0000 0011 110.
           0,    0, 26, //  70  0000 0011 111.
           0,    0, 25, //  71  0000 0100 000.
           0,    0, 24, //  72  0000 0100 001.
           0,    0, 23, //  73  0000 0100 010.
           0,    0, 22  //  74  0000 0100 011.
    ]),

    //  macroblock_type bitmap:
    //    0x10  macroblock_quant
    //    0x08  macroblock_motion_forward
    //    0x04  macroblock_motion_backward
    //    0x02  macrobkock_pattern
    //    0x01  macroblock_intra
    //

    MACROBLOCK_TYPE_I = new Int8Array([
         1*3,  2*3,     0, //   0
          -1,  3*3,     0, //   1  0
           0,    0,  0x01, //   2  1.
           0,    0,  0x11  //   3  01.
    ]),

    MACROBLOCK_TYPE_P = new Int8Array([
         1*3,  2*3,     0, //  0
         3*3,  4*3,     0, //  1  0
           0,    0,  0x0a, //  2  1.
         5*3,  6*3,     0, //  3  00
           0,    0,  0x02, //  4  01.
         7*3,  8*3,     0, //  5  000
           0,    0,  0x08, //  6  001.
         9*3, 10*3,     0, //  7  0000
        11*3, 12*3,     0, //  8  0001
          -1, 13*3,     0, //  9  00000
           0,    0,  0x12, // 10  00001.
           0,    0,  0x1a, // 11  00010.
           0,    0,  0x01, // 12  00011.
           0,    0,  0x11  // 13  000001.
    ]),

    MACROBLOCK_TYPE_B = new Int8Array([
         1*3,  2*3,     0,  //  0
         3*3,  5*3,     0,  //  1  0
         4*3,  6*3,     0,  //  2  1
         8*3,  7*3,     0,  //  3  00
           0,    0,  0x0c,  //  4  10.
         9*3, 10*3,     0,  //  5  01
           0,    0,  0x0e,  //  6  11.
        13*3, 14*3,     0,  //  7  001
        12*3, 11*3,     0,  //  8  000
           0,    0,  0x04,  //  9  010.
           0,    0,  0x06,  // 10  011.
        18*3, 16*3,     0,  // 11  0001
        15*3, 17*3,     0,  // 12  0000
           0,    0,  0x08,  // 13  0010.
           0,    0,  0x0a,  // 14  0011.
          -1, 19*3,     0,  // 15  00000
           0,    0,  0x01,  // 16  00011.
        20*3, 21*3,     0,  // 17  00001
           0,    0,  0x1e,  // 18  00010.
           0,    0,  0x11,  // 19  000001.
           0,    0,  0x16,  // 20  000010.
           0,    0,  0x1a   // 21  000011.
    ]),

    CODE_BLOCK_PATTERN = new Int16Array([
          2*3,   1*3,   0,  //   0
          3*3,   6*3,   0,  //   1  1
          4*3,   5*3,   0,  //   2  0
          8*3,  11*3,   0,  //   3  10
         12*3,  13*3,   0,  //   4  00
          9*3,   7*3,   0,  //   5  01
         10*3,  14*3,   0,  //   6  11
         20*3,  19*3,   0,  //   7  011
         18*3,  16*3,   0,  //   8  100
         23*3,  17*3,   0,  //   9  010
         27*3,  25*3,   0,  //  10  110
         21*3,  28*3,   0,  //  11  101
         15*3,  22*3,   0,  //  12  000
         24*3,  26*3,   0,  //  13  001
            0,     0,  60,  //  14  111.
         35*3,  40*3,   0,  //  15  0000
         44*3,  48*3,   0,  //  16  1001
         38*3,  36*3,   0,  //  17  0101
         42*3,  47*3,   0,  //  18  1000
         29*3,  31*3,   0,  //  19  0111
         39*3,  32*3,   0,  //  20  0110
            0,     0,  32,  //  21  1010.
         45*3,  46*3,   0,  //  22  0001
         33*3,  41*3,   0,  //  23  0100
         43*3,  34*3,   0,  //  24  0010
            0,     0,   4,  //  25  1101.
         30*3,  37*3,   0,  //  26  0011
            0,     0,   8,  //  27  1100.
            0,     0,  16,  //  28  1011.
            0,     0,  44,  //  29  0111 0.
         50*3,  56*3,   0,  //  30  0011 0
            0,     0,  28,  //  31  0111 1.
            0,     0,  52,  //  32  0110 1.
            0,     0,  62,  //  33  0100 0.
         61*3,  59*3,   0,  //  34  0010 1
         52*3,  60*3,   0,  //  35  0000 0
            0,     0,   1,  //  36  0101 1.
         55*3,  54*3,   0,  //  37  0011 1
            0,     0,  61,  //  38  0101 0.
            0,     0,  56,  //  39  0110 0.
         57*3,  58*3,   0,  //  40  0000 1
            0,     0,   2,  //  41  0100 1.
            0,     0,  40,  //  42  1000 0.
         51*3,  62*3,   0,  //  43  0010 0
            0,     0,  48,  //  44  1001 0.
         64*3,  63*3,   0,  //  45  0001 0
         49*3,  53*3,   0,  //  46  0001 1
            0,     0,  20,  //  47  1000 1.
            0,     0,  12,  //  48  1001 1.
         80*3,  83*3,   0,  //  49  0001 10
            0,     0,  63,  //  50  0011 00.
         77*3,  75*3,   0,  //  51  0010 00
         65*3,  73*3,   0,  //  52  0000 00
         84*3,  66*3,   0,  //  53  0001 11
            0,     0,  24,  //  54  0011 11.
            0,     0,  36,  //  55  0011 10.
            0,     0,   3,  //  56  0011 01.
         69*3,  87*3,   0,  //  57  0000 10
         81*3,  79*3,   0,  //  58  0000 11
         68*3,  71*3,   0,  //  59  0010 11
         70*3,  78*3,   0,  //  60  0000 01
         67*3,  76*3,   0,  //  61  0010 10
         72*3,  74*3,   0,  //  62  0010 01
         86*3,  85*3,   0,  //  63  0001 01
         88*3,  82*3,   0,  //  64  0001 00
           -1,  94*3,   0,  //  65  0000 000
         95*3,  97*3,   0,  //  66  0001 111
            0,     0,  33,  //  67  0010 100.
            0,     0,   9,  //  68  0010 110.
        106*3, 110*3,   0,  //  69  0000 100
        102*3, 116*3,   0,  //  70  0000 010
            0,     0,   5,  //  71  0010 111.
            0,     0,  10,  //  72  0010 010.
         93*3,  89*3,   0,  //  73  0000 001
            0,     0,   6,  //  74  0010 011.
            0,     0,  18,  //  75  0010 001.
            0,     0,  17,  //  76  0010 101.
            0,     0,  34,  //  77  0010 000.
        113*3, 119*3,   0,  //  78  0000 011
        103*3, 104*3,   0,  //  79  0000 111
         90*3,  92*3,   0,  //  80  0001 100
        109*3, 107*3,   0,  //  81  0000 110
        117*3, 118*3,   0,  //  82  0001 001
        101*3,  99*3,   0,  //  83  0001 101
         98*3,  96*3,   0,  //  84  0001 110
        100*3,  91*3,   0,  //  85  0001 011
        114*3, 115*3,   0,  //  86  0001 010
        105*3, 108*3,   0,  //  87  0000 101
        112*3, 111*3,   0,  //  88  0001 000
        121*3, 125*3,   0,  //  89  0000 0011
            0,     0,  41,  //  90  0001 1000.
            0,     0,  14,  //  91  0001 0111.
            0,     0,  21,  //  92  0001 1001.
        124*3, 122*3,   0,  //  93  0000 0010
        120*3, 123*3,   0,  //  94  0000 0001
            0,     0,  11,  //  95  0001 1110.
            0,     0,  19,  //  96  0001 1101.
            0,     0,   7,  //  97  0001 1111.
            0,     0,  35,  //  98  0001 1100.
            0,     0,  13,  //  99  0001 1011.
            0,     0,  50,  // 100  0001 0110.
            0,     0,  49,  // 101  0001 1010.
            0,     0,  58,  // 102  0000 0100.
            0,     0,  37,  // 103  0000 1110.
            0,     0,  25,  // 104  0000 1111.
            0,     0,  45,  // 105  0000 1010.
            0,     0,  57,  // 106  0000 1000.
            0,     0,  26,  // 107  0000 1101.
            0,     0,  29,  // 108  0000 1011.
            0,     0,  38,  // 109  0000 1100.
            0,     0,  53,  // 110  0000 1001.
            0,     0,  23,  // 111  0001 0001.
            0,     0,  43,  // 112  0001 0000.
            0,     0,  46,  // 113  0000 0110.
            0,     0,  42,  // 114  0001 0100.
            0,     0,  22,  // 115  0001 0101.
            0,     0,  54,  // 116  0000 0101.
            0,     0,  51,  // 117  0001 0010.
            0,     0,  15,  // 118  0001 0011.
            0,     0,  30,  // 119  0000 0111.
            0,     0,  39,  // 120  0000 0001 0.
            0,     0,  47,  // 121  0000 0011 0.
            0,     0,  55,  // 122  0000 0010 1.
            0,     0,  27,  // 123  0000 0001 1.
            0,     0,  59,  // 124  0000 0010 0.
            0,     0,  31   // 125  0000 0011 1.
    ]),

    MOTION = new Int16Array([
          1*3,   2*3,   0,  //   0
          4*3,   3*3,   0,  //   1  0
            0,     0,   0,  //   2  1.
          6*3,   5*3,   0,  //   3  01
          8*3,   7*3,   0,  //   4  00
            0,     0,  -1,  //   5  011.
            0,     0,   1,  //   6  010.
          9*3,  10*3,   0,  //   7  001
         12*3,  11*3,   0,  //   8  000
            0,     0,   2,  //   9  0010.
            0,     0,  -2,  //  10  0011.
         14*3,  15*3,   0,  //  11  0001
         16*3,  13*3,   0,  //  12  0000
         20*3,  18*3,   0,  //  13  0000 1
            0,     0,   3,  //  14  0001 0.
            0,     0,  -3,  //  15  0001 1.
         17*3,  19*3,   0,  //  16  0000 0
           -1,  23*3,   0,  //  17  0000 00
         27*3,  25*3,   0,  //  18  0000 11
         26*3,  21*3,   0,  //  19  0000 01
         24*3,  22*3,   0,  //  20  0000 10
         32*3,  28*3,   0,  //  21  0000 011
         29*3,  31*3,   0,  //  22  0000 101
           -1,  33*3,   0,  //  23  0000 001
         36*3,  35*3,   0,  //  24  0000 100
            0,     0,  -4,  //  25  0000 111.
         30*3,  34*3,   0,  //  26  0000 010
            0,     0,   4,  //  27  0000 110.
            0,     0,  -7,  //  28  0000 0111.
            0,     0,   5,  //  29  0000 1010.
         37*3,  41*3,   0,  //  30  0000 0100
            0,     0,  -5,  //  31  0000 1011.
            0,     0,   7,  //  32  0000 0110.
         38*3,  40*3,   0,  //  33  0000 0011
         42*3,  39*3,   0,  //  34  0000 0101
            0,     0,  -6,  //  35  0000 1001.
            0,     0,   6,  //  36  0000 1000.
         51*3,  54*3,   0,  //  37  0000 0100 0
         50*3,  49*3,   0,  //  38  0000 0011 0
         45*3,  46*3,   0,  //  39  0000 0101 1
         52*3,  47*3,   0,  //  40  0000 0011 1
         43*3,  53*3,   0,  //  41  0000 0100 1
         44*3,  48*3,   0,  //  42  0000 0101 0
            0,     0,  10,  //  43  0000 0100 10.
            0,     0,   9,  //  44  0000 0101 00.
            0,     0,   8,  //  45  0000 0101 10.
            0,     0,  -8,  //  46  0000 0101 11.
         57*3,  66*3,   0,  //  47  0000 0011 11
            0,     0,  -9,  //  48  0000 0101 01.
         60*3,  64*3,   0,  //  49  0000 0011 01
         56*3,  61*3,   0,  //  50  0000 0011 00
         55*3,  62*3,   0,  //  51  0000 0100 00
         58*3,  63*3,   0,  //  52  0000 0011 10
            0,     0, -10,  //  53  0000 0100 11.
         59*3,  65*3,   0,  //  54  0000 0100 01
            0,     0,  12,  //  55  0000 0100 000.
            0,     0,  16,  //  56  0000 0011 000.
            0,     0,  13,  //  57  0000 0011 110.
            0,     0,  14,  //  58  0000 0011 100.
            0,     0,  11,  //  59  0000 0100 010.
            0,     0,  15,  //  60  0000 0011 010.
            0,     0, -16,  //  61  0000 0011 001.
            0,     0, -12,  //  62  0000 0100 001.
            0,     0, -14,  //  63  0000 0011 101.
            0,     0, -15,  //  64  0000 0011 011.
            0,     0, -11,  //  65  0000 0100 011.
            0,     0, -13   //  66  0000 0011 111.
    ]),

    DCT_DC_SIZE_LUMINANCE = new Int8Array([
          2*3,   1*3, 0,  //   0
          6*3,   5*3, 0,  //   1  1
          3*3,   4*3, 0,  //   2  0
            0,     0, 1,  //   3  00.
            0,     0, 2,  //   4  01.
          9*3,   8*3, 0,  //   5  11
          7*3,  10*3, 0,  //   6  10
            0,     0, 0,  //   7  100.
         12*3,  11*3, 0,  //   8  111
            0,     0, 4,  //   9  110.
            0,     0, 3,  //  10  101.
         13*3,  14*3, 0,  //  11  1111
            0,     0, 5,  //  12  1110.
            0,     0, 6,  //  13  1111 0.
         16*3,  15*3, 0,  //  14  1111 1
         17*3,    -1, 0,  //  15  1111 11
            0,     0, 7,  //  16  1111 10.
            0,     0, 8   //  17  1111 110.
    ]),

    DCT_DC_SIZE_CHROMINANCE = new Int8Array([
          2*3,   1*3, 0,  //   0
          4*3,   3*3, 0,  //   1  1
          6*3,   5*3, 0,  //   2  0
          8*3,   7*3, 0,  //   3  11
            0,     0, 2,  //   4  10.
            0,     0, 1,  //   5  01.
            0,     0, 0,  //   6  00.
         10*3,   9*3, 0,  //   7  111
            0,     0, 3,  //   8  110.
         12*3,  11*3, 0,  //   9  1111
            0,     0, 4,  //  10  1110.
         14*3,  13*3, 0,  //  11  1111 1
            0,     0, 5,  //  12  1111 0.
         16*3,  15*3, 0,  //  13  1111 11
            0,     0, 6,  //  14  1111 10.
         17*3,    -1, 0,  //  15  1111 111
            0,     0, 7,  //  16  1111 110.
            0,     0, 8   //  17  1111 1110.
    ]),

    //  dct_coeff bitmap:
    //    0xff00  run
    //    0x00ff  level

    //  Decoded values are unsigned. Sign bit follows in the stream.

    //  Interpretation of the value 0x0001
    //    for dc_coeff_first:  run=0, level=1
    //    for dc_coeff_next:   If the next bit is 1: run=0, level=1
    //                         If the next bit is 0: end_of_block

    //  escape decodes as 0xffff.

    DCT_COEFF = new Int32Array([
          1*3,   2*3,      0,  //   0
          4*3,   3*3,      0,  //   1  0
            0,     0, 0x0001,  //   2  1.
          7*3,   8*3,      0,  //   3  01
          6*3,   5*3,      0,  //   4  00
         13*3,   9*3,      0,  //   5  001
         11*3,  10*3,      0,  //   6  000
         14*3,  12*3,      0,  //   7  010
            0,     0, 0x0101,  //   8  011.
         20*3,  22*3,      0,  //   9  0011
         18*3,  21*3,      0,  //  10  0001
         16*3,  19*3,      0,  //  11  0000
            0,     0, 0x0201,  //  12  0101.
         17*3,  15*3,      0,  //  13  0010
            0,     0, 0x0002,  //  14  0100.
            0,     0, 0x0003,  //  15  0010 1.
         27*3,  25*3,      0,  //  16  0000 0
         29*3,  31*3,      0,  //  17  0010 0
         24*3,  26*3,      0,  //  18  0001 0
         32*3,  30*3,      0,  //  19  0000 1
            0,     0, 0x0401,  //  20  0011 0.
         23*3,  28*3,      0,  //  21  0001 1
            0,     0, 0x0301,  //  22  0011 1.
            0,     0, 0x0102,  //  23  0001 10.
            0,     0, 0x0701,  //  24  0001 00.
            0,     0, 0xffff,  //  25  0000 01. -- escape
            0,     0, 0x0601,  //  26  0001 01.
         37*3,  36*3,      0,  //  27  0000 00
            0,     0, 0x0501,  //  28  0001 11.
         35*3,  34*3,      0,  //  29  0010 00
         39*3,  38*3,      0,  //  30  0000 11
         33*3,  42*3,      0,  //  31  0010 01
         40*3,  41*3,      0,  //  32  0000 10
         52*3,  50*3,      0,  //  33  0010 010
         54*3,  53*3,      0,  //  34  0010 001
         48*3,  49*3,      0,  //  35  0010 000
         43*3,  45*3,      0,  //  36  0000 001
         46*3,  44*3,      0,  //  37  0000 000
            0,     0, 0x0801,  //  38  0000 111.
            0,     0, 0x0004,  //  39  0000 110.
            0,     0, 0x0202,  //  40  0000 100.
            0,     0, 0x0901,  //  41  0000 101.
         51*3,  47*3,      0,  //  42  0010 011
         55*3,  57*3,      0,  //  43  0000 0010
         60*3,  56*3,      0,  //  44  0000 0001
         59*3,  58*3,      0,  //  45  0000 0011
         61*3,  62*3,      0,  //  46  0000 0000
            0,     0, 0x0a01,  //  47  0010 0111.
            0,     0, 0x0d01,  //  48  0010 0000.
            0,     0, 0x0006,  //  49  0010 0001.
            0,     0, 0x0103,  //  50  0010 0101.
            0,     0, 0x0005,  //  51  0010 0110.
            0,     0, 0x0302,  //  52  0010 0100.
            0,     0, 0x0b01,  //  53  0010 0011.
            0,     0, 0x0c01,  //  54  0010 0010.
         76*3,  75*3,      0,  //  55  0000 0010 0
         67*3,  70*3,      0,  //  56  0000 0001 1
         73*3,  71*3,      0,  //  57  0000 0010 1
         78*3,  74*3,      0,  //  58  0000 0011 1
         72*3,  77*3,      0,  //  59  0000 0011 0
         69*3,  64*3,      0,  //  60  0000 0001 0
         68*3,  63*3,      0,  //  61  0000 0000 0
         66*3,  65*3,      0,  //  62  0000 0000 1
         81*3,  87*3,      0,  //  63  0000 0000 01
         91*3,  80*3,      0,  //  64  0000 0001 01
         82*3,  79*3,      0,  //  65  0000 0000 11
         83*3,  86*3,      0,  //  66  0000 0000 10
         93*3,  92*3,      0,  //  67  0000 0001 10
         84*3,  85*3,      0,  //  68  0000 0000 00
         90*3,  94*3,      0,  //  69  0000 0001 00
         88*3,  89*3,      0,  //  70  0000 0001 11
            0,     0, 0x0203,  //  71  0000 0010 11.
            0,     0, 0x0104,  //  72  0000 0011 00.
            0,     0, 0x0007,  //  73  0000 0010 10.
            0,     0, 0x0402,  //  74  0000 0011 11.
            0,     0, 0x0502,  //  75  0000 0010 01.
            0,     0, 0x1001,  //  76  0000 0010 00.
            0,     0, 0x0f01,  //  77  0000 0011 01.
            0,     0, 0x0e01,  //  78  0000 0011 10.
        105*3, 107*3,      0,  //  79  0000 0000 111
        111*3, 114*3,      0,  //  80  0000 0001 011
        104*3,  97*3,      0,  //  81  0000 0000 010
        125*3, 119*3,      0,  //  82  0000 0000 110
         96*3,  98*3,      0,  //  83  0000 0000 100
           -1, 123*3,      0,  //  84  0000 0000 000
         95*3, 101*3,      0,  //  85  0000 0000 001
        106*3, 121*3,      0,  //  86  0000 0000 101
         99*3, 102*3,      0,  //  87  0000 0000 011
        113*3, 103*3,      0,  //  88  0000 0001 110
        112*3, 116*3,      0,  //  89  0000 0001 111
        110*3, 100*3,      0,  //  90  0000 0001 000
        124*3, 115*3,      0,  //  91  0000 0001 010
        117*3, 122*3,      0,  //  92  0000 0001 101
        109*3, 118*3,      0,  //  93  0000 0001 100
        120*3, 108*3,      0,  //  94  0000 0001 001
        127*3, 136*3,      0,  //  95  0000 0000 0010
        139*3, 140*3,      0,  //  96  0000 0000 1000
        130*3, 126*3,      0,  //  97  0000 0000 0101
        145*3, 146*3,      0,  //  98  0000 0000 1001
        128*3, 129*3,      0,  //  99  0000 0000 0110
            0,     0, 0x0802,  // 100  0000 0001 0001.
        132*3, 134*3,      0,  // 101  0000 0000 0011
        155*3, 154*3,      0,  // 102  0000 0000 0111
            0,     0, 0x0008,  // 103  0000 0001 1101.
        137*3, 133*3,      0,  // 104  0000 0000 0100
        143*3, 144*3,      0,  // 105  0000 0000 1110
        151*3, 138*3,      0,  // 106  0000 0000 1010
        142*3, 141*3,      0,  // 107  0000 0000 1111
            0,     0, 0x000a,  // 108  0000 0001 0011.
            0,     0, 0x0009,  // 109  0000 0001 1000.
            0,     0, 0x000b,  // 110  0000 0001 0000.
            0,     0, 0x1501,  // 111  0000 0001 0110.
            0,     0, 0x0602,  // 112  0000 0001 1110.
            0,     0, 0x0303,  // 113  0000 0001 1100.
            0,     0, 0x1401,  // 114  0000 0001 0111.
            0,     0, 0x0702,  // 115  0000 0001 0101.
            0,     0, 0x1101,  // 116  0000 0001 1111.
            0,     0, 0x1201,  // 117  0000 0001 1010.
            0,     0, 0x1301,  // 118  0000 0001 1001.
        148*3, 152*3,      0,  // 119  0000 0000 1101
            0,     0, 0x0403,  // 120  0000 0001 0010.
        153*3, 150*3,      0,  // 121  0000 0000 1011
            0,     0, 0x0105,  // 122  0000 0001 1011.
        131*3, 135*3,      0,  // 123  0000 0000 0001
            0,     0, 0x0204,  // 124  0000 0001 0100.
        149*3, 147*3,      0,  // 125  0000 0000 1100
        172*3, 173*3,      0,  // 126  0000 0000 0101 1
        162*3, 158*3,      0,  // 127  0000 0000 0010 0
        170*3, 161*3,      0,  // 128  0000 0000 0110 0
        168*3, 166*3,      0,  // 129  0000 0000 0110 1
        157*3, 179*3,      0,  // 130  0000 0000 0101 0
        169*3, 167*3,      0,  // 131  0000 0000 0001 0
        174*3, 171*3,      0,  // 132  0000 0000 0011 0
        178*3, 177*3,      0,  // 133  0000 0000 0100 1
        156*3, 159*3,      0,  // 134  0000 0000 0011 1
        164*3, 165*3,      0,  // 135  0000 0000 0001 1
        183*3, 182*3,      0,  // 136  0000 0000 0010 1
        175*3, 176*3,      0,  // 137  0000 0000 0100 0
            0,     0, 0x0107,  // 138  0000 0000 1010 1.
            0,     0, 0x0a02,  // 139  0000 0000 1000 0.
            0,     0, 0x0902,  // 140  0000 0000 1000 1.
            0,     0, 0x1601,  // 141  0000 0000 1111 1.
            0,     0, 0x1701,  // 142  0000 0000 1111 0.
            0,     0, 0x1901,  // 143  0000 0000 1110 0.
            0,     0, 0x1801,  // 144  0000 0000 1110 1.
            0,     0, 0x0503,  // 145  0000 0000 1001 0.
            0,     0, 0x0304,  // 146  0000 0000 1001 1.
            0,     0, 0x000d,  // 147  0000 0000 1100 1.
            0,     0, 0x000c,  // 148  0000 0000 1101 0.
            0,     0, 0x000e,  // 149  0000 0000 1100 0.
            0,     0, 0x000f,  // 150  0000 0000 1011 1.
            0,     0, 0x0205,  // 151  0000 0000 1010 0.
            0,     0, 0x1a01,  // 152  0000 0000 1101 1.
            0,     0, 0x0106,  // 153  0000 0000 1011 0.
        180*3, 181*3,      0,  // 154  0000 0000 0111 1
        160*3, 163*3,      0,  // 155  0000 0000 0111 0
        196*3, 199*3,      0,  // 156  0000 0000 0011 10
            0,     0, 0x001b,  // 157  0000 0000 0101 00.
        203*3, 185*3,      0,  // 158  0000 0000 0010 01
        202*3, 201*3,      0,  // 159  0000 0000 0011 11
            0,     0, 0x0013,  // 160  0000 0000 0111 00.
            0,     0, 0x0016,  // 161  0000 0000 0110 01.
        197*3, 207*3,      0,  // 162  0000 0000 0010 00
            0,     0, 0x0012,  // 163  0000 0000 0111 01.
        191*3, 192*3,      0,  // 164  0000 0000 0001 10
        188*3, 190*3,      0,  // 165  0000 0000 0001 11
            0,     0, 0x0014,  // 166  0000 0000 0110 11.
        184*3, 194*3,      0,  // 167  0000 0000 0001 01
            0,     0, 0x0015,  // 168  0000 0000 0110 10.
        186*3, 193*3,      0,  // 169  0000 0000 0001 00
            0,     0, 0x0017,  // 170  0000 0000 0110 00.
        204*3, 198*3,      0,  // 171  0000 0000 0011 01
            0,     0, 0x0019,  // 172  0000 0000 0101 10.
            0,     0, 0x0018,  // 173  0000 0000 0101 11.
        200*3, 205*3,      0,  // 174  0000 0000 0011 00
            0,     0, 0x001f,  // 175  0000 0000 0100 00.
            0,     0, 0x001e,  // 176  0000 0000 0100 01.
            0,     0, 0x001c,  // 177  0000 0000 0100 11.
            0,     0, 0x001d,  // 178  0000 0000 0100 10.
            0,     0, 0x001a,  // 179  0000 0000 0101 01.
            0,     0, 0x0011,  // 180  0000 0000 0111 10.
            0,     0, 0x0010,  // 181  0000 0000 0111 11.
        189*3, 206*3,      0,  // 182  0000 0000 0010 11
        187*3, 195*3,      0,  // 183  0000 0000 0010 10
        218*3, 211*3,      0,  // 184  0000 0000 0001 010
            0,     0, 0x0025,  // 185  0000 0000 0010 011.
        215*3, 216*3,      0,  // 186  0000 0000 0001 000
            0,     0, 0x0024,  // 187  0000 0000 0010 100.
        210*3, 212*3,      0,  // 188  0000 0000 0001 110
            0,     0, 0x0022,  // 189  0000 0000 0010 110.
        213*3, 209*3,      0,  // 190  0000 0000 0001 111
        221*3, 222*3,      0,  // 191  0000 0000 0001 100
        219*3, 208*3,      0,  // 192  0000 0000 0001 101
        217*3, 214*3,      0,  // 193  0000 0000 0001 001
        223*3, 220*3,      0,  // 194  0000 0000 0001 011
            0,     0, 0x0023,  // 195  0000 0000 0010 101.
            0,     0, 0x010b,  // 196  0000 0000 0011 100.
            0,     0, 0x0028,  // 197  0000 0000 0010 000.
            0,     0, 0x010c,  // 198  0000 0000 0011 011.
            0,     0, 0x010a,  // 199  0000 0000 0011 101.
            0,     0, 0x0020,  // 200  0000 0000 0011 000.
            0,     0, 0x0108,  // 201  0000 0000 0011 111.
            0,     0, 0x0109,  // 202  0000 0000 0011 110.
            0,     0, 0x0026,  // 203  0000 0000 0010 010.
            0,     0, 0x010d,  // 204  0000 0000 0011 010.
            0,     0, 0x010e,  // 205  0000 0000 0011 001.
            0,     0, 0x0021,  // 206  0000 0000 0010 111.
            0,     0, 0x0027,  // 207  0000 0000 0010 001.
            0,     0, 0x1f01,  // 208  0000 0000 0001 1011.
            0,     0, 0x1b01,  // 209  0000 0000 0001 1111.
            0,     0, 0x1e01,  // 210  0000 0000 0001 1100.
            0,     0, 0x1002,  // 211  0000 0000 0001 0101.
            0,     0, 0x1d01,  // 212  0000 0000 0001 1101.
            0,     0, 0x1c01,  // 213  0000 0000 0001 1110.
            0,     0, 0x010f,  // 214  0000 0000 0001 0011.
            0,     0, 0x0112,  // 215  0000 0000 0001 0000.
            0,     0, 0x0111,  // 216  0000 0000 0001 0001.
            0,     0, 0x0110,  // 217  0000 0000 0001 0010.
            0,     0, 0x0603,  // 218  0000 0000 0001 0100.
            0,     0, 0x0b02,  // 219  0000 0000 0001 1010.
            0,     0, 0x0e02,  // 220  0000 0000 0001 0111.
            0,     0, 0x0d02,  // 221  0000 0000 0001 1000.
            0,     0, 0x0c02,  // 222  0000 0000 0001 1001.
            0,     0, 0x0f02   // 223  0000 0000 0001 0110.
    ]),

    PICTURE_TYPE_I = 1,
    PICTURE_TYPE_P = 2,
    PICTURE_TYPE_B = 3,
    //PICTURE_TYPE_D = 4,

    START_SEQUENCE = 0xB3,
    START_SLICE_FIRST = 0x01,
    START_SLICE_LAST = 0xAF,
    START_PICTURE = 0x00,
    START_EXTENSION = 0xB5,
    START_USER_DATA = 0xB2,

    // use reserved start code for frame number
    START_FRAME_NUMBER = 0xB0,

    // Shaders for accelerated WebGL YCbCrToRGBA conversion
    SHADER_FRAGMENT_YCBCRTORGBA = [
        'precision mediump float;',
        'uniform sampler2D YTexture;',
        'uniform sampler2D CBTexture;',
        'uniform sampler2D CRTexture;',
        'varying vec2 texCoord;',

        'void main() {',
            'float y = texture2D(YTexture, texCoord).r;',
            'float cr = texture2D(CBTexture, texCoord).r - 0.5;',
            'float cb = texture2D(CRTexture, texCoord).r - 0.5;',

            'gl_FragColor = vec4(',
                'y + 1.4 * cr,',
                'y + -0.343 * cb - 0.711 * cr,',
                'y + 1.765 * cb,',
                '1.0',
            ');',
        '}'
    ].join('\n'),

    SHADER_FRAGMENT_LOADING = [
        'precision mediump float;',
        'uniform float loaded;',
        'varying vec2 texCoord;',

        'void main() {',
            'float c = ceil(loaded-(1.0-texCoord.y));',
            //'float c = ceil(loaded-(1.0-texCoord.y) +sin((texCoord.x+loaded)*16.0)*0.01);', // Fancy wave anim
            'gl_FragColor = vec4(c,c,c,1);',
        '}'
    ].join('\n'),

    SHADER_VERTEX_IDENTITY = [
        'attribute vec2 vertex;',
        'varying vec2 texCoord;',

        'void main() {',
            'texCoord = vertex;',
            'gl_Position = vec4((vertex * 2.0 - 1.0) * vec2(1, -1), 0.0, 1.0);',
        '}'
    ].join('\n');

var MACROBLOCK_TYPE_TABLES = [
    null,
    MACROBLOCK_TYPE_I,
    MACROBLOCK_TYPE_P,
    MACROBLOCK_TYPE_B
];



// ----------------------------------------------------------------------------
// Bit Reader

var BitReader = function(arrayBuffer) {
    this.bytes = new Uint8Array(arrayBuffer);
    this.length = this.bytes.length;
    this.writePos = this.bytes.length;
    this.index = 0;
};

BitReader.NOT_FOUND = -1;

BitReader.prototype.reset = function() {
    this.writePos = 0;
    this.index = 0;
};

BitReader.prototype.findNextMPEGStartCode = function() {
    for( var i = (this.index+7 >> 3); i < this.writePos; i++ ) {
        if(
            this.bytes[i] === 0x00 &&
            this.bytes[i+1] === 0x00 &&
            this.bytes[i+2] === 0x01
        ) {
            this.index = (i+4) << 3;
            return this.bytes[i+3];
        }
    }
    this.index = (this.writePos << 3);
    return BitReader.NOT_FOUND;
};

BitReader.prototype.nextBytesAreStartCode = function() {
    var i = (this.index+7 >> 3);
    return (
        i >= this.writePos || (
            this.bytes[i] === 0x00 &&
            this.bytes[i+1] === 0x00 &&
            this.bytes[i+2] === 0x01
        )
    );
};

BitReader.prototype.nextBits = function(count) {
    var
        byteOffset = this.index >> 3,
        room = (8 - this.index % 8);

    if( room >= count ) {
        return (this.bytes[byteOffset] >> (room - count)) & (0xff >> (8-count));
    }

    var
        leftover = (this.index + count) % 8, // Leftover bits in last byte
        end = (this.index + count -1) >> 3,
        value = this.bytes[byteOffset] & (0xff >> (8-room)); // Fill out first byte

    for( byteOffset++; byteOffset < end; byteOffset++ ) {
        value <<= 8; // Shift and
        value |= this.bytes[byteOffset]; // Put next byte
    }

    if (leftover > 0) {
        value <<= leftover; // Make room for remaining bits
        value |= (this.bytes[byteOffset] >> (8 - leftover));
    }
    else {
        value <<= 8;
        value |= this.bytes[byteOffset];
    }

    return value;
};

BitReader.prototype.getBits = function(count) {
    var value = this.nextBits(count);
    this.index += count;
    return value;
};

BitReader.prototype.advance = function(count) {
    return (this.index += count);
};

BitReader.prototype.rewind = function(count) {
    return (this.index -= count);
};

BitReader.prototype.write = function(data) {
    if(this.writePos + data.length > this.length) {
        // buffer overflow, try to truncate

        if(VERBOSE) {
            console.log("buffer overflow, truncate: index=" + this.index + " writepos=" + this.writePos + " buflen=" + this.length);
        }

        // leave 32 bytes before current pos to allow rewind
        if(!this.truncate(32, data.length)) {
            return false;
        }
    }

    this.bytes.set(data, this.writePos);
    this.writePos += data.length;

    return true;
}

BitReader.prototype.truncate = function(leaveBytes, wantBytes) {
    leaveBytes = leaveBytes || 0;

    // index is a position in bits
    var bytepos = this.index / 8;

    if(bytepos <= leaveBytes) {
        console.log("cannot truncate: index=" + this.index + " bytepos=" + bytepos);
        return false;
    }

    if(wantBytes && bytepos < wantBytes) {
        console.log("cannot truncate: index=" + this.index + " bytepos=" + bytepos + " want=" + wantBytes);
        return false;
    }

    this.bytes.set(this.bytes.subarray(bytepos - leaveBytes, this.writePos));
    this.writePos -= bytepos - leaveBytes;
    this.index = leaveBytes*8;

    if(VERBOSE) {
        console.log("truncate", this.index, bytepos, this.writePos, this.bytes.length);
    }

    return true;
}

////////////////////////////////////////////////////////////////////////////////
// test file play
jsmpeg.prototype.load = function( url ) {
	this.url = url;

	var that = this;
	if(
		this.progressive &&
		window.fetch &&
		window.ReadableByteStream
	) {
		var reqHeaders = new Headers();
		reqHeaders.append('Content-Type', 'video/mpeg');
		fetch(url, {headers: reqHeaders}).then(function (res) {
			var contentLength = res.headers.get('Content-Length');
			var reader = res.body.getReader();

			that.buffer = new BitReader(new ArrayBuffer(contentLength));
			that.buffer.writePos = 0;
			that.fetchReaderPump(reader);
        });
	}
	else {
		var request = new XMLHttpRequest();
		request.onreadystatechange = function() {
			if( request.readyState === request.DONE && request.status === 200 ) {
				that.loadCallback(request.response);
			}
		};

		request.onprogress = this.gl
			? this.updateLoaderGL.bind(this)
			: this.updateLoader2D.bind(this);

		request.open('GET', url);
		request.responseType = 'arraybuffer';
		request.send();
	}
};

jsmpeg.prototype.updateLoader2D = function( ev ) {
	var
		p = ev.loaded / ev.total,
		w = this.canvas.width,
		h = this.canvas.height,
		ctx = this.canvasContext;

	ctx.fillStyle = '#222';
	ctx.fillRect(0, 0, w, h);
	ctx.fillStyle = '#fff';
	ctx.fillRect(0, h - h*p, w, h*p);
};

jsmpeg.prototype.updateLoaderGL = function( ev ) {
	var gl = this.gl;
	gl.uniform1f(gl.getUniformLocation(this.loadingProgram, 'loaded'), (ev.loaded / ev.total));
	gl.drawArrays(gl.TRIANGLE_STRIP, 0, 4);
};


jsmpeg.prototype.loadCallback = function(file) {
    console.log("load done");
	this.buffer = new BitReader(file);

	if( this.seekable ) {
		this.collectIntraFrames();
		this.buffer.index = 0;
	}

	console.log("111");
	this.findStartCode(START_SEQUENCE);
	this.firstSequenceHeader = this.buffer.index;
	this.decodeSequenceHeader();

	console.log("222");

	// Calculate the duration. This only works if the video is seekable and we have a frame count
	this.duration = this.frameCount / this.pictureRate;

	// Load the first frame
	this.nextFrame();

	if( this.autoplay ) {
	    console.log("play");
	    this.stopped = false;
		this.play();
	}

	if( this.externalLoadCallback ) {
		this.externalLoadCallback(this);
	}
};

jsmpeg.prototype.collectIntraFrames = function() {
	// Loop through the whole buffer and collect all intraFrames to build our seek index.
	// We also keep track of total frame count here
	var frame;
	for( frame = 0; this.findStartCode(START_PICTURE) !== BitReader.NOT_FOUND; frame++ ) {

		// Check if the found picture is an intra frame and remember the position
		this.buffer.advance(10); // skip temporalReference
		if( this.buffer.getBits(3) === PICTURE_TYPE_I ) {
			// Remember index 13 bits back, before temporalReference and picture type
			this.intraFrames.push({frame: frame, index: this.buffer.index - 13});
		}
	}

	this.frameCount = frame;
};

jsmpeg.prototype.seekToFrame = function(seekFrame, seekExact) {
	if( seekFrame < 0 || seekFrame >= this.frameCount || !this.intraFrames.length ) {
		return false;
	}

	// Find the last intra frame before or equal to seek frame
	var target = null;
	for( var i = 0; i < this.intraFrames.length && this.intraFrames[i].frame <= seekFrame; i++ ) {
		target = this.intraFrames[i];
	}

	this.buffer.index = target.index;
	this.currentFrame = target.frame-1;

	// If we're seeking to the exact frame, we may have to decode some more frames before
	// the one we want
	if( seekExact ) {
		for( var frame = target.frame; frame < seekFrame; frame++ ) {
			this.decodePicture(DECODE_SKIP_OUTPUT);
			this.findStartCode(START_PICTURE);
		}
		this.currentFrame = seekFrame-1;
	}

	// Decode and display the picture we have seeked to
	this.decodePicture();
	return true;
};

jsmpeg.prototype.seekToTime = function(time, seekExact) {
	this.seekToFrame( (time * this.pictureRate)|0, seekExact );
};
////////////////////////////////////////////////////////////////////////////////

})(window);

/** @suppress{suspiciousCode} */
!function() {

    //require
    if(TorrentStream === undefined) {
        TorrentStream = {};
    }
    var EngineApi = TorrentStream.EngineApi;
    var $ = TorrentStream.jQuery;
    var Q = TorrentStream.Q;
    var MPEGRenderer = TorrentStream.MPEGRenderer;
    var MSERenderer = TorrentStream.MSERenderer;

    var MODULE_NAME = "player-client";
    var DEBUG = true;
    var VERBOSE = true;

    // OUT events (server->client)
    var MSG_FRAME_SETUP = 0,
        MSG_FRAME_DATA = 1,
        MSG_FRAME_CLEANUP = 2,
        MSG_RENDERER_SETUP = 3,
        MSG_MPEG_PACKET = 4,
        MSG_VLC_EVENT = 5,
        MSG_GOT_CHUNK = 6,
        MSG_HANDSHAKE = 7,
        MSG_ENGINE_EVENT = 8,
        MSG_SETUP_PLAYER = 9,
        MSG_LOAD_RESPONSE = 10,
        MSG_SEGMENTER_STOPPED = 11;

    // IN events (client->server)
    var MSG_IN_FRAME_RENDERED = 0,
        MSG_IN_FRAME_RECEIVED = 1,
        MSG_IN_PLAYBACK_STATUS = 3;

    // renderer types
    var RENDERER_FRAME = 0,
        RENDERER_MPEG_WEBSOCKET = 1,
        RENDERER_MSE = 2,
        RENDERER_MPEG_AJAX = 3,
        RENDERER_DIRECT_HTTP = 4;

    // vlc event param types
    var PARAM_TYPE_EMPTY = 0,
        PARAM_TYPE_INT32 = 1,
        PARAM_TYPE_FLOAT = 2;

    // states
    var STATE_IDLE = 0,
        STATE_OPENING = 1,
        STATE_PLAYING = 3,
        STATE_PAUSED = 4,
        STATE_STOPPED = 6;

    // engine events
    var ENGINE_EVENT_STATE = 0,
        ENGINE_EVENT_STATUS = 1,
        ENGINE_EVENT_STOP = 2,
        ENGINE_EVENT_EVENT = 3;

    // libvlc events
    var libvlc_MediaMetaChanged=0,
        libvlc_MediaSubItemAdded=1,
        libvlc_MediaDurationChanged=2,
        libvlc_MediaParsedChanged=3,
        libvlc_MediaFreed=4,
        libvlc_MediaStateChanged=5,
        libvlc_MediaSubItemTreeAdded=6,

        libvlc_MediaPlayerMediaChanged=256,
        libvlc_MediaPlayerNothingSpecial=257,
        libvlc_MediaPlayerOpening=258,
        libvlc_MediaPlayerBuffering=259,
        libvlc_MediaPlayerPlaying=260,
        libvlc_MediaPlayerPaused=261,
        libvlc_MediaPlayerStopped=262,
        libvlc_MediaPlayerForward=263,
        libvlc_MediaPlayerBackward=264,
        libvlc_MediaPlayerEndReached=265,
        libvlc_MediaPlayerEncounteredError=266,
        libvlc_MediaPlayerTimeChanged=267,
        libvlc_MediaPlayerPositionChanged=268,
        libvlc_MediaPlayerSeekableChanged=269,
        libvlc_MediaPlayerPausableChanged=270,
        libvlc_MediaPlayerTitleChanged=271,
        libvlc_MediaPlayerSnapshotTaken=272,
        libvlc_MediaPlayerLengthChanged=273,
        libvlc_MediaPlayerVout=274,
        libvlc_MediaPlayerScrambledChanged=275;

    // array utility
    // see: http://stackoverflow.com/questions/5306680/move-an-array-element-from-one-array-position-to-another
    Array.prototype.move = function (old_index, new_index) {
        if (new_index >= this.length) {
            var k = new_index - this.length;
            while ((k--) + 1) {
                this.push(undefined);
            }
        }
        this.splice(new_index, 0, this.splice(old_index, 1)[0]);
        return this;
    };

    function log() {
        if(DEBUG) {
            var args = Array.prototype.slice.call(arguments);
            args.unshift(MODULE_NAME + ":");
            console.log.apply(console, args);
        }
    }

    function verbose() {
        if(VERBOSE) {
            var args = Array.prototype.slice.call(arguments);
            args.unshift(MODULE_NAME + ":");
            console.log.apply(console, args);
        }
    }

    function readUInt16BE(buf) {
        return (buf[0] << 8) + buf[1];
    }

    function readUInt32BE(buf) {
        return (buf[0]<<24) + (buf[1]<<16) + (buf[2]<<8) + buf[3];
    }

    function readUInt64BE(buf) {
        return (buf[0] * Math.pow(2, 56)) + (buf[1] * Math.pow(2, 48)) + (buf[2] * Math.pow(2, 40)) + (buf[3] * Math.pow(2, 32)) + (buf[4] * Math.pow(2, 24)) + (buf[5]<<16) + (buf[6]<<8) + buf[7];
    }

    function writeUInt32BE(buf, offset, value) {
        for(var i=0,j=3; i<4; i++,j--) {
            buf[i+offset] = (value >> (8*j)) & 0xFF;
        }
    }

    function ab2str(buf) {
        return String.fromCharCode.apply(null, new Uint16Array(buf));
    }

    function parseEngineStatus(str) {
        var i,
            ret = {},
            tmp = str.split("|");

        ret = {
            main: parseSingleEngineStatus(tmp[0])
        };

        if(tmp.length >= 2) {
            ret.ad = parseSingleEngineStatus(tmp[1]);
        }

        for(i=0; i<tmp.length; i++) {
            var s = parseSingleEngineStatus(tmp[i]);
            ret[s.type] = s.payload;
        }

        return ret;
    }

    function parseSingleEngineStatus(str) {
        var i,
            ret = {},
            payload = {},
            tmp = str.split(":");

        if(tmp.length != 2) {
            throw "bad status string"
        }

        ret.type = tmp[0];
        tmp = tmp[1].split(";");

        payload.status = tmp[0];
        i = 1;

        if(payload.status == 'err') {
            payload.error_id = tmp[i++];
            payload.error_message = tmp[i++];
        }
        else if(payload.status == 'check') {
            payload.progress = tmp[i++];
        }
        else if(payload.status == 'prebuf') {
            payload.progress = tmp[i++];
            payload.time = tmp[i++];
        }
        else if(payload.status == 'buf') {
            payload.progress = tmp[i++];
            payload.time = tmp[i++];
        }
        else if(payload.status == 'seekprebuf') {
            payload.progress = tmp[i++];
        }

        if(payload.status != 'idle'
            && payload.status != 'err'
            && payload.status != 'check'
            && payload.status != 'loading'
            && payload.status != 'starting') {
            payload.total_progress = tmp[i++];
            payload.immediate_progress = tmp[i++];
            payload.speed_down = tmp[i++];
            payload.http_speed_down = tmp[i++];
            payload.speed_up = tmp[i++];
            payload.peers = tmp[i++];
            payload.http_peers = tmp[i++];
            payload.downloaded = tmp[i++];
            payload.http_downloaded = tmp[i++];
            payload.uploaded = tmp[i++];
        }

        ret.payload = payload;

        return ret;
    }

    function sendRequest(port, clientId, method, details) {
        details = details || {};

        details.params = details.params || {};
        if(clientId != -1) {
            details.params.client_id = clientId;
        }

        var deferred = Q.defer();
        $.ajax({
            method: "GET",
            url: "http://127.0.0.1:" + port + "/" + method,
            data: details.params,
            dataType: "json",
            timeout: 10000,
            success: function(data, textStatus, xhr) {
                if(data.error) {
                    deferred.reject(data.error);
                }
                else {
                    deferred.resolve(data.result);
                }
            },
            error: function(xhr, textStatus, error) {
                deferred.reject("request failed");
            }
        });

        return deferred.promise;
    }

    function Playlist(player) {
        this.player = player;
        this.items = [];
        this._currentItem = -1;
        this._nextAsyncRequestId = 0;
        this._pendingLoadRequests = {};
    }

    Object.defineProperty(Playlist.prototype, 'itemCount', {
        get: function() {
            return this.items.length;
        }
    });

    Object.defineProperty(Playlist.prototype, 'currentItem', {
        get: function() {
            return this._currentItem;
        },
        set: function(value) {
            this._currentItem = value;
        }
    });

    Playlist.prototype.add = function(descriptor, callback) {
        var requestId = this._nextAsyncRequestId++,
            params = $.extend(descriptor, {
                request_id: requestId
            });

        this._pendingLoadRequests[requestId] = callback;

        this.player.sendRequest("load", {
            params: params,
            onsuccess: function(response) {
                console.log("load:success: response", response);
            },
            onerror: function(error) {
                console.log("load:error", error);
            }
        });
    };

    Playlist.prototype.addRaw = function(descriptor, title) {
        console.log("playlist.addRaw", title, descriptor);

        var item = {
            title: decodeURIComponent(title),
            descriptor: descriptor
        };

        this.items.push(item);
        if(this._currentItem == -1) {
            this._currentItem = 0;
        }
        return this.items.length - 1;
    }

    Playlist.prototype.clear = function() {
        this.items = [];
        this._currentItem = -1;
    };

    Playlist.prototype.play = function(mrl) {
        var self = this,
            idx;

        console.log("playlist.play", mrl);

        if(mrl) {
            idx = this.add(mrl);
            this._currentItem = idx;
        }
        else if(this.items.length) {
            mrl = this.getCurrentMRL();
        }
        else {
            console.log("play: no items");
            return false;
        }

        if(this.player.playing) {
            this.stop(false);
            this.player.playing = false;
        }

        this.player.sendRequest("play", {
            params: mrl,
            onsuccess: function(response) {
                console.log("play:success: response", response);
            },
            onerror: function(error) {
                console.log("play:error", error);
            }
        });

        this.player.playing = true;
    }

    Playlist.prototype.playItem = function(idx) {
        if(typeof idx !== "number") {
            throw "item index must be an integer";
        }

        if(this.items.length == 0) {
            throw "playlist is empty";
        }

        if(idx < 0 || idx >= this.items.length) {
            throw "bad item index";
        }

        this._currentItem = idx;

        this.play();
    }

    Playlist.prototype.advanceItem = function(pos, advance) {
        var oldPos = pos,
            newPos = pos + advance;
        this.items.move(oldPos, newPos);
    };

    Playlist.prototype.stop = function(fullstop) {
        this.player.stop(fullstop);
    }

    Playlist.prototype.pause = function() {
        this.player.pause();
    }

    Playlist.prototype.getCurrentMRL = function() {
        if(this.items.length == 0) {
            return null;
        }

        if(this._currentItem < 0 || this._currentItem >= this.items.length) {
            console.log("getCurrentMRL: fix current item: curr=" + this._currentItem + " items=" + this.items.length);
            this._currentItem = 0;
        }

        return this.items[this._currentItem].descriptor;
    }

    Playlist.prototype.resume = function() {
        var mrl = this.getCurrentMRL();

        log("resume: state=" + this.player.state + " mrl=", mrl);

        if(this.player.state == 4) {
            // unpause
            if(this.player.rendererType == RENDERER_MSE || this.player.rendererType == RENDERER_DIRECT_HTTP) {
                this.player.video.play();
            }
            else {
                this.player.sendRequest("resume");
                this.player.renderer.play();
            }
        }
        else if(this.player.state != 3 && mrl) {
            // restart
            if(this.player.renderer) {
                this.player.renderer.shutdown();
            }
            this.play();
        }
        this.player.playing = true;
    }

    function Player(canvas, video, conf) {
        var self = this;

        // server connection params
        this._conf = conf;
        this._connected = false;
        this._http_ports = conf.http_ports || [6880, 7518, 9213];
        this._https_ports = conf.https_ports || [6881, 7519, 9214];

        //TODO: set default pixel format?
        this.currentPixelFormat = "???";
        this.events = new EventEmitter2();
        this.playlist = new Playlist(this);
        this.websocket_client = null;
        this.currentFrame = null;
        this.canvas = canvas;
        this.video = video;
        this.rendererType = -1;
        this._destroyed = false;

        this.is_live = false;
        this.is_ad = false;
        this.lastLivePos = null;
        this._clientId = -1;
        this.playing = false;
        this.wasStopped = false;
        this.state = STATE_IDLE;
        this.currentPosition = 0;
        this.duration = 0;

        this._volume = 100;
        this._muted = false;
        this._deinterlace = "disabled";
        this._audioChannel = -1;
        this._audioTrackCount = 0;
        this._currentAudioTrack = -1;
        this._audioTracks = [];
        this._subtitlesTrackCount = 0;
        this._currentSubtitlesTrack = -1;
        this._subtitles = [];

        this.idleTimer = null;
        this.idleTimerStartedAt = null;
        this.idleTimerTimeout = null;
        this.idleTimerCallback = null;

        // queue to hold requests until connected
        this.pendingRequests = [];

        ifvisible.on("blur", function() {
            if(self.playing) {
                self.wasStopped = true;
                self.playlist.pause();
                self.startIdleTimer(function() {
                    self.playlist.stop(true);
                }, 60000);
            }
        });

        ifvisible.on("focus", function() {
            self.stopIdleTimer();
            if(self.wasStopped) {
                self.wasStopped = false;
                self.playlist.resume();
            }
        });

        this.connect();
    }

    // static values
    Player.prototype.I420 = "I420";

    Object.defineProperty(Player.prototype, 'pixelFormat', {
        set: function(value) {
            console.log("set pixelFormat", value);
            this.currentPixelFormat = value;
        },
        get: function() {
            return this.currentPixelFormat;
        }
    });

    Object.defineProperty(Player.prototype, 'position', {
        set: function(value) {
            var self = this;

            if(self.is_ad) {
                // cannot seek in ad
                return;
            }

            console.log("set position", value, this.is_ad);
            this.currentPosition = value;

            if(this.rendererType == RENDERER_MSE || this.rendererType == RENDERER_DIRECT_HTTP) {
                this.renderer.reset(true);
            }

            if(this.is_live) {
                var totalPieces = this.lastLivePos.live_last - this.lastLivePos.live_first + 1,
                    pos = parseInt(this.lastLivePos.live_first) + Math.round(totalPieces * value);

                this.sendRequest("live_seek", {
                    params: {
                        value: pos
                    }
                });
            }
            else {
                this.sendRequest("set_position", {
                    params: {
                        value: value
                    }
                }).then(
                    function(response) {
                        if(self.rendererType == RENDERER_MSE) {
                            self.renderer.timeOffset = parseInt(response);
                        }
                    }
                );
            }
        },
        get: function() {
            return this.currentPosition;
        }
    });

    Object.defineProperty(Player.prototype, 'volume', {
        set: function(value) {
            var self = this;

            if(typeof value !== "number") {
                return;
            }

            value = Math.round(value);
            this._volume = value;

            if(this.rendererType == RENDERER_MSE || this.rendererType == RENDERER_DIRECT_HTTP) {
                value /= 200.0;
                verbose("set volume:video: " + value);
                this.video.volume = value;
            }
            else {
                verbose("set volume:player: " + value);
                this.sendRequest("set_volume", {
                    params: {
                        value: value
                    }
                });
            }
        },
        get: function() {
            return this._volume;
        }
    });

    Object.defineProperty(Player.prototype, 'muted', {
        set: function(value) {
            var self = this;

            if(typeof value !== "boolean") {
                return;
            }

            this._muted = value;

            if(this.rendererType == RENDERER_MSE || this.rendererType == RENDERER_DIRECT_HTTP) {
                this.video.muted = value;
            }
            else {
                this.sendRequest("set_muted", {
                    params: {
                        value: value ? 1 : 0
                    }
                });
            }
        },
        get: function() {
            return this._muted;
        }
    });

    Object.defineProperty(Player.prototype, 'deinterlace', {
        get: function() {
            return this._deinterlace;
        }
    });

    Object.defineProperty(Player.prototype, 'audioChannel', {
        set: function(value) {
            var self = this;

            if(typeof value !== "number") {
                return;
            }

            this._audioChannel = value;

            if(this.rendererType == RENDERER_MSE || this.rendererType == RENDERER_DIRECT_HTTP) {
                //TODO: implement
            }
            else {
                this.sendRequest("set_audio_channel", {
                    params: {
                        value: value
                    }
                });
            }
        },
        get: function() {
            return this._audioChannel;
        }
    });

    // audio tracks
    Object.defineProperty(Player.prototype, 'audioTrackCount', {
        get: function() {
            return this._audioTrackCount;
        }
    });

    Object.defineProperty(Player.prototype, 'audioTracks', {
        get: function() {
            return this._audioTracks;
        }
    });

    Object.defineProperty(Player.prototype, 'currentAudioTrack', {
        set: function(value) {
            var self = this;

            if(typeof value !== "number") {
                return;
            }

            this._currentAudioTrack = value;

            if(this.rendererType == RENDERER_MSE || this.rendererType == RENDERER_DIRECT_HTTP) {
                //TODO: implement
            }
            else {
                this.sendRequest("set_current_audio_track", {
                    params: {
                        value: value
                    }
                });
            }
        },
        get: function() {
            return this._currentAudioTrack;
        }
    });

    Object.defineProperty(Player.prototype, 'length', {
        get: function() {
            if(this.rendererType == RENDERER_DIRECT_HTTP) {
                return this.renderer.getDuration();
            }
            else {
                return this.duration;
            }
        }
    });

    // subtitles
    Object.defineProperty(Player.prototype, 'subtitlesTrackCount', {
        get: function() {
            return this._subtitlesTrackCount;
        }
    });

    Object.defineProperty(Player.prototype, 'subtitles', {
        get: function() {
            return this._subtitles;
        }
    });

    Object.defineProperty(Player.prototype, 'currentSubtitlesTrack', {
        set: function(value) {
            var self = this;

            if(typeof value !== "number") {
                return;
            }

            this._currentSubtitlesTrack = value;

            if(this.rendererType == RENDERER_MSE || this.rendererType == RENDERER_DIRECT_HTTP) {
                //TODO: implement
            }
            else {
                this.sendRequest("set_current_subtitles_track", {
                    params: {
                        value: value
                    }
                });
            }
        },
        get: function() {
            return this._currentSubtitlesTrack;
        }
    });

    Player.prototype.liveSeek = function(pos) {
        this.sendRequest("live_seek", {
            params: {
                value: pos
            }
        });
    };

    Player.prototype.requestSkip = function() {
        this.sendPlaybackStatus(101);
    };

    Player.prototype.getRendererType = function() {
        if(this.rendererType === RENDERER_MPEG_AJAX || this.rendererType === RENDERER_MPEG_WEBSOCKET) {
            return "mpeg";
        }
        else if(this.rendererType === RENDERER_MSE || this.rendererType === RENDERER_DIRECT_HTTP) {
            return "mse";
        }
        else {
            return "unknown";
        }
    };

    Player.prototype.connect = function(ports, deferred) {
        var self = this;
        
        if(self._destroyed) {
            return;
        }

        if(ports === undefined) {
            // copy ports array
            ports = self._http_ports.slice();
        }

        this.engineMessage("Connecting...");
        this._connect(ports).then(
            function() {
                self.engineMessage("");
            },
            function(err) {
                log("failed to connect", err);
                // start again
                setTimeout(self.connect.bind(self), 1000);
            }
            );
    }

    Player.prototype._connect = function(ports, deferred) {
        var self = this;

        if(deferred === undefined) {
            deferred = Q.defer();
        }

        if(!ports) {
            deferred.reject("missing ports");
        }
        else if(ports.length == 0) {
            deferred.reject("no more ports");
        }
        else {
            var port = ports.shift();
            sendRequest(port, -1, "get_config").then(
                function(response) {
                    log("connected to port", port);
                    self._http_port = port;

                    log("connect ws: port=" + response.websocket_server_port);

                    self.websocket_client = new WebSocket('ws://127.0.0.1:' + response.websocket_server_port);
                    self.websocket_client.onopen = function() {
                        log("websocket opened");
                        self.websocket_client.binaryType = 'arraybuffer';
                        self.websocket_client.onmessage = self.receiveSocketMessage.bind(self);
                        self._connected = true;
                        deferred.resolve();
                    };
                    self.websocket_client.onclose = function() {
                        log("websocket closed");
                        self._http_port = -1;
                        self._clientId = -1;
                        self._connected = false;
                        self.internalStop();

                        // reconnect
                        self.connect();
                    };
                },
                function(error) {
                    log("connect error");
                    // try to start js player
                    EngineApi.serverRequest("start_js_player").then(
                        function(response) {
                            log("start_js_player", response);
                        },
                        function(err) {
                            log("start_js_player failed", err);
                        }
                        );
                    
                    // try to connect to the next port
                    setTimeout(function() {
                        self._connect(ports, deferred);
                    }, 1000);
                }
            );
        }

        return deferred.promise;
    };
    
    Player.prototype.destroy = function() {
        this._destroyed = true;
        this.stop();
        this.websocket_client.close();
    };

    Player.prototype.sendRequest = function(method, details) {
        if(this._clientId === -1 && method !== "get_config") {
            // server is not connected, queue request
            var deferred = Q.defer();
            this.pendingRequests.push({
                method: method,
                details: details,
                deferred: deferred
            });
            return deferred.promise;
        }
        else {
            return sendRequest(this._http_port, this._clientId, method, details);
        }
    };

    Player.prototype.startIdleTimer = function(callback, timeout) {
        this.stopIdleTimer();

        this.idleTimerStartedAt = Date.now();
        this.idleTimerTimeout = timeout;
        this.idleTimerCallback = callback;
        this.idleTimer = setInterval(this.idleTimerTick.bind(this), 100);
    };

    Player.prototype.stopIdleTimer = function() {
        if(this.idleTimer) {
            clearInterval(this.idleTimer);
            this.idleTimer = null;
            this.idleTimerStartedAt = null;
            this.idleTimerTimeout = null;
            this.idleTimerCallback = null;
        }
    };

    Player.prototype.idleTimerTick = function() {
        var age = Date.now() - this.idleTimerStartedAt;
        console.log("idleTimerTick: age=" + age);

        if(age >= this.idleTimerTimeout) {
            this.idleTimerCallback.call(this);
            this.stopIdleTimer();
        }
    };

    Player.prototype.onFrameRendered = function(frameNumber) {
        var buf = new Uint8Array(5);
        buf[0] = MSG_IN_FRAME_RENDERED;
        writeUInt32BE(buf, 1, frameNumber);
        this.websocket_client.send(buf);
    }

    Player.prototype.sendPlaybackStatus = function(status) {
        var buf = new Uint8Array(5);
        buf[0] = MSG_IN_PLAYBACK_STATUS;
        writeUInt32BE(buf, 1, status);
        this.websocket_client.send(buf);
    }

    Player.prototype.sendPendingRequests = function() {
        for(var i=0; i<this.pendingRequests.length; i++) {
            var req = this.pendingRequests[i];
            this.sendRequest(req.method, req.details);
        }
    };

    Player.prototype.internalStop = function() {
        // set state
        this.playing = false;

        // stop renderer
        if(this.renderer) {
            this.renderer.stop();
        }

        this.setRendererType(-1);
    };

    Player.prototype.stop = function(fullstop) {
        this.internalStop();

        // send "stop" command to player
        if(fullstop === undefined) {
            fullstop = true;
        }
        this.sendRequest("stop", {
            params: {
                fullstop: fullstop ? 1 : 0 // need an integer
            }
        });
    };

    Player.prototype.pause = function() {
        if(this.rendererType == RENDERER_MSE || this.rendererType == RENDERER_DIRECT_HTTP) {
            this.video.pause();
        }
        else {
            this.sendRequest("pause");
            this.renderer.pause();
        }
        this.playing = false;
    };

    Player.prototype.receiveSocketMessage = function(event) {
        var self = this,
            buf = new Uint8Array(event.data),
            type = buf[0];

        buf = buf.subarray(1);

        if(type == MSG_FRAME_SETUP) {
            var pixelFormat = buf[0],
                width = readUInt16BE(buf.subarray(1, 3)),
                height = readUInt16BE(buf.subarray(3, 5)),
                length = readUInt32BE(buf.subarray(5, 9)),
                uOffset = readUInt32BE(buf.subarray(9, 13)),
                vOffset = readUInt32BE(buf.subarray(13, 17));

            console.log("frame setup: format=" + pixelFormat + " w=" + width + " h=" + height + " length=" + length + " u=" + uOffset + " v=" + vOffset);

            this.currentFrame = new Uint8Array(length);
            this.currentFrame.uOffset = uOffset;
            this.currentFrame.vOffset = vOffset;
            this.currentFrame.length = length;

            if(!this.renderer) {
                console.log("frame setup: missing renderer");
                return;
            }

            if(this.rendererType !== RENDERER_FRAME) {
                console.log("frame setup: bad renderer type: " + this.rendererType);
                return;
            }

            this.renderer.onFrameSetup(width, height, pixelFormat, this.currentFrame);

            // emit event to resize canvas
            this.events.emit("FrameSetup", true, width, height);
        }
        else if(type == MSG_FRAME_DATA) {
            this.currentFrame.set(buf);

            if(!this.renderer) {
                console.log("frame setup: missing renderer");
                return;
            }

            if(this.rendererType !== RENDERER_FRAME) {
                console.log("frame setup: bad renderer type: " + this.rendererType);
                return;
            }

            this.renderer.onFrameReady(this.currentFrame);
        }
        else if(type == MSG_FRAME_CLEANUP) {
            console.log("frame cleanup");
            this.currentFrame = null;
        }
        else if(type == MSG_RENDERER_SETUP) {
            var type = buf[0],
                width = readUInt16BE(buf.subarray(1, 3)),
                height = readUInt16BE(buf.subarray(3, 5)),
                duration = readUInt32BE(buf.subarray(5, 9)),
                is_live = buf[9],
                is_ad = buf[10],
                extraData = null,
                playbackUrl = null;

            if(buf.length > 11) {
                try {
                    extraData = JSON.parse(ab2str(buf.subarray(11)));
                }
                catch(e) {
                    console.log("failed to parse extra data: " + e);
                    extraData = null;
                }
            }

            if(type == RENDERER_DIRECT_HTTP) {
                playbackUrl = extraData.playback_url

                // resize to container if dimensions are unknown
                if(width == 0) {
                    width = -1;
                }
                if(height == 0) {
                    height = -1;
                }
            }

            console.log("renderer setup: type=" + type + " w=" + width + " h=" + height + " duration=" + duration + " is_live=" + is_live);

            self.setupRenderer(type, width, height, playbackUrl);

            this.playing = true;
            self.duration = duration;
            self.is_live = is_live;
            self.is_ad = is_ad;

            this.mediaChanged();

            if(is_ad) {
                self.setMode(2, extraData.ad_params);
            }
            else if(is_live) {
                self.setMode(1);
            }
            else {
                self.setMode(0);
            }

            if(duration > 0 && typeof self.onLengthChanged === "function") {
                self.onLengthChanged(duration);
            }
        }
        else if(type == MSG_MPEG_PACKET) {
            if(!this.renderer) {
                console.log("mpeg packet: missing renderer");
                return;
            }

            if(this.rendererType !== RENDERER_MPEG_WEBSOCKET && this.rendererType !== RENDERER_MPEG_AJAX) {
                console.log("mpeg packet: bad renderer type: " + this.rendererType);
                return;
            }

            if(this.rendererType == RENDERER_MPEG_AJAX) {
                var chunkId = readUInt32BE(buf.subarray(0, 4));
                this.gotChunk(chunkId);
            }
            else {
                this.renderer.onVideoPacket(buf);
            }
        }
        else if(type == MSG_GOT_CHUNK) {
            var chunkId = readUInt32BE(buf.subarray(0, 4)),
                discontinuity = buf[4];

            console.log("got chunk: id=" + chunkId + " discontinuity=" + discontinuity);

            if(this.rendererType !== RENDERER_MSE) {
                console.log("got chunk: bad renderer type: " + this.rendererType);
                return;
            }

            this.renderer.gotChunk(chunkId, discontinuity);
        }
        else if(type == MSG_SEGMENTER_STOPPED) {
            var retval = readUInt32BE(buf.subarray(0, 4))

            console.log("segmenter stopped: retval=" + retval);
        }
        else if(type == MSG_VLC_EVENT) {
            var event = readUInt32BE(buf.subarray(0, 4)),
                paramType = buf[4],
                param = null;

            if(paramType == PARAM_TYPE_INT32) {
                param = readUInt32BE(buf.subarray(5, 9));
            }
            else if(paramType == PARAM_TYPE_FLOAT) {
                param = readUInt64BE(buf.subarray(5, 13)) / 1000.0;
            }

            switch(event) {
                case libvlc_MediaStateChanged:
                    break;
                case libvlc_MediaPlayerOpening:
                    this.state = STATE_OPENING;
                    if(typeof this.onOpening === "function") {
                        this.onOpening();
                    }
                    break;
                case libvlc_MediaPlayerBuffering:
                    // if(typeof this.onBuffering === "function") {
                    //     this.onBuffering(param);
                    // }
                    break;
                case libvlc_MediaPlayerPlaying:
                    console.log("libvlc_MediaPlayerPlaying");
                    this.state = STATE_PLAYING;
                    this.playing = true;
                    if(typeof this.onPlaying === "function") {
                        this.onPlaying();
                    }
                    break;
                case libvlc_MediaPlayerPaused:
                    console.log("libvlc_MediaPlayerPaused");
                    this.state = STATE_PAUSED;
                    if(typeof this.onPaused === "function") {
                        this.onPaused();
                    }
                    break;
                case libvlc_MediaPlayerStopped:
                    console.log("libvlc_MediaPlayerStopped");
                    this.state = STATE_STOPPED;
                    if(this.renderer) {
                        this.renderer.stop();
                    }
                    if(typeof this.onStopped === "function") {
                        this.onStopped();
                    }
                    break;
                case libvlc_MediaPlayerEndReached:
                    console.log("libvlc_MediaPlayerEndReached");
                    this.state = STATE_STOPPED;
                    if(this.renderer) {
                        this.renderer.stop();
                    }
                    if(typeof this.onEndReached === "function") {
                        this.onEndReached();
                    }
                    break;
                case libvlc_MediaPlayerPositionChanged:
                    if(!this.is_live) {
                        this.currentPosition = param;
                        if(this.playing && typeof this.onPositionChanged === "function") {
                            this.onPositionChanged(param);
                        }
                    }
                    break;
                case libvlc_MediaPlayerTimeChanged:
                    if(!this.is_live) {
                        if(this.playing && typeof this.onTimeChanged === "function") {
                            this.onTimeChanged(param);
                        }
                    }
                    break;
                case libvlc_MediaPlayerLengthChanged:
                    this.duration = param;
                    if(this.playing && typeof this.onLengthChanged === "function") {
                        this.onLengthChanged(param);
                    }
                    break;
            }
        }
        else if(type === MSG_ENGINE_EVENT) {
            var event = buf[0];

            switch(event) {
                case ENGINE_EVENT_STOP:
                    console.log("got engine event: stop: playing=" + self.playing);
                    if(self.playing) {
                        self.playing = false;
                        if(self.renderer) {
                            self.renderer.stop();
                        }
                    }
                    break;
                case ENGINE_EVENT_STATE:
                    var state = buf[1];
                    console.log("got engine event: state=" + state);
                    break;
                case ENGINE_EVENT_STATUS:
                    var status = ab2str(buf.subarray(1));

                    status = parseEngineStatus(status);
                    if(status.main) {
                        var msg = "";

                        if(status.main.status == "prebuf") {
                            msg = "Prebuffering " + status.main.progress + "% (connected to " + status.main.peers + " streams)";
                        }
                        else if(status.main.status == "check") {
                            msg = "Checking " + status.main.progress + "%";
                        }
                        else if(status.main.status == "starting") {
                            msg = "Starting...";
                        }
                        else if(status.main.status == "seek") {
                            msg = "Seeking...";
                        }
                        else if(status.main.status == "seekprebuf") {
                            msg = "Seeking " + status.main.progress + "%";
                        }
                        this.engineMessage(msg);
                    }

                    break;
                case ENGINE_EVENT_EVENT:
                    var payload = JSON.parse(ab2str(buf.subarray(1)));
                    if(payload.livepos) {
                        var position,
                            e = payload.livepos,
                            totalPieces = e.live_last - e.live_first + 1;

                        position = (e.pos - e.live_first + 1) / totalPieces;
                        this.currentPosition = position;
                        this.lastLivePos = e;

                        if(this.playing && typeof this.onLivePositionChanged === "function") {
                            this.onLivePositionChanged({
                                is_live: parseInt(e.is_live) === 1,
                                position: position
                            });
                        }
                    }
                    else {
                        console.log("got engine event", payload);
                    }

                    break;
                default:
                    console.log("got unknown engine event: " + event);
                    break;
            }
        }
        else if(type == MSG_HANDSHAKE) {
            var clientId = readUInt32BE(buf.subarray(0, 4));
            console.log("got handshake: clientId=" + clientId);
            this._clientId = clientId;
            this.sendPendingRequests();
        }
        else if(type == MSG_SETUP_PLAYER) {
            var config = JSON.parse(ab2str(buf));

            if(VERBOSE) {
                console.log("setup player: config=" + JSON.stringify(config))
            }

            this._volume = config.volume;
            this._muted = config.muted;
            this._deinterlace = config.deinterlace;
            this._audioChannel = config.audio_channel;

            this._audioTrackCount = config.audio_track_count;
            this._currentAudioTrack = config.current_audio_track;
            this._audioTracks = config.audio_tracks;

            this._subtitlesTrackCount = config.subtitles_track_count;
            this._currentSubtitlesTrack = config.current_subtitles_track;
            this._subtitles = config.subtitles;

            if(typeof this.onPlayerSetup === "function") {
                this.onPlayerSetup(config);
            }
        }
        else if(type == MSG_LOAD_RESPONSE) {
            var response = JSON.parse(ab2str(buf));

            if(VERBOSE) {
                console.log("load response: " + JSON.stringify(response))
            }

            if(response.status == 100) {
                console.log("failed to load playlist");
                this.engineMessage("Cannot load transport file");
            }

            if(response.files) {
                for(var i=0; i<response.files.length; i++) {
                    var title = response.files[i][0],
                        fileIndex = response.files[i][1];

                    this.playlist.addRaw({
                        infohash: response.infohash,
                        file_index: fileIndex
                    }, title);
                }
            }

            if(typeof this.playlist._pendingLoadRequests[response.request_id] === "function") {
                this.playlist._pendingLoadRequests[response.request_id]();
            }
            delete this.playlist._pendingLoadRequests[response.request_id];
        }
        else {
            console.log("gotMessage: unknown message: type=" + type + " datalen=" + buf.length);
        }
    }

    Player.prototype.engineMessage = function(msg) {
        if(typeof this.onEngineMessage === "function") {
            this.onEngineMessage(msg);
        }
    }

    Player.prototype.mediaChanged = function() {
        if(typeof this.onMediaChanged === "function") {
            this.onMediaChanged();
        }
    }

    Player.prototype.setMode = function(mode, params) {
        if(typeof this.onPlaybackMode === "function") {
            this.onPlaybackMode(mode, params);
        }
    }

    Player.prototype.setRendererType = function(type) {
        this.rendererType = type;

        // for testing
        if(type === RENDERER_FRAME) {
            $(".renderer-type").text("FRAME");
        }
        else if(type === RENDERER_MPEG_WEBSOCKET || type === RENDERER_MPEG_AJAX) {
            $(".renderer-type").text("CANVAS");
        }
        else if(type === RENDERER_MSE || type === RENDERER_DIRECT_HTTP) {
            $(".renderer-type").text("HTML5 VIDEO");
        }
        else {
            $(".renderer-type").text("(STOPPED)");
        }
    };

    Player.prototype.setupRenderer = function(type, width, height, playbackUrl) {
        var self = this,
            useCanvas;

        console.log("setupRenderer: type=" + type + " width=" + width + " height=" + height + " playbackUrl=" + playbackUrl);
        this.setRendererType(type);

        // shutdown prev renderer
        if(this.renderer) {
            this.renderer.shutdown();
            this.renderer = null;
        }

        // create new renderer
        if(type === RENDERER_FRAME) {
            this.renderer = new FrameRenderer(this.canvas);
            useCanvas = true;
        }
        else if(type === RENDERER_MPEG_WEBSOCKET || type === RENDERER_MPEG_AJAX) {
            this.renderer = new MPEGRenderer(this.canvas, this);
            this.renderer.start();
            useCanvas = true;
        }
        else if(type === RENDERER_MSE || type === RENDERER_DIRECT_HTTP) {
            useCanvas = false;
            this.renderer = new MSERenderer(this.video, this, playbackUrl);
            this.renderer.events.on("play", function() {
                console.log("player:renderer_event: play");
                self.state = STATE_PLAYING;
                self.playing = true;
                if(typeof self.onPlaying === "function") {
                    self.onPlaying();
                }
            });
            this.renderer.events.on("pause", function() {
                console.log("player:renderer_event: pause");
                self.state = STATE_PAUSED;
                if(typeof self.onPaused === "function") {
                    self.onPaused();
                }
            });
            this.renderer.events.on("stop", function() {
                console.log("player:renderer_event: stop");
                self.state = STATE_STOPPED;
                self.playing = false;
                if(typeof self.onStopped === "function") {
                    self.onStopped();
                }
            });
            this.renderer.events.on("time", function(value) {
                if(!self.is_live) {
                    if(typeof self.onTimeChanged === "function") {
                        self.onTimeChanged(value);
                    }

                    if(self.rendererType == RENDERER_MSE && self.duration) {
                        var position = value / self.duration;
                        if(typeof self.onPositionChanged === "function") {
                            self.onPositionChanged(position);
                        }
                    }
                    else if(self.rendererType == RENDERER_DIRECT_HTTP) {
                        var duration = self.renderer.getDuration();
                        if(duration > 0) {
                            var position = value / duration;
                            if(typeof self.onPositionChanged === "function") {
                                self.onPositionChanged(position);
                            }
                        }
                    }
                }
            });
            this.renderer.events.on("duration", function(value) {
                if(!self.is_live) {
                    if(typeof self.onLengthChanged === "function") {
                        self.onLengthChanged(value);
                    }
                }
            });
            this.renderer.events.on("ended", function() {
                console.log("player:renderer_event: ended");
                self.state = STATE_STOPPED;
                self.playing = false;
                if(typeof self.onStopped === "function") {
                    self.onStopped();
                }
                self.sendPlaybackStatus(100);
            });
            this.renderer.events.on("error", function() {
                console.log("player:renderer_event: error");
                self.state = STATE_STOPPED;
                self.playing = false;
                if(typeof self.onStopped === "function") {
                    self.onStopped();
                }
                self.sendPlaybackStatus(201);
            });
            this.renderer.events.on("seekstart", function() {
                console.log("player:renderer_event: seek start");
                self.engineMessage("Seeking...");
            });
            this.renderer.events.on("seekend", function() {
                console.log("player:renderer_event: seek end");
                self.engineMessage("");
            });
        }
        else {
            console.log("setupRenderer: unknown type: " + type);
            return;
        }

        // setup renderer
        this.renderer.setup(width, height);

        // emit event to resize canvas
        this.events.emit("FrameSetup", useCanvas, width, height);
    }

    Player.prototype.gotChunk = function(chunkId) {
        var self = this;
        self.loadChunk(chunkId, function(response) {
            self.renderer.onVideoPacket(new Uint8Array(response));
        });
    };

    Player.prototype.loadChunk = function(chunkId, cb) {
        var xhr = new XMLHttpRequest(),
            url = "http://127.0.0.1:6880/get_chunk?client_id=" + this._clientId + "&id=" + chunkId;

        xhr.open('get', url);
        xhr.responseType = 'arraybuffer';
        xhr.onload = function () {
            if(this.status == 200) {
                cb(xhr.response);
            }
        };
        xhr.send();
    }

    Player.prototype.deinterlaceEnable = function(mode) {
        this._deinterlace = mode;
        this.sendRequest("deinterlace_enable", {
            params: {
                mode: mode
            }
        });
    };

    Player.prototype.deinterlaceDisable = function(mode) {
        this._deinterlace = "disabled";
        this.sendRequest("deinterlace_disable");
    };

    TorrentStream.PlayerClient = {
        createPlayer: function(canvas, video, conf) {
            return new Player(canvas, video, conf);
        }
    };
}();/*****************************************************************************
* Copyright (c) 2015 Branza Victor-Alexandru <branza.alex[at]gmail.com>
*
* This program is free software; you can redistribute it and/or modify it
* under the terms of the GNU Lesser General Public License as published by
* the Free Software Foundation; either version 2.1 of the License, or
* (at your option) any later version.
*
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
* GNU Lesser General Public License for more details.
*
* You should have received a copy of the GNU Lesser General Public License
* along with this program; if not, write to the Free Software Foundation,
* Inc., 51 Franklin Street, Fifth Floor, Boston MA 02110-1301, USA.
*****************************************************************************/

// WebChimera.js Player v0.5.2

//TODO: make fullscreen cross-browser (webkitRequestFullscreen etc)

/** @suppress{suspiciousCode} */
!function() {

var DEBUG_RESIZE = true;
var VERBOSE = false;

//require
var Utils = TorrentStream.Utils;
var $ = TorrentStream.jQuery;
var PlayerClient = TorrentStream.PlayerClient;

var vlcs = {},
    opts = {},
    players = {},
    seekDrag = false,
    volDrag = false,
    firstTime = true,
    // fs = require('fs'),
    // request = require('request'),
    // events = require('events'),
    cssUrl = "//static.acestream.net/jsplayer/jsplayer.min.css",
    powerSaveBlocker=null,
    sleep=null,
    sleepId;

// inject css
if (!$("link[href='"+cssUrl+"']").length) {
    $('<link href="'+cssUrl+'" rel="stylesheet">').appendTo("head");

    //TODO: check if we need this; now it works in chrome only
    // window.document.styleSheets[0].insertRule('.wcp-menu-items::-webkit-scrollbar {width: 44px !important;}', 0);
    // window.document.styleSheets[0].insertRule('.wcp-menu-items::-webkit-scrollbar-track','background-color: #696969 !important; border-right: 13px solid rgba(0, 0, 0, 0); border-left: 21px solid rgba(0, 0, 0, 0); background-clip: padding-box; -webkit-box-shadow: none !important;');
    // window.document.styleSheets[0].insertRule('.wcp-menu-items::-webkit-scrollbar-thumb','background-color: #e5e5e5; border-right: 13px solid rgba(0, 0, 0, 0); border-left: 21px solid rgba(0, 0, 0, 0); background-clip: padding-box; -webkit-box-shadow: none !important;');
    // window.document.styleSheets[0].insertRule('.wcp-menu-items::-webkit-scrollbar-thumb:hover','background-color: #e5e5e5 !important; border-right: 13px solid rgba(0, 0, 0, 0); border-left: 21px solid rgba(0, 0, 0, 0); background-clip: padding-box; -webkit-box-shadow: none !important;');
    // window.document.styleSheets[0].insertRule('.wcp-menu-items::-webkit-scrollbar-thumb:active','background-color: #e5e5e5 !important; border-right: 13px solid rgba(0, 0, 0, 0); border-left: 21px solid rgba(0, 0, 0, 0); background-clip: padding-box; -webkit-box-shadow: none !important;');
}

// deinitializate when page changed
window.onbeforeunload = function(e) {
    // stop all players
    for (var wjsIndex in players) if (players.hasOwnProperty(wjsIndex) && players[wjsIndex].vlc) players[wjsIndex].vlc.stop();
}

function parseSecondsFromTime(timeString) {
    //TODO: add error handling
    var a = timeString.split(":");
    return parseInt(a[0]) * 3600 + parseInt(a[1]) * 60 + parseInt(a[2]);
}

function wjs(context) {

    this.version = "v0.5.2";

    if(typeof context === "undefined") {
        context = "#webchimera";
    }
    else if(typeof context !== "string") {
        if(!context.id) {
            context.id = "webchimera";
        }
        context = "#" + context.id;
    }

    // Save the context
    this.context = (typeof context === "undefined") ? "#webchimera" : context;  // if no playerid set, default to "webchimera"

    if ($(this.context).hasClass("webchimeras")) this.context = "#"+$(this.context).find(".wcp-wrapper")[0].id;

    if (this.context.substring(0,1) == "#") {
        if (window.document.getElementById(this.context.substring(1)).firstChild) {
            this.wrapper = window.document.getElementById(this.context.substring(1));
            // this.canvas = this.wrapper.firstChild.firstChild;
            this.canvas = $(this.wrapper.firstChild).find("canvas").get(0);
            this.video = $(this.wrapper.firstChild).find("video").get(0);
            this.wrapper = $(this.wrapper);
        }
        this.allElements = [window.document.getElementById(this.context.substring(1))];
    } else {
        if (this.context.substring(0,1) == ".") this.allElements = window.document.getElementsByClassName(this.context.substring(1));
        else this.allElements = window.document.getElementsByTagName(this.context);
        this.wrapper = this.allElements[0];
        // this.canvas = this.wrapper.firstChild.firstChild;
        this.canvas = $(this.wrapper.firstChild).find("canvas").get(0);
        this.video = $(this.wrapper.firstChild).find("video").get(0);
        this.wrapper = $(this.wrapper);
    }
    if (vlcs[this.context]) {
        this.vlc = vlcs[this.context].vlc;
        // this.renderer = vlcs[this.context].renderer;
    }
    return this;
}

wjs.prototype.toggleMute = function() {
    if (!this.vlc.mute) this.mute(true);
    else this.mute(false);
    return this;
}

wjs.prototype.togglePause = function() {
    if (!this.playing()) {
        if (this.itemCount() > 0) this.play();
    } else this.pause();
    return this;
}

wjs.prototype.play = function(mrl) {
    if (!this.playing()) {
        switchClass(this.find(".wcp-anim-basic"),"wcp-anim-icon-pause","wcp-anim-icon-play");

        wjsButton = this.find(".wcp-play");
        if (wjsButton.length != 0) wjsButton.removeClass("wcp-play").addClass("wcp-pause");

        wjsButton = this.find(".wcp-replay");
        if (wjsButton.length != 0) wjsButton.removeClass("wcp-replay").addClass("wcp-pause");

        if (mrl) {
            this.vlc.playlist.play(mrl);
        }
        else {
            this.vlc.playlist.resume();
        }
        // else if (this.itemCount() > 0) {
        //     this.vlc.playlist.play();
        // }
    }
    return this;
}

wjs.prototype.pause = function() {
    if (this.playing()) {
        switchClass(this.find(".wcp-anim-basic"),"wcp-anim-icon-play","wcp-anim-icon-pause");
        this.find(".wcp-pause").removeClass("wcp-pause").addClass("wcp-play");
        this.vlc.playlist.pause();
    }
    return this;
}

wjs.prototype.playItem = function(i) {
    if (typeof i !== 'undefined') {
        if (i < this.itemCount() && i > -1) {
            if (this.itemDesc(i).disabled) {
                this.vlc.playlist.items[i].disabled = false;
                if (this.find(".wcp-playlist").is(":visible")) {
                    this.find(".wcp-playlist-items:eq("+i+")").removeClass("wcp-disabled");
                }
                this.find(".wcp-playlist").find(".wcp-menu-selected").removeClass("wcp-menu-selected");
                this.find(".wcp-playlist-items:eq("+i+")").addClass("wcp-menu-selected");
            }

            opts[this.context].keepHidden = true;
            this.zoom(0);

            wjsButton = this.find(".wcp-play");
            if (wjsButton.length != 0) wjsButton.removeClass("wcp-play").addClass("wcp-pause");

            wjsButton = this.find(".wcp-replay");
            if (wjsButton.length != 0) wjsButton.removeClass("wcp-replay").addClass("wcp-pause");

            this.vlc.playlist.playItem(i);

            positionChanged.call(this,0);
            this.find(".wcp-time-current").text("");
            this.find(".wcp-time-total").text("");
        }
    } else return false;
    return this;
}

wjs.prototype.deinterlaceEnable = function(mode) {
    this.vlc.deinterlaceEnable(mode);
}

wjs.prototype.deinterlaceDisable = function() {
    this.vlc.deinterlaceDisable();
}

wjs.prototype.stop = function() {
    wjsButton = this.find(".wcp-pause");
    if (wjsButton.length != 0) wjsButton.removeClass("wcp-pause").addClass("wcp-play");

    wjsButton = this.find(".wcp-replay");
    if (wjsButton.length != 0) wjsButton.removeClass("wcp-replay").addClass("wcp-play");

    this.vlc.playlist.stop();

    positionChanged.call(this,0);
    this.find(".wcp-time-current").text("");
    this.find(".wcp-time-total").text("");
    return this;
}

wjs.prototype.destroy = function() {
    this.stop();
    this.vlc.destroy();
    return this;
};

wjs.prototype.next = function() {
    if (this.currentItem() +1 < this.itemCount()) {

        var noDisabled = true;
        for (i = this.currentItem() +1; i < this.itemCount(); i++) {
            if (!this.itemDesc(i).disabled) {
                noDisabled = false;
                break;
            }
        }
        if (noDisabled) return false;

        this.playItem(i);

        return this;
    } else return false;
}

wjs.prototype.prev = function() {
    if (this.currentItem() > 0) {

        var noDisabled = true;
        for (i = this.currentItem() -1; i > -1; i--) {
            if (!this.itemDesc(i).disabled) {
                noDisabled = false;
                break;
            }
        }
        if (noDisabled) return false;

        this.playItem(i);

        return this;
    } else return false;
}

wjs.prototype.addPlayer = function(wcpSettings) {

    if (wcpSettings) newid = (typeof wcpSettings["id"] === "undefined") ? "webchimera" : wcpSettings["id"]; // if no id set, default to "webchimera"
    else newid = "webchimera";

    if (window.document.getElementById(newid) !== null) {
        for (i = 2; window.document.getElementById(newid +i) !== null; i++) { }
        newid = newid +i;
    }

    if (typeof newid === 'string') {
        if (newid.substring(0,1) == "#") var targetid = ' id="'+newid.substring(1)+'" class="wcp-wrapper"';
        else if (newid.substring(0,1) == ".") { var targetid = ' id="webchimera" class="'+newid.substring(1)+' wcp-wrapper"'; newid = "#webchimera"; }
        else { var targetid = ' id="'+newid+'" class="wcp-wrapper"'; newid = "#"+newid; }
    } else { var targetid = ' id="webchimera" class="wcp-wrapper"'; newid = "#webchimera"; }

    vlcs[newid] = {};
    vlcs[newid].events = new EventEmitter2();

    if (wcpSettings) {
        opts[newid] = wcpSettings;
        vlcs[newid].multiscreen = (typeof wcpSettings["multiscreen"] === "undefined") ? false : wcpSettings["multiscreen"];
    } else {
        opts[newid] = {};
        vlcs[newid].multiscreen = false;
    }
    if (typeof opts[newid].titleBar === 'undefined') opts[newid].titleBar = "both";
    opts[newid].uiHidden = false;
    opts[newid].subDelay = 0;
    opts[newid].lastItem = -1;
    opts[newid].aspectRatio = "Default";
    opts[newid].crop = "Default";
    opts[newid].zoom = 1;
    if (typeof opts[newid].allowFullscreen === 'undefined') opts[newid].allowFullscreen = true;

    playerbody = '<div' + targetid + ' style="height: 100%">'+
                     // canvas and video
                     '<div class="wcp-center" style="overflow: hidden">'+
                         '<canvas class="wcp-canvas wcp-center"></canvas>'+
                         '<video class="wcp-canvas wcp-center"></video>'+
                     '</div>'+
                     '<div class="wcp-surface"></div>'+

                     // playlist
                    '<div class="wcp-menu wcp-playlist wcp-center">'+
                        '<div class="wcp-menu-close"></div>'+
                        '<div class="wcp-menu-title">'+
                            '<div class="wcp-menu-title-1"></div>'+
                            '<div class="wcp-menu-title-2">'+
                                'Name'+
                            '</div>'+
                            '<div class="wcp-menu-title-3">'+
                                'Actions'+
                            '</div>'+
                        '</div>'+
                        '<div class="wcp-menu-items wcp-playlist-items">'+
                            '<ul class="items-container"></ul>'+
                        '</div>'+
                    '</div>'+

                     // subtitles menu
                     '<div class="wcp-menu wcp-subtitles wcp-center">'+
                         '<div class="wcp-menu-close"></div>'+
                         '<div class="wcp-menu-title">Subtitle Menu</div>'+
                         '<ul class="wcp-menu-items wcp-subtitles-items"></ul>'+
                     '</div>'+

                     // center pause animation
                     '<div class="wcp-pause-anim wcp-center">'+
                         '<i class="wcp-anim-basic wcp-anim-icon-play"></i>'+
                     '</div>'+

                     // title bar
                     '<div class="wcp-titlebar">'+
                         '<div class="wcp-title wcp-text-block"></div>'+
                     '</div>'+

                     // toolbar
                     '<div class="wcp-toolbar">'+
                        '<div></div>'+
                         // progress bar
                         '<div class="wcp-progress-bar">'+
                             '<div class="wcp-progress-seen"></div>'+
                             '<div class="wcp-progress-pointer"></div>'+
                         '</div>'+

                         // left buttons
                         '<div class="wcp-ad-info wcp-left wcp-text-block" style="display: none;">'+
                            '<div class="wcp-ad-info-waiting"></div>'+
                            '<span class="wcp-ad-info-text"></span>'+
                         '</div>'+
                         '<div class="wcp-button wcp-left wcp-prev" style="display: none"></div>'+
                         '<div class="wcp-button wcp-left wcp-play"></div>'+
                         '<div class="wcp-button wcp-left wcp-next" style="display: none"></div>'+

                         // live button
                         '<div class="wcp-live wcp-left wcp-text-block state-unknown" style="display: none;"><div class="wcp-live-status"></div>Эфир</div>'+

                         // volume
                         '<div class="controls-volume sound">'+
                            '<div class="wcp-button wcp-mute state-on"></div>'+
                            '<div class="scale">'+
                                '<div class="volume">'+
                                    '<div class="up-to-87"></div>'+
                                    '<div class="up-to-100"></div>'+
                                    '<div class="up-to-150"></div>'+
                                    '<div class="vol_control"></div>'+
                                '</div>'+
                            '</div>'+
                            '<div class="spacer"></div>'+
                         '</div>'+

                         '<div class="volume-text"></div>'+

                         // time/duration
                         '<div class="wcp-time">'+
                             '<span class="wcp-time-current"></span>'+
                             '<span class="wcp-time-total"></span>'+
                         '</div>'+

                         // right buttons
                         '<div class="wcp-ad-disable wcp-right wcp-text-block" style="display: none;"></div>'+
                         '<div class="wcp-button wcp-right wcp-stop state-off"></div>'+
                         '<div class="wcp-button wcp-right wcp-maximize"></div>'+
                         '<div class="wcp-button wcp-right wcp-playlist-but"></div>'+
                         //'<div class="wcp-button wcp-right wcp-subtitle-but"></div>'+
                     '</div>'+

                     // status
                     '<div class="wcp-status"></div>'+

                     // notification
                     '<div class="wcp-notif"></div>'+

                     // subtitles text
                     '<div class="wcp-subtitle-text"></div>'+

                     // tooltip
                     '<div class="wcp-tooltip">'+
                         '<div class="wcp-tooltip-arrow"></div>'+
                         '<div class="wcp-tooltip-inner">00:00</div>'+
                     '</div>'+
                 '</div>';

    opts[newid].currentSub = 0;
    opts[newid].trackSub = -1;

    $(this.context).each(function(ij,el) { if (!$(el).hasClass("webchimeras")) $(el).addClass("webchimeras"); el.innerHTML = playerbody; });

    if (vlcs[newid].multiscreen) {
        vlcs[newid].multiscreen = (typeof wcpSettings["multiscreen"] === "undefined") ? false : wcpSettings["multiscreen"];
        $(newid).find(".wcp-toolbar").hide(0);
        $(newid).find(".wcp-tooltip").hide(0);
        wjs(newid).wrapper.css({cursor: 'pointer'});
    }

    wjs(newid).canvas = $(newid).find("canvas").get(0);
    wjs(newid).video = $(newid).find("video").get(0);

    // resize video when window is resized
    if (firstTime) {
        firstTime = false;
        window.onresize = function(i) { autoResize(); };
        $(window).bind("mouseup",function(i) {
            return function(event) {
                mouseClickEnd.call(players[i],event);
            }
        }(newid)).bind("mousemove",function(i) {
            return function(event) {
                mouseMoved.call(players[i],event);
            }
        }(newid));

        $(document).bind("webkitfullscreenchange mozfullscreenchange fullscreenchange", function(i) {
            return function() {
                onFullscreenChanged.call(players[i]);
            }
        }(newid));
    }

    wjs(newid).wrapper.find(".wcp-menu-close").click(function() {
        if ($(this).parents(".wcp-wrapper").find(".wcp-playlist").is(":visible")) {
            $(".wcp-playlist-items .items-container").sortable("destroy");
            $(this).parents(".wcp-wrapper").find(".wcp-playlist").hide(0);
        } else if ($(this).parents(".wcp-wrapper").find(".wcp-subtitles").is(":visible")) {
            $(this).parents(".wcp-wrapper").find(".wcp-subtitles").hide(0);
        }
    });

    // toolbar button actions
    wjs(newid).wrapper.find(".wcp-button").click(function() {
        wjsPlayer = getContext(this);
        vlc = wjsPlayer.vlc;
        buttonClass = this.className.replace("wcp-button","").replace("wcp-left","").replace("wcp-vol-button","").replace("wcp-right","").replace("state-on","").replace("state-off","").split(" ").join("");

        // for testing
        console.log("click: vlc.state=" + vlc.state + " buttonClass=" + buttonClass);

        if (buttonClass == "wcp-playlist-but") {
            if ($(this).parents(".wcp-wrapper").find(".wcp-playlist").is(":visible")) hidePlaylist.call(wjsPlayer);
            else showPlaylist.call(wjsPlayer);
        }
        if (buttonClass == "wcp-subtitle-but") {
            if ($(this).parents(".wcp-wrapper").find(".wcp-subtitles").is(":visible")) hideSubtitles.call(wjsPlayer);
            else showSubtitles.call(wjsPlayer);
        }
        if (buttonClass == "wcp-prev") wjsPlayer.prev();
        else if (buttonClass == "wcp-next") wjsPlayer.next();
        if ([3,4,6].indexOf(vlc.state) > -1) {
            if (buttonClass == "wcp-play") wjsPlayer.play().animatePause();
            else if (buttonClass == "wcp-pause") wjsPlayer.pause().animatePause();
            else if (buttonClass == "wcp-replay") { vlc.stop(); wjsPlayer.play().animatePause(); }
        }

        if ([0,5].indexOf(vlc.state) > -1 && buttonClass == "wcp-play") if (wjsPlayer.itemCount() > 0) wjsPlayer.play().animatePause();

        if (buttonClass == "wcp-minimize") fullscreenOff.call(wjsPlayer);
        else if (buttonClass == "wcp-maximize") fullscreenOn.call(wjsPlayer);

        if(buttonClass == "wcp-stop") {
            wjsPlayer.stop();
        }

        if (buttonClass == "wcp-mute") {
            wjsPlayer.toggleMute();
        }
    });

    // live button click
    wjs(newid).wrapper.find(".wcp-live").click(function() {
        if($(this).hasClass("state-timeshift")) {
            var wjsPlayer = getContext(this);
            wjsPlayer.vlc.liveSeek(-1);
        }
    });

    // skip button click
    wjs(newid).wrapper.find(".wcp-ad-info-text").click(function() {
        var canSkip = parseInt($(this).data("can-skip"));
        if(canSkip === 1) {
            var wjsPlayer = getContext(this);
            wjsPlayer.vlc.requestSkip();
        }
    });

    // disable ads button click
    wjs(newid).wrapper.find(".wcp-ad-disable").click(function() {
        var url = $(this).data("url");
        if(url) {
            window.open(url);
        }
    });

    // surface click actions
    wjs(newid).wrapper.find(".wcp-surface").click(function() {
        wjsPlayer = getContext(this);

        if(wjsPlayer._playbackMode === 2 && wjsPlayer._playbackParams.clickurl) {
            window.open(decodeURIComponent(wjsPlayer._playbackParams.clickurl));
        }
        else if (opts[wjsPlayer.context].allowPauseOnClick) {
            if (wjsPlayer.stateInt() == 6) {
                wjsPlayer.find(".wcp-replay").trigger("click");
                return;
            }
            if ([3,4].indexOf(wjsPlayer.stateInt()) > -1) {
                if (vlcs[wjsPlayer.context].multiscreen && window.document.webkitFullscreenElement == null) {
                    wjsPlayer.fullscreen(true);
                    if (wjsPlayer.wrapper.css('cursor') == 'none') wjsPlayer.wrapper.css({cursor: 'default'});
                    if (wjsPlayer.mute()) wjsPlayer.mute(false);
                } else wjsPlayer.togglePause().animatePause();
            }
            if ([5].indexOf(wjsPlayer.vlc.state) > -1 && !wjsPlayer.playing() && wjsPlayer.itemCount() > 0) wjsPlayer.play().animatePause();
        }
    });

    wjs(newid).wrapper.find(".wcp-surface").dblclick(function() {
        wjsPlayer = getContext(this);
        if (opts[wjsPlayer.context].allowFullscreen) {
            wjsPlayer.find(".wcp-anim-basic").finish();
            wjsPlayer.find(".wcp-pause-anim").finish();
            wjsPlayer.toggleFullscreen();
        }
    });

    wjs(newid).wrapper.parent().bind("mousemove",function(e) {
        wjsPlayer = getContext(this);
        if (opts[wjsPlayer.context].uiHidden === false) {
            if (vlcs[wjsPlayer.context].multiscreen && window.document.webkitFullscreenElement == null) {
                wjsPlayer.wrapper.css({cursor: 'pointer'});
            } else {
                clearTimeout(vlcs[wjsPlayer.context].hideUI);
                wjsPlayer.wrapper.css({cursor: 'default'});

                if (window.document.webkitFullscreenElement == null) {
                    if (["both","minimized"].indexOf(opts[wjsPlayer.context].titleBar) > -1) {
                        wjsPlayer.find(".wcp-titlebar").stop().show(0);
                        if (wjsPlayer.find(".wcp-status").css("top") == "10px") wjsPlayer.find(".wcp-status").css("top", "35px");
                        if (wjsPlayer.find(".wcp-notif").css("top") == "10px") wjsPlayer.find(".wcp-notif").css("top", "35px");
                    }
                } else {
                    if (["both","fullscreen"].indexOf(opts[wjsPlayer.context].titleBar) > -1) {
                        wjsPlayer.find(".wcp-titlebar").stop().show(0);
                        if (wjsPlayer.find(".wcp-status").css("top") == "10px") wjsPlayer.find(".wcp-status").css("top", "35px");
                        if (wjsPlayer.find(".wcp-notif").css("top") == "10px") wjsPlayer.find(".wcp-notif").css("top", "35px");
                    }
                }

                wjsPlayer.find(".wcp-toolbar").stop().show(0);
                if (!volDrag && !seekDrag) {
                    if ($(wjsPlayer.find(".wcp-toolbar").selector + ":hover").length > 0) {
                        vlcs[wjsPlayer.context].hideUI = setTimeout(function(i) { return function() { hideUI.call(players[i]); } }(wjsPlayer.context),3000);
                        vlcs[wjsPlayer.context].timestampUI = Math.floor(Date.now() / 1000);
                    } else vlcs[wjsPlayer.context].hideUI = setTimeout(function(i) { return function() { hideUI.call(players[i]); } }(wjsPlayer.context),3000);
                }
            }
        } else wjsPlayer.wrapper.css({cursor: 'default'});
    });

    /* Progress and Volume Bars */
    wjs(newid).wrapper.find(".wcp-progress-bar").hover(function(arg1) {
        return progressHoverIn.call(getContext(this),arg1);
    }, function(e) {
        if (!seekDrag) sel.call(this,".wcp-tooltip").hide(0);
    });

    wjs(newid).wrapper.find(".wcp-progress-bar").bind("mousemove",function(arg1) {
        return progressMouseMoved.call(getContext(this),arg1);
    });

    wjs(newid).wrapper.find(".wcp-progress-bar").bind("mousedown", function(e) {
        seekDrag = true;
        var rect = $(this).parents(".wcp-wrapper")[0].getBoundingClientRect();
        p = (e.pageX - rect.left) / $(this).width();
        sel.call(this,".wcp-progress-seen").css("width", (p*100)+"%");
    });

    wjs(newid).wrapper.find(".controls-volume").mouseout(
        function() {
            wjsPlayer.find(".volume-text").text("").hide();
        }
    );

    wjs(newid).wrapper.find(".volume").mousemove(function(event) {
            var pos = event.offsetX ? event.offsetX : event.pageX - $(this).offset().left;
            var w = $(this).width();
            if(w) {
                var vol = Math.round(pos / w * 100);
                wjsPlayer.find(".volume-text").text(vol + "%").show();
            }
    });

    wjs(newid).wrapper.find(".volume").mousedown(function(event) {
            var pos = event.offsetX ? event.offsetX : event.pageX - $(this).offset().left;
            var w = $(this).width();
            if(w) {
                getContext(this).volume(Math.floor(pos / w * 200));
            }
    });

    wjs(newid).wrapper.contextMenu({
        selector: '.wcp-surface',
        build: function($trigger, e) {
            var wjsPlayer = getContext($trigger),
                rendererType = wjsPlayer.vlc.getRendererType(),
                currentCrop = wjsPlayer.crop(),
                currentAspectRatio = wjsPlayer.aspectRatio(),
                currentDeinterlace = wjsPlayer.deinterlace(),
                currentAudioChannel = wjsPlayer.vlc.audioChannel,
                currentAudioTrack = wjsPlayer.vlc.currentAudioTrack,
                availableAudioTracks = wjsPlayer.vlc.audioTracks,
                currentSubtitlesTrack = wjsPlayer.vlc.currentSubtitlesTrack,
                availableSubtitlesTracks = wjsPlayer.vlc.subtitles;

            var menuItems = {
                "aspect_ratio": {
                    name: "Aspect Ratio",
                    items: {
                        "ar_default": {name: "Default"},
                        "ar_1_1": {name: "1:1"},
                        "ar_16_9": {name: "16:9"},
                    }
                },
                "crop": {
                    name: "Crop",
                    items: {
                        "crop_default": {name: "Default"},
                        "crop_1_1": {name: "1:1"},
                        "crop_16_9": {name: "16:9"},
                    }
                },
            };

            if(rendererType === "mpeg") {
                Utils.extend(menuItems, {

                    "audio_channels": {
                        name: "Audio channels",
                        items: {
                            "ac_stereo": {name: "Stereo"},
                            "ac_reverse_stereo": {name: "Reverse Stereo"},
                            "ac_left": {name: "Left"},
                            "ac_right": {name: "Right"},
                        }
                    },
                    "deinterlace": {
                        name: "Deinterlace",
                        items: {
                            "di_disabled": {name: "Disabled"},
                            "di_blend": {name: "blend"},
                            "di_bob": {name: "bob"},
                            "di_discard": {name: "discard"},
                            "di_linear": {name: "linear"},
                            "di_mean": {name: "mean"},
                            "di_x": {name: "x"},
                            "di_yadif": {name: "yadif"},
                            "di_yadif2x": {name: "yadif2x"},
                        }
                    }
                });

                if(availableAudioTracks.length > 0) {
                    Utils.extend(menuItems, {
                        "audio_tracks": {
                            name: "Audio tracks",
                            items: {
                            }
                        },
                    });
                }

                if(availableSubtitlesTracks.length > 0) {
                    Utils.extend(menuItems, {
                        "subtitles": {
                            name: "Subtitles",
                            items: {
                            }
                        },
                    });
                }
            }

            var menu = {
                callback: function(key, options) {
                    console.log("context menu click", key, options);
                    var wjsPlayer = getContext(this);

                    if(key == 'crop_default') {
                        wjsPlayer.crop("default");
                    }
                    else if(key == 'crop_1_1') {
                        wjsPlayer.crop("1:1");
                    }
                    else if(key == 'crop_16_9') {
                        wjsPlayer.crop("16:9");
                    }
                    else if(key == "ar_default") {
                        wjsPlayer.aspectRatio("default");
                    }
                    else if(key == "ar_1_1") {
                        wjsPlayer.aspectRatio("1:1");
                    }
                    else if(key == "ar_16_9") {
                        wjsPlayer.aspectRatio("16:9");
                    }
                    // deinterlace
                    else if(key == "di_disabled") {
                        wjsPlayer.deinterlace("disabled");
                    }
                    else if(key == "di_blend") {
                        wjsPlayer.deinterlace("blend");
                    }
                    // audio channels
                    else if(key == "ac_stereo") {
                        wjsPlayer.vlc.audioChannel = 1;
                    }
                    else if(key == "ac_reverse_stereo") {
                        wjsPlayer.vlc.audioChannel = 2;
                    }
                    else if(key == "ac_left") {
                        wjsPlayer.vlc.audioChannel = 3;
                    }
                    else if(key == "ac_right") {
                        wjsPlayer.vlc.audioChannel = 4;
                    }
                    // audio track
                    else if(key.substring(0, 12) == "audio_track:") {
                        var value = parseInt(key.substring(12));
                        wjsPlayer.vlc.currentAudioTrack = value;
                    }
                    // subtitles track
                    else if(key.substring(0, 12) == "subtitles_track:") {
                        var value = parseInt(key.substring(12));
                        wjsPlayer.vlc.currentSubtitlesTrack = value;
                    }
                },
                items: menuItems
            };

            if(VERBOSE) {
                console.log("currentCrop", currentCrop);
                console.log("currentAspectRatio", currentAspectRatio);
                console.log("currentDeinterlace", currentDeinterlace);
                console.log("currentAudioChannel", currentAudioChannel);
                console.log("currentAudioTrack", currentAudioTrack);
                console.log("availableAudioTracks", availableAudioTracks);
                console.log("currentSubtitlesTrack", currentSubtitlesTrack);
                console.log("availableSubtitlesTracks", availableSubtitlesTracks);
            }

            // set current crop
            if(currentCrop == "1:1") {
                menu.items['crop'].items['crop_1_1'].icon = "fa-check";
            }
            else if(currentCrop == "16:9") {
                menu.items['crop'].items['crop_16_9'].icon = "fa-check";
            }
            else {
                menu.items['crop'].items['crop_default'].icon = "fa-check";
            }

            // set current aspect ratio
            if(currentAspectRatio == "1:1") {
                menu.items['aspect_ratio'].items['ar_1_1'].icon = "fa-check";
            }
            else if(currentAspectRatio == "16:9") {
                menu.items['aspect_ratio'].items['ar_16_9'].icon = "fa-check";
            }
            else {
                menu.items['aspect_ratio'].items['ar_default'].icon = "fa-check";
            }

            if(rendererType == "mpeg") {
                // set current deinterlace mode
                if(currentDeinterlace == "blend") {
                    menu.items['deinterlace'].items['di_blend'].icon = "fa-check";
                }
                else {
                    menu.items['deinterlace'].items['di_disabled'].icon = "fa-check";
                }

                // set current audio channel
                if(currentAudioChannel == 1) {
                    menu.items['audio_channels'].items['ac_stereo'].icon = "fa-check";
                }
                else if(currentAudioChannel == 2) {
                    menu.items['audio_channels'].items['ac_reverse_stereo'].icon = "fa-check";
                }
                else if(currentAudioChannel == 3) {
                    menu.items['audio_channels'].items['ac_left'].icon = "fa-check";
                }
                else if(currentAudioChannel == 4) {
                    menu.items['audio_channels'].items['ac_right'].icon = "fa-check";
                }

                // set available and current audio tracks
                for(i=0; i<availableAudioTracks.length; i++) {
                    var item = {name: availableAudioTracks[i], key: "test" + i};
                    if(i == currentAudioTrack) {
                        item.icon = "fa-check";
                    }
                    menu.items['audio_tracks'].items["audio_track:" + i] = item;
                }

                // set available and current subtitles tracks
                for(i=0; i<availableSubtitlesTracks.length; i++) {
                    var item = {name: availableSubtitlesTracks[i], key: "test" + i};
                    if(i == currentSubtitlesTrack) {
                        item.icon = "fa-check";
                    }
                    menu.items['subtitles'].items["subtitles_track:" + i] = item;
                }
            }

            return menu;
        }
    });

    // set initial status message font size
    fontSize = calcFontSize(wjs(newid));

    wjs(newid).wrapper.find(".wcp-status").css('fontSize', fontSize);
    wjs(newid).wrapper.find(".wcp-notif").css('fontSize', fontSize);
    wjs(newid).wrapper.find(".wcp-subtitle-text").css('fontSize', fontSize);

    // create player and attach event handlers
    wjsPlayer = wjs(newid);
    vlcs[newid].hideUI = setTimeout(function(i) { return function() { hideUI.call(players[i]); } }(newid),6000);
    vlcs[newid].timestampUI = 0;
    // vlcs[newid].renderer = window.Renderer;

    // set default network-caching to 10 seconds
    if (!wcpSettings["buffer"]) wcpSettings["buffer"] = 10000;

    if (!wcpSettings["vlcArgs"]) wcpSettings["vlcArgs"] = ["--network-caching="+wcpSettings["buffer"]];
    else {
        var checkBuffer = wcpSettings["vlcArgs"].some(function(el,ij) {
            if (el.indexOf("--network-caching") == 0) return true;
        });
        if (!checkBuffer) wcpSettings["vlcArgs"].push("--network-caching="+wcpSettings["buffer"]);
    }

    var _ctx = wjs(newid);
    if (wcpSettings && wcpSettings["conf"]) {
        vlcs[newid].vlc = PlayerClient.createPlayer(_ctx.canvas, _ctx.video, wcpSettings["conf"]);
    }
    else {
        vlcs[newid].vlc = PlayerClient.createPlayer(_ctx.canvas, _ctx.video);
    }

    vlcs[newid].vlc.events.on("FrameSetup",function(i) {
        return function(useCanvas, width, height, pixelFormat, videoFrame) {
            vlcs[i].events.emit('FrameSetup', width, height, pixelFormat, videoFrame);

            if(useCanvas) {
                $(players[i].canvas).show();
                $(players[i].video).hide();
            }
            else {
                $(players[i].canvas).hide();
                $(players[i].video).show();
            }

            if(DEBUG_RESIZE) {
                console.log("FrameSetup: useCanvas=" + useCanvas + " width=" + width + " height=" + height);
            }
            singleResize.call(players[i], width, height, pixelFormat, videoFrame);
            isPlaying.call(players[i]);
        }
    }(newid));

    vlcs[newid].vlc.onEngineMessage = function(i) {
        return function(event) {
            gotEngineMessage.call(players[i],event);
        }
    }(newid);

    vlcs[newid].vlc.onPlaybackMode = function(i) {
        return function(event, params) {
            setPlaybackMode.call(players[i], event, params);
        }
    }(newid);

    vlcs[newid].vlc.onPlayerSetup = function(i) {
        return function(event) {
            playerSetup.call(players[i],event);
        }
    }(newid);

    vlcs[newid].vlc.onPositionChanged = function(i) {
        return function(event) {
            positionChanged.call(players[i],event);
        }
    }(newid);

    vlcs[newid].vlc.onLivePositionChanged = function(i) {
        return function(event) {
            livePositionChanged.call(players[i],event);
        }
    }(newid);

    vlcs[newid].vlc.onTimeChanged = function(i) {
        return function(event) {
            timePassed.call(players[i],event);
        }
    }(newid);

    vlcs[newid].vlc.onMediaChanged = function(i) {
        return function() {
            isMediaChanged.call(players[i]);
        }
    }(newid);

    vlcs[newid].vlc.onNothingSpecial = function(i) {
        return function() {
            if (vlcs[i].lastState != "idle") {
                vlcs[i].lastState = "idle";
                vlcs[i].events.emit('StateChanged','idle');
                vlcs[i].events.emit('StateChangedInt',0);
            }
        }
    }(newid);

    vlcs[newid].vlc.onOpening = function(i) {
        return function() {
            if (vlcs[i].lastState != "opening") {
                vlcs[i].lastState = "opening";
                vlcs[i].events.emit('StateChanged','opening');
                vlcs[i].events.emit('StateChangedInt',1);
            }
            isOpening.call(players[i]);
        }
    }(newid);

    vlcs[newid].vlc.onBuffering = function(i) {
        return function(event) {
            if (vlcs[i].lastState != "buffering") {
                vlcs[i].lastState = "buffering";
                vlcs[i].events.emit('StateChanged','buffering');
                vlcs[i].events.emit('StateChangedInt',2);
            }
            isBuffering.call(players[i],event);
        }
    }(newid);

    vlcs[newid].vlc.onPlaying = function(i) {
        return function() {
            if (vlcs[i].lastState != "playing") {
                vlcs[i].lastState = "playing";
                vlcs[i].events.emit('StateChanged','playing');
                vlcs[i].events.emit('StateChangedInt',3);
            }
            isPlaying.call(players[i]);

            preventSleep();
        }
    }(newid);

    vlcs[newid].vlc.onLengthChanged = function(i) {
        return function(length) {
            wjsPlayer = players[i];
            if (length > 0) {
                if (wjsPlayer.find(".wcp-time-current").text() == "") wjsPlayer.find(".wcp-time-current").text("00:00");
                wjsPlayer.find(".wcp-time-total").text(" / "+parseTime(length));
            } else wjsPlayer.find(".wcp-time-total").text("");
        }
    }(newid);

    vlcs[newid].vlc.onPaused = function(i) {
        return function() {
            if (vlcs[i].lastState != "paused") {
                vlcs[i].lastState = "paused";
                vlcs[i].events.emit('StateChanged','paused');
                vlcs[i].events.emit('StateChangedInt',4);

                // update playlist action button
                players[i].find(".wcp-playlist .wcp-menu-item").removeClass("state-playing");

                allowSleep();
            }
        }
    }(newid);

    vlcs[newid].vlc.onStopped = function(i) {
        return function() {
            if (vlcs[i].lastState != "stopping") {
                vlcs[i].lastState = "stopping";
                vlcs[i].events.emit('StateChanged','stopping');
                vlcs[i].events.emit('StateChangedInt',5);
            }
            hasStopped.call(players[i]);
        }
    }(newid);

    vlcs[newid].vlc.onEndReached = function(i) {
        return function() {
            if (vlcs[i].lastState != "ended") {
                vlcs[i].lastState = "ended";
                vlcs[i].events.emit('StateChanged','ended');
                vlcs[i].events.emit('StateChangedInt',6);
            }
            hasEnded.call(players[i]);

            allowSleep();
        }
    }(newid);

    vlcs[newid].vlc.onEncounteredError = function(i) {
        return function() {
            if (vlcs[i].lastState != "error") {
                vlcs[i].lastState = "error";
                vlcs[i].events.emit('StateChanged','error');
                vlcs[i].events.emit('StateChangedInt',7);
            }

            allowSleep();
        }
    }(newid);

    // set playlist mode to single playback, the player has it's own playlist mode feature
    vlcs[newid].vlc.playlist.mode = vlcs[newid].vlc.playlist.Single;

    players[newid] = new wjs(newid);

    return players[newid];
}

wjs.prototype.addPlaylist = function(playlist) {
     var self = this;

     // convert all strings to json object
     if (Array.isArray(playlist) === true) {
         var item = 0;
         for (item = 0; typeof playlist[item] !== 'undefined'; item++) {
             if (typeof playlist[item] === 'string') {
                 var tempPlaylist = playlist[item];
                 delete playlist[item];
                 playlist[item] = { url: tempPlaylist };
             }
         }
     } else if (typeof playlist === 'string') {
         var tempPlaylist = playlist;
         delete playlist;
         playlist = [];
         playlist.push({ url: tempPlaylist });
         delete tempPlaylist;
     } else if (typeof playlist === 'object') {
         var tempPlaylist = playlist;
         delete playlist;
         playlist = [];
         playlist.push(tempPlaylist);
         delete tempPlaylist;
     }
     // end convert all strings to json object

     function postProcess(conf) {
        if (this.itemCount() > 1) {
            this.find(".wcp-prev").show(0);
            this.find(".wcp-next").show(0);
        }
        else {
            this.find(".wcp-prev").hide(0);
            this.find(".wcp-next").hide(0);
        }

        if (this.state() == "idle" || this.state() == "ended") {
            if(conf && conf.autoplay) {
                this.playItem(0);
            }
            if ((opts[this.context].mute || opts[this.context].multiscreen) && !this.mute()) this.mute(true);
        }

        if (this.find(".wcp-playlist").is(":visible")) {
            printPlaylist.call(this);
        }
        if (this.itemCount() > 1) {
            this.find(".wcp-playlist-but").css({ display: "block" });
        }


          // //TODO: cannot set this, playlist is loaded async
          // // if (playlist[item].title) this.vlc.playlist.items[this.itemCount()-1].title = "[custom]"+playlist[item].title;
          // // this.vlc.playlist.items[this.itemCount()-1].setting = "{}";

          // var playerSettings = {};
          // if (typeof playlist[item].aspectRatio !== 'undefined') {
          //     if (item == 0) opts[this.context].aspectRatio = playlist[item].aspectRatio;
          //     playerSettings.aspectRatio = playlist[item].aspectRatio;
          // }
          // if (typeof playlist[item].crop !== 'undefined') {
          //     if (item == 0) opts[this.context].crop = playlist[item].crop;
          //     playerSettings.crop = playlist[item].crop;
          // }
          // if (typeof playlist[item].zoom !== 'undefined') {
          //     if (item == 0) opts[this.context].zoom = playlist[item].zoom;
          //     playerSettings.zoom = playlist[item].zoom;
          // }
          // if (typeof playlist[item].subtitles !== 'undefined') playerSettings.subtitles = playlist[item].subtitles;

          // //TODO: cannot set this, playlist is loaded async
          // // if (Object.keys(playerSettings).length > 0) this.vlc.playlist.items[this.itemCount()-1].setting = JSON.stringify(playerSettings);
     }

     if (Array.isArray(playlist) === true && typeof playlist[0] === 'object') {
         var item = 0;
         for (item = 0; item < playlist.length; item++) {
              if (playlist[item].vlcArgs) {
                  if (!Array.isArray(playlist[item].vlcArgs)) {
                      if (playlist[item].vlcArgs.indexOf(" ") > -1) {
                          playlist[item].vlcArgs = playlist[item].vlcArgs.split(" ");
                      } else playlist[item].vlcArgs = [playlist[item].vlcArgs];
                  }
                  this.vlc.playlist.addWithOptions(playlist[item].url,playlist[item].vlcArgs);
              }
              else {
                var conf = playlist[item].conf,
                    self = this;

                this.vlc.playlist.add(playlist[item].url, function() {
                    postProcess.call(self, conf);
                });
              }
          }
     }

    return this;
}

wjs.prototype.subDesc = function(getDesc) {
    if (!isNaN(getDesc)) {
        if (getDesc < this.vlc.subtitles.count) {
            wjsResponse = {};
            wjsResponse.language = this.vlc.subtitles[getDesc];
            wjsResponse.type = "internal";
            return wjsResponse;
        } else {
            var itemSetting = this.itemDesc(this.currentItem()).setting;
            if (itemSetting.subtitles) {
                itemSubtitles = itemSetting.subtitles;
                wjsIndex = this.vlc.subtitles.count;
                if (wjsIndex == 0) wjsIndex = 1;
                for (var newDesc in itemSubtitles) if (itemSubtitles.hasOwnProperty(newDesc)) {
                    if (getDesc == wjsIndex) {
                        wjsResponse = {};
                        wjsResponse.language = newDesc;
                        wjsResponse.type = "external";
                        wjsResponse.url = itemSubtitles[newDesc];
                        wjsResponse.ext = itemSubtitles[newDesc].split('.').pop().toLowerCase();
                        if (wjsResponse.ext.indexOf('[') > -1) wjsResponse.ext = wjsResponse.ext.substr(0,wjsResponse.ext.indexOf('['));
                        return wjsResponse;
                    }
                    wjsIndex++;
                }
                return;
            }
        }
        return;
    } else return console.error("Value sent to .subDesc() needs to be a number.");
}

wjs.prototype.subCount = function() {
    wjsIndex = this.vlc.subtitles.count;
    var itemSetting = this.itemDesc(this.currentItem()).setting;
    if (itemSetting.subtitles) {
        itemSubtitles = itemSetting.subtitles;
        if (wjsIndex == 0) wjsIndex = 1;
        for (var newDesc in itemSubtitles) if (itemSubtitles.hasOwnProperty(newDesc)) wjsIndex++;
        return wjsIndex;
    }
    return wjsIndex;
}

wjs.prototype.subTrack = function(newTrack) {
    if (typeof newTrack === 'number') {
        if (newTrack == 0) {
            this.vlc.subtitles.track = 0;
            clearSubtitles.call(this);
        } else {
            if (newTrack < this.vlc.subtitles.count) {
                this.find(".wcp-subtitle-text").html("");
                opts[this.context].subtitles = [];
                this.vlc.subtitles.track = newTrack;
            } else {
                this.find(".wcp-subtitle-text").html("");
                opts[this.context].subtitles = [];

                if (this.vlc.subtitles.track > 0) {
                    this.vlc.subtitles.track = 0;
                    newSub = newTrack - this.vlc.subtitles.count +1;
                } else newSub = newTrack - this.vlc.subtitles.count;

                itemSubtitles = this.itemDesc(this.currentItem()).setting.subtitles;
                for (var k in itemSubtitles) if (itemSubtitles.hasOwnProperty(k)) {
                    newSub--;
                    if (newSub == 0) {
                        loadSubtitle.call(this,itemSubtitles[k]);
                        break;
                    }
                }
            }
            opts[this.context].currentSub = newTrack;
            printSubtitles.call(this);
        }
    } else return opts[this.context].currentSub;
    return this;
}

wjs.prototype.subDelay = function(newDelay) {
    if (typeof newDelay === 'number') {
        this.vlc.subtitles.delay = newDelay;
        opts[this.context].subDelay = newDelay;
    } else return opts[this.context].subDelay;
    return this;
}

wjs.prototype.audioTrack = function(newTrack) {
    if (typeof newTrack === 'number') this.vlc.audio.track = newTrack;
    else return this.vlc.audio.track;
    return this;
}
wjs.prototype.audioDesc = function(getDesc) {
    if (typeof getDesc === 'number') return this.vlc.audio[getDesc];
    return this;
}
wjs.prototype.audioDelay = function(newDelay) {
    if (typeof newDelay === 'number') this.vlc.audio.delay = newDelay;
    else return this.vlc.audio.delay;
    return this;
}
wjs.prototype.audioChan = function(newChan) {
    if (typeof newChan === 'string') {
        if (newChan == "error") this.vlc.audio.channel = -1;
        else if (newChan == "stereo") this.vlc.audio.channel = 1;
        else if (newChan == "reverseStereo") this.vlc.audio.channel = 2;
        else if (newChan == "left") this.vlc.audio.channel = 3;
        else if (newChan == "right") this.vlc.audio.channel = 4;
        else if (newChan == "dolby") this.vlc.audio.channel = 5;
        else return false;
    } else {
        if (this.vlc.audio.channel == -1) return "error";
        else if (this.vlc.audio.channel == 1) return "stereo";
        else if (this.vlc.audio.channel == 2) return "reverseStereo";
        else if (this.vlc.audio.channel == 3) return "left";
        else if (this.vlc.audio.channel == 4) return "right";
        else if (this.vlc.audio.channel == 5) return "dolby";
    }
    return this;
}

wjs.prototype.audioChanInt = function(newChan) {
    if (typeof newChan === 'number') this.vlc.audio.channel = newChan;
    else return this.vlc.audio.channel;
    return this;
}

wjs.prototype.deinterlace = function(newMode) {
    if (typeof newMode === 'string') {
        if (newMode == 'disabled') {
            this.vlc.deinterlaceDisable();
        }
        else {
            this.vlc.deinterlaceEnable(newMode);
        }
    }
    else {
        return this.vlc.deinterlace;
    }
    return this;
}

wjs.prototype.mute = function(newMute) {
    if (typeof newMute === "boolean") {
        if (this.vlc.mute !== newMute) {
            if (!this.vlc.mute) players[this.context].volume(0);
            else {
                if (opts[this.context].lastVolume <= 15) opts[this.context].lastVolume = 100;
                this.volume(opts[this.context].lastVolume);
            }
        } else return false;
    } else return this.vlc.mute;
}

wjs.prototype.volume = function(newVolume) {
    var vv;
    if (typeof newVolume !== 'undefined' && !isNaN(newVolume) && newVolume >= 0 && newVolume <= 5) {
        opts[this.context].lastVolume = this.vlc.volume;
        this.vlc.volume = 0;
        if (!this.vlc.mute) {
            // this.find(".wcp-vol-button").removeClass("wcp-volume-medium").removeClass("wcp-volume-high").removeClass("wcp-volume-low").addClass("wcp-mute");
            this.vlc.mute = true;
        }
        // this.find(".wcp-vol-bar-full").css("width", "0px");
        vv = 0;
        // this.find(".mute").addClass("off").removeClass("on");
        // this.find(".vol_control").css("left", "0");
    }
    else if (newVolume && !isNaN(newVolume) && newVolume > 5 && newVolume <= 200) {
        if (this.vlc.mute) this.vlc.mute = false;

        // if (newVolume > 150) this.find(".wcp-vol-button").removeClass("wcp-mute").removeClass("wcp-volume-medium").removeClass("wcp-volume-low").addClass("wcp-volume-high");
        // else if (newVolume > 50) this.find(".wcp-vol-button").removeClass("wcp-mute").removeClass("wcp-volume-high").removeClass("wcp-volume-low").addClass("wcp-volume-medium");
        // else this.find(".wcp-vol-button").removeClass("wcp-mute").removeClass("wcp-volume-medium").removeClass("wcp-volume-high").addClass("wcp-volume-low");

        // this.find(".wcp-vol-bar-full").css("width", (((newVolume/200)*parseInt(this.find(".wcp-vol-bar").css("width")))-parseInt(this.find(".wcp-vol-bar-pointer").css("width")))+"px");
        vv = newVolume / 2;
        // this.find(".mute").addClass("on").removeClass("off");
        // this.find(".vol_control").css("left", (newVolume / 2).toFixed(2) + "%");

        this.vlc.volume = parseInt(newVolume);
    }
    else {
        return this.vlc.volume;
    }

    var v2 = vv*2;
    if(vv == 0) {
        this.find(".wcp-mute").addClass("state-off").removeClass("state-on");
    }
    else {
        this.find(".wcp-mute").addClass("state-on").removeClass("state-off");
    }

    if( v2 <= 87 ) {
        this.find(".up-to-87").css({right: (100-vv) + "%"});
        this.find(".up-to-100").hide();
        this.find(".up-to-150").hide();
        this.find(".vol_control").css({left: vv + "%"});
    }
    else if( v2 <=100 ) {
        this.find(".up-to-87").css({right: (100-vv) + "%"});
        this.find(".up-to-100").css({right: (100-vv) + "%"}).show();
        this.find(".up-to-150").hide();
        this.find(".vol_control").css({left: vv + "%"});
    }
    else {
        this.find(".up-to-87").css({right: (100-vv) + "%"});
        this.find(".up-to-100").css({right: (100-vv) + "%"}).show();
        this.find(".up-to-150").css({right: (100-vv) + "%"}).show();
        this.find(".vol_control").css({left: vv + "%"});
    }

    return this;
}

wjs.prototype.time = function(newTime) {
    if (typeof newTime === 'number') {
        this.vlc.time = newTime;
        this.find(".wcp-time-current").text(parseTime(newTime,this.vlc.length));
        this.find(".wcp-progress-seen")[0].style.width = (newTime/(this.vlc.length)*100)+"%";
    } else return this.vlc.time;
    return this;
}

wjs.prototype.position = function(newPosition) {
    if (typeof newPosition === 'number') {
        this.vlc.position = newPosition;
        if(this._playbackMode == 0) {
            this.find(".wcp-time-current").text(parseTime(this.vlc.length*newPosition,this.vlc.length));
        }
        this.find(".wcp-progress-seen")[0].style.width = (newPosition*100)+"%";
    }
    else {
        return this.vlc.position;
    }
    return this;
}

wjs.prototype.rate = function(newRate) {
    if (typeof newRate === 'number') this.vlc.input.rate = newRate;
    else return this.vlc.input.rate;
    return this;
}

wjs.prototype.currentItem = function(i) {
    if (typeof i !== 'undefined') {
        if (i != this.vlc.playlist.currentItem) {
            if (i < this.itemCount() && i > -1) {
                if (this.itemDesc(i).disabled) {
                    this.vlc.playlist.items[i].disabled = false;
                    if (this.find(".wcp-playlist").is(":visible")) {
                        this.find(".wcp-playlist-items:eq("+i+")").removeClass("wcp-disabled");
                    }
                    this.find(".wcp-playlist").find(".wcp-menu-selected").removeClass("wcp-menu-selected");
                    this.find(".wcp-playlist-items:eq("+i+")").addClass("wcp-menu-selected");
                }
                opts[this.context].keepHidden = true;
                this.zoom(0);

                wjsButton = this.find(".wcp-play");
                if (wjsButton.length != 0) wjsButton.removeClass("wcp-play").addClass("wcp-pause");

                wjsButton = this.find(".wcp-replay");
                if (wjsButton.length != 0) wjsButton.removeClass("wcp-replay").addClass("wcp-pause");

                this.vlc.playlist.currentItem = i;

                positionChanged.call(this,0);
                this.find(".wcp-time-current").text("");
                this.find(".wcp-time-total").text("");
            }
        }
    } else return this.vlc.playlist.currentItem;
    return this;
}

wjs.prototype.itemDesc = function(getDesc) {
    if (typeof getDesc === 'number') {
        if (getDesc > -1 && getDesc < this.itemCount()) {
            wjsDesc = JSON.stringify(this.vlc.playlist.items[getDesc]);
            return JSON.parse(wjsDesc.replace('"title":"[custom]','"title":"').split('\\"').join('"').split('"{').join('{').split('}"').join('}'));
        } else return false;
    }
    return false;
}

wjs.prototype.state = function() {
    reqState = this.vlc.state;
    if (reqState == 0) return "idle";
    else if (reqState == 1) return "opening";
    else if (reqState == 2) return "buffering";
    else if (reqState == 3) return "playing";
    else if (reqState == 4) return "paused";
    else if (reqState == 5) return "stopping";
    else if (reqState == 6) return "ended";
    else if (reqState == 7) return "error";
    return false;
}

wjs.prototype.aspectRatio = function(newRatio) {
    if (typeof newRatio === 'string') {
        opts[this.context].crop = "Default";
        if (opts[this.context].zoom > 0) opts[this.context].zoom = 1;
        opts[this.context].aspectRatio = newRatio;
        autoResize();
    } else return opts[this.context].aspectRatio;
    return this;
}

wjs.prototype.crop = function(newCrop) {
    if (typeof newCrop === 'string') {
        opts[this.context].aspectRatio = "Default";
        if (opts[this.context].zoom > 0) opts[this.context].zoom = 1;
        opts[this.context].crop = newCrop;
        autoResize();
    } else return opts[this.context].crop;
    return this;
}

wjs.prototype.zoom = function(newZoom) {
    if (typeof newZoom === 'number') {
        opts[this.context].aspectRatio = "Default";
        opts[this.context].crop = "Default";
        opts[this.context].zoom = newZoom;
        autoResize();
    } else return opts[this.context].zoom;
    return this;
}

wjs.prototype.advanceItem = function(newX,newY) {
    if (typeof newX === 'number' && typeof newY === 'number') {
        this.vlc.playlist.advanceItem(newX,newY);
        if (this.find(".wcp-playlist").is(":visible")) printPlaylist.call(this);
    } else return false;
    return this;
}

wjs.prototype.removeItem = function(remItem) {
    if (typeof remItem === 'number') {
         if (this.itemCount() <= 2) {
             if (this.vlc.playlist.removeItem(remItem)) {
                 this.find(".wcp-prev").hide(0);
                 this.find(".wcp-next").hide(0);
             }
         } else this.vlc.playlist.removeItem(remItem);
        if (this.find(".wcp-playlist").is(":visible")) printPlaylist.call(this);
        // hide playlist button if less then 2 playlist items
        if (this.itemCount() < 2) this.find(".wcp-playlist-but").css({ display: "none" });
    } else return false;
    return this;
}

wjs.prototype.clearPlaylist = function() {
    this.stop();
    this.vlc.playlist.clear();
    this.find(".wcp-time-total").text("");
    if (this.find(".wcp-playlist").is(":visible")) printPlaylist.call(this);
    if (this.find(".wcp-playlist-but").is(":visible")) this.find(".wcp-playlist-but").css({ display: "none" });
    return this;
}

function progressHoverIn(e) {
    if (this.vlc.length) {
        var rect = this.wrapper[0].getBoundingClientRect();
        if (e.pageX >= rect.left && e.pageX <= rect.right) {
            var newtime = Math.floor(this.vlc.length * ((e.pageX - rect.left) / this.wrapper.width()));
            if (newtime > 0) {
                this.find(".wcp-tooltip-inner").text(parseTime(newtime));
                var offset = Math.floor(this.find(".wcp-tooltip").width() / 2);
                if (e.pageX >= (offset + rect.left) && e.pageX <= (rect.right - offset)) {
                    this.find(".wcp-tooltip").css("left",((e.pageX - rect.left) - offset)+"px");
                } else if (e.pageX < (rect.left + offset)) this.find(".wcp-tooltip").css("left",rect.left+"px");
                else if (e.pageX > (rect.right - offset)) this.find(".wcp-tooltip").css("left",(rect.right - this.find(".wcp-tooltip").width())+"px");
                this.find(".wcp-tooltip").show(0);
            }
        } else this.find(".wcp-tooltip").hide(0);
    }
}

function progressMouseMoved(e) {
    if (this.vlc.length) {
        var rect = this.wrapper[0].getBoundingClientRect();
        if (e.pageX >= rect.left && e.pageX <= rect.right) {
            var newtime = Math.floor(this.vlc.length * ((e.pageX - rect.left) / this.wrapper.width()));
            if (newtime > 0) {
                this.find(".wcp-tooltip-inner").text(parseTime(newtime));
                var offset = Math.floor(this.find(".wcp-tooltip").width() / 2);
                if (e.pageX >= (offset + rect.left) && e.pageX <= (rect.right - offset)) {
                    this.find(".wcp-tooltip").css("left",((e.pageX - rect.left) - offset)+"px");
                } else if (e.pageX < (rect.left + offset)) this.find(".wcp-tooltip").css("left",rect.left+"px");
                else if (e.pageX > (rect.right - offset)) this.find(".wcp-tooltip").css("left",(rect.right - this.find(".wcp-tooltip").width())+"px");
                this.find(".wcp-tooltip").show(0);
            }
        } else this.find(".wcp-tooltip").hide(0);
    }
}

function seekDragEnded(e,wjsMulti) {

    var rect = this.wrapper[0].getBoundingClientRect();

    if (wjsMulti) {
        var wjsLogic = (e.pageX >= rect.left && e.pageX <= rect.right && e.pageY >= rect.top && e.pageY <= rect.bottom);
        this.find(".wcp-tooltip").fadeOut();
    } else {
        var wjsLogic = (e.pageX >= rect.left && e.pageX <= rect.right);
        this.find(".wcp-tooltip").hide(0);
    }

    if (wjsLogic) {
        p = (e.pageX - rect.left) / (rect.right - rect.left);
        this.find(".wcp-progress-seen").css("width", (p*100)+"%");
        this.vlc.position = p;
        this.find(".wcp-time-current").text(this.find(".wcp-tooltip-inner").text());
    }

}

function volDragEnded(e,wjsMulti) {

    if (wjsMulti) {
        var rect = this.wrapper[0].getBoundingClientRect();
        var wjsLogic = (e.pageX >= rect.left && e.pageX <= rect.right && e.pageY >= rect.top && e.pageY <= rect.bottom);
    } else var wjsLogic = true;

    var rect = this.find(".wcp-vol-bar")[0].getBoundingClientRect();

    if (wjsLogic) {
        var volControl = this.find(".wcp-vol-control");

        if (e.pageX >= rect.right) {
            p = 1;
            setTimeout(function() { volControl.animate({ width: 0 },200); },1500);
        } else if (e.pageX <= rect.left)  {
            p = 0;
            setTimeout(function() { volControl.animate({ width: 0 },200); },1500);
        } else {
            p = (e.pageX - rect.left) / (rect.right - rect.left);
            if (e.pageY < rect.top) setTimeout(function() { volControl.animate({ width: 0 },200); },1500);
            else if (e.pageY > rect.bottom) setTimeout(function() { volControl.animate({ width: 0 },200); },1500);
        }
        this.volume(Math.floor(200* p)+5);
    }

}

function mouseClickEnd(e) {
    clearInterval(vlcs[this.context].hideUI);
    this.wrapper.css({cursor: 'default'});

    vlcs[this.context].hideUI = setTimeout(function(i) { return function() { hideUI.call(players[i]); } }(this.context),3000);
    if (seekDrag) {
        seekDrag = false;
        if (window.document.webkitFullscreenElement != null || $(".webchimeras").length == 1) seekDragEnded.call(this,e);
        else $('.webchimeras').each(function(i, obj) { seekDragEnded.call(getContext(obj),e,true); });
    }
    if (volDrag) {
        volDrag = false;
        if (window.document.webkitFullscreenElement != null || $(".webchimeras").length == 1) volDragEnded.call(this,e);
        else $('.webchimeras').each(function(i, obj) { volDragEnded.call(getContext(obj),e,true); });
    }
}

function seekDragMoved(e,wjsMulti) {

    var rect = this.wrapper[0].getBoundingClientRect();

    if (wjsMulti) var wjsLogic = (e.pageX >= rect.left && e.pageX <= rect.right && e.pageY >= rect.top && e.pageY <= rect.bottom);
    else var wjsLogic = (e.pageX >= rect.left && e.pageX <= rect.right);

    if (wjsLogic) {
        p = (e.pageX - rect.left) / (rect.right - rect.left);
        this.find(".wcp-progress-seen").css("width", (p*100)+"%");
        vlc = this.vlc;
        var newtime = Math.floor(vlc.length * ((e.pageX - rect.left) / this.wrapper.width()));
        if (newtime > 0) {
            this.find(".wcp-tooltip-inner").text(parseTime(newtime));
            var offset = Math.floor(this.find(".wcp-tooltip").width() / 2);
            if (e.pageX >= (offset + rect.left) && e.pageX <= (rect.right - offset)) {
                this.find(".wcp-tooltip").css("left",((e.pageX - rect.left) - offset)+"px");
            } else if (e.pageX < (rect.left + offset)) this.find(".wcp-tooltip").css("left",rect.left+"px");
            else if (e.pageX > (rect.right - offset)) this.find(".wcp-tooltip").css("left",(rect.right - this.find(".wcp-tooltip").width())+"px");
            this.find(".wcp-tooltip").show(0);
        }
    }
}

function volDragMoved(e,wjsMulti) {

    var rect = this.find(".wcp-vol-bar")[0].getBoundingClientRect();

    if (wjsMulti) {
        var rectWrapper = this.wrapper.parent()[0].getBoundingClientRect();
        var wjsLogic = (e.pageX >= rectWrapper.left && e.pageX <= rectWrapper.right && e.pageY >= rectWrapper.top && e.pageY <= rectWrapper.bottom);
    } else var wjsLogic = true;

    if (wjsLogic && e.pageX >= rect.left && e.pageX <= rect.right) {
        p = (e.pageX - rect.left) / (rect.right - rect.left);
        this.volume(Math.floor(200* p)+5);
    }
}

function mouseMoved(e) {
    if (seekDrag) {
        if (window.document.webkitFullscreenElement != null || $(".webchimeras").length == 1) seekDragMoved.call(this,e);
        else $('.webchimeras').each(function(i, obj) { seekDragMoved.call(getContext(obj),e,true); });
    }
    if (volDrag) {
        if (window.document.webkitFullscreenElement != null || $(".webchimeras").length == 1) volDragMoved.call(this,e);
        else $('.webchimeras').each(function(i, obj) { volDragMoved.call(getContext(obj),e,true); });
    }
}

wjs.prototype.catchEvent = function(wjsEvent,wjsFunction) {
    var saveContext = this;
    this.vlc.events.on(wjsEvent, function(event) { return wjsFunction.call(saveContext,event); } );
    return this;
}

wjs.prototype.video = function(newBool) {
    if (typeof newBool !== 'undefined') {
        if (newBool === true) {
            if (opts[this.context].zoom == 0) {
                opts[this.context].zoom = opts[this.context].lastZoom;
                delete opts[this.context].lastZoom;
                autoResize();
                return true;
            } else return false;
        } else {
            if (opts[this.context].zoom > 0) {
                opts[this.context].lastZoom = opts[this.context].zoom;
                opts[this.context].zoom = 0;
                autoResize();
                return true;
            } else return false;
        }
    }
}

wjs.prototype.playlist = function(newBool) {
    if (typeof newBool !== 'undefined') {
        if (newBool === true) return showPlaylist.call(this);
        else return hidePlaylist.call(this);
    } else return this.find(".wcp-playlist")[0];
}

wjs.prototype.subtitles = function(newBool) {
    if (typeof newBool !== 'undefined') {
        if (newBool === true) return showSubtitles.call(this);
        else return hideSubtitles.call(this);
    } else return this.find(".wcp-subtitles")[0];
}

wjs.prototype.ui = function(newBool) {
    if (typeof newBool !== 'undefined') {
        if (newBool === true) {
            if (opts[this.context].uiHidden) {
                opts[this.context].uiHidden = false;
                this.find(".wcp-titlebar").stop().show(0);
                this.find(".wcp-toolbar").stop().show(0);
                if (this.wrapper.css('cursor') == 'none') this.wrapper.css({cursor: 'default'});
                return true;
            } else return false;
        } else {
            if (!opts[this.context].uiHidden) {
                opts[this.context].uiHidden = true;
                this.find(".wcp-titlebar").stop().hide(0);
                this.find(".wcp-toolbar").stop().hide(0);
                this.find(".wcp-tooltip").stop().hide(0);
                if (this.wrapper.css('cursor') == 'none') this.wrapper.css({cursor: 'default'});
                return true;
            } else return false;
        }
    } else return this;
}

wjs.prototype.notify = function(newMessage) {
    this.find(".wcp-notif").text(newMessage);
    this.find(".wcp-notif").stop().show(0);
    if (opts[this.context].notifTimer) clearTimeout(opts[this.context].notifTimer);
    wjsPlayer = this;
    opts[this.context].notifTimer = setTimeout(function() { wjsPlayer.find(".wcp-notif").fadeOut(1500); },1000);
}

wjs.prototype.toggleFullscreen = function() {
    if (window.document.webkitFullscreenElement == null) return fullscreenOn.call(this);
    else return fullscreenOff.call(this);
}

wjs.prototype.fullscreen = function(newBool) {
    if (typeof newBool !== 'undefined') {
        if (newBool === true) return fullscreenOn.call(this);
        else return fullscreenOff.call(this);
    } else {
        if (window.document.webkitFullscreenElement == null) return false;
        else return true;
    }
}

wjs.prototype.animatePause = function() {
    this.find(".wcp-anim-basic").css("fontSize", "50px");
    this.find(".wcp-anim-basic").css("padding", "7px 27px");
    this.find(".wcp-anim-basic").css("borderRadius", "12px");
    this.find(".wcp-pause-anim").fadeIn(200).fadeOut(200);
    this.find(".wcp-anim-basic").animate({ fontSize: "80px", padding: "7px 30px" },400);
}

function onFullscreenChanged() {
    var self = this;
    var isFullscreen = (window.document.webkitFullscreenElement !== null);

    if(isFullscreen) {
        if (opts[self.context].titleBar == "none" || opts[self.context].titleBar == "minimized") {
            self.find(".wcp-titlebar").hide(0);
            if (self.find(".wcp-status").css("top") == "35px") self.find(".wcp-status").css("top", "10px");
            if (self.find(".wcp-notif").css("top") == "35px") self.find(".wcp-notif").css("top", "10px");
        } else {
            if (self.find(".wcp-status").css("top") == "10px") self.find(".wcp-status").css("top", "35px");
            if (self.find(".wcp-notif").css("top") == "10px") self.find(".wcp-notif").css("top", "35px");
        }
        switchClass(self.find(".wcp-maximize"),"wcp-maximize","wcp-minimize");
        this.find(".wcp-toolbar").addClass("state-fullscreen");
        this.find(".wcp-playlist").addClass("state-fullscreen");
    }
    else {
        if (["none","fullscreen"].indexOf(opts[self.context].titleBar) > -1) {
            self.find(".wcp-titlebar").hide(0);
            if (self.find(".wcp-status").css("top") == "35px") self.find(".wcp-status").css("top", "10px");
            if (self.find(".wcp-notif").css("top") == "35px") self.find(".wcp-notif").css("top", "10px");
        } else {
            if (self.find(".wcp-status").css("top") == "10px") self.find(".wcp-status").css("top", "35px");
            if (self.find(".wcp-notif").css("top") == "10px") self.find(".wcp-notif").css("top", "35px");
        }

        switchClass(self.find(".wcp-minimize"),"wcp-minimize","wcp-maximize");
        this.find(".wcp-toolbar").removeClass("state-fullscreen");
        this.find(".wcp-playlist").removeClass("state-fullscreen");

        if (vlcs[self.context].multiscreen) {
            self.find(".wcp-titlebar").hide(0);
            self.find(".wcp-toolbar").hide(0);
            self.find(".wcp-tooltip").hide(0);
            self.wrapper.css({cursor: 'pointer'});
            if (!self.vlc.mute) self.vlc.mute = true;
        }
    }
}

function fullscreenOn() {
    if (window.document.webkitFullscreenElement == null) {
        var wcpWrapper = this.wrapper[0];
        if (wcpWrapper.webkitRequestFullscreen) {
            wcpWrapper.webkitRequestFullscreen();
        }
        else if (wcpWrapper.requestFullscreen) {
            wcpWrapper.requestFullscreen();
        }

        return true;
    }
    else {
        return false;
    }
}

function fullscreenOff() {
    if (window.document.webkitFullscreenElement != null) {
        if (window.document.webkitCancelFullScreen) {
            window.document.webkitCancelFullScreen();
        }
        else if (window.document.cancelFullScreen) {
            window.document.cancelFullScreen();
        }

        return true;
    }
    else {
        return false;
    }
}

// player event handlers
function timePassed(t) {
    if(this._playbackMode === 2) {
        var skipOffset = parseInt(this.find(".wcp-ad-info-text").data("skip-offset")),
            secondsLeft;

        if(skipOffset > 0) {
            secondsLeft = Math.round(skipOffset - t/1000);
            if(secondsLeft > 0) {
                this.find(".wcp-ad-info-text").text("Реклама").data("can-skip", 0);
                this.find(".wcp-ad-info-waiting").show().text(secondsLeft);
            }
            else {
                this.find(".wcp-ad-info-text").text("Пропустить рекламу").data("can-skip", 1);
                this.find(".wcp-ad-info-waiting").hide();
            }
        }
    }

    if (t > 0) this.find(".wcp-time-current").text(parseTime(t,this.vlc.length));
    else if (this.find(".wcp-time-current").text() != "" && this.find(".wcp-time-total").text() == "") this.find(".wcp-time-current").text("");

    if (typeof opts[this.context].subtitles === 'undefined') opts[this.context].subtitles = [];

    if (opts[this.context].subtitles.length > 0) {
        // End show subtitle text (external subtitles)
        var nowSecond = (t - opts[this.context].subDelay) /1000;
        if (opts[this.context].trackSub > -2) {
            var subtitle = -1;

            var os = 0;
            for (os in opts[this.context].subtitles) {
                if (os > nowSecond) break;
                subtitle = os;
            }

            if (subtitle > 0) {
                if(subtitle != opts[this.context].trackSub) {
                    if ((opts[this.context].subtitles[subtitle].t.match(new RegExp("<", "g")) || []).length == 2) {
                        if (!(opts[this.context].subtitles[subtitle].t.substr(0,1) == "<" && opts[this.context].subtitles[subtitle].t.slice(-1) == ">")) {
                            opts[this.context].subtitles[subtitle].t = opts[this.context].subtitles[subtitle].t.replace(/<\/?[^>]+(>|$)/g, "");
                        }
                    } else if ((opts[this.context].subtitles[subtitle].t.match(new RegExp("<", "g")) || []).length > 2) {
                        opts[this.context].subtitles[subtitle].t = opts[this.context].subtitles[subtitle].t.replace(/<\/?[^>]+(>|$)/g, "");
                    }
                    this.find(".wcp-subtitle-text").html(nl2br(opts[this.context].subtitles[subtitle].t));
                    opts[this.context].trackSub = subtitle;
                } else if (opts[this.context].subtitles[subtitle].o < nowSecond) {
                    this.find(".wcp-subtitle-text").html("");
                }
            }
        }
        // End show subtitle text (external subtitles)
    }
}
function positionChanged(position) {
    opts[this.context].lastPos = position;
    if (!seekDrag) this.find(".wcp-progress-seen")[0].style.width = (position*100)+"%";
}

function livePositionChanged(event) {
    positionChanged.call(this, event.position);
    if(event.is_live) {
        this.find(".wcp-live").addClass("state-live").removeClass("state-timeshift").removeClass("state-unknown");
    }
    else {
        this.find(".wcp-live").addClass("state-timeshift").removeClass("state-live").removeClass("state-unknown");
    }
}

function isOpening() {
    if (this.currentItem() != opts[this.context].lastItem) {
        opts[this.context].lastItem = this.currentItem();
        if (this.find(".wcp-playlist").is(":visible")) printPlaylist.call(this);
        this.find(".wcp-title")[0].innerHTML = this.itemDesc(this.currentItem()).title;
    }
    // var style = window.getComputedStyle(this.find(".wcp-status")[0]);
    // if (style.display === 'none') this.find(".wcp-status").show();
    // this.find(".wcp-status").text("Opening");
}

function isMediaChanged() {
    opts[this.context].currentSub = 0;
    opts[this.context].subtitles = [];

    this.find(".wcp-subtitle-text").html("");
    if (this.find(".wcp-subtitles").is(":visible")) this.find(".wcp-subtitles").hide(0);
    this.find(".wcp-subtitle-but").hide(0);

    opts[this.context].firstTime = true;
}

function isBuffering(percent) {
    this.find(".wcp-status").text("Buffering "+percent+"%");
    this.find(".wcp-status").stop().show(0);
    if (percent == 100) this.find(".wcp-status").fadeOut(1200);
}

function gotEngineMessage(msg) {
    if(!msg || msg.length == 0) {
        this.find(".wcp-status").fadeOut(1200);
    }
    else {
        this.find(".wcp-status").text(msg);
        this.find(".wcp-status").stop().show(0);
    }
}

function setPlaybackMode(mode, params) {
    if(mode === 2) {
        this.find(".wcp-progress-bar").removeClass("state-live").addClass("state-vod");
        this.find(".wcp-play").hide();
        this.find(".wcp-pause").hide();
        this.find(".wcp-prev").hide();
        this.find(".wcp-next").hide();
        this.find(".wcp-playlist-but").hide();
        this.find(".wcp-stop").hide();
        this.find(".wcp-time").hide();
        this.find(".wcp-ad-info").show();
        this.find(".wcp-ad-disable").show();

        if(params) {
            var secondsUntilSkip = parseSecondsFromTime(decodeURIComponent(params.skipoffset));

            if(secondsUntilSkip > 0) {
                this.find(".wcp-ad-info-text").text("Реклама").data("can-skip", 0).data("skip-offset", secondsUntilSkip);
                this.find(".wcp-ad-info-waiting").show().text(secondsUntilSkip);
            }
            else {
                this.find(".wcp-ad-info-text").text("Пропустить рекламу").data("can-skip", 1);
                this.find(".wcp-ad-info-waiting").hide();
            }

            if(params.noads_link) {
                this.find(".wcp-ad-disable").show().data("url", decodeURIComponent(params.noads_link)).text(decodeURIComponent(params.noads_text));
            }
            else {
                this.find(".wcp-ad-disable").hide().data("url", "").text("");
            }
        }
    }
    else {
        if(mode === 1) {
            this.find(".wcp-live").show();
            this.find(".wcp-progress-bar").removeClass("state-vod").addClass("state-live");
        }
        else {
            this.find(".wcp-live").hide();
            this.find(".wcp-progress-bar").removeClass("state-live").addClass("state-vod");
        }
        this.find(".wcp-play").show();
        this.find(".wcp-pause").show();

        if (this.itemCount() > 1) {
            this.find(".wcp-prev").show(0);
            this.find(".wcp-next").show(0);
        }
        else {
            this.find(".wcp-prev").hide(0);
            this.find(".wcp-next").hide(0);
        }
        this.find(".wcp-stop").show();
        this.find(".wcp-time").show();
        this.find(".wcp-ad-info").hide();
        this.find(".wcp-ad-disable").hide();
    }

    this._playbackMode = mode;
    this._playbackParams = params;
}

function playerSetup(conf) {
    this.volume(conf.volume);
}

function isPlaying() {
    if (opts[this.context].keepHidden) {
        opts[this.context].keepHidden = false;
        itemSetting = this.itemDesc(this.currentItem()).setting;
        if (itemSetting && itemSetting.zoom) {
            opts[this.context].zoom = itemSetting.zoom;
        }
        else {
            opts[this.context].zoom = 1;
            autoResize();
        }
    }

    if (opts[this.context].firstTime) {
        if (this.find(".wcp-title").text() != this.itemDesc(this.currentItem()).title) {
            this.find(".wcp-title")[0].innerHTML = this.itemDesc(this.currentItem()).title;
        }
        opts[this.context].firstTime = false;
        if (this.vlc.subtitles.track > 0) this.vlc.subtitles.track = 0;
        opts[this.context].currentSub = 0;
        opts[this.context].trackSub = -1;
        totalSubs = this.vlc.subtitles.count;
        itemSetting = this.itemDesc(this.currentItem()).setting;

        if(itemSetting) {
            // set default aspect ratio
            if (itemSetting.aspectRatio) opts[this.context].aspectRatio = itemSetting.aspectRatio;
            else {
                opts[this.context].aspectRatio = "Default";
                autoResize();
            }

            // set default crop
            if (itemSetting.crop) opts[this.context].crop = itemSetting.crop;
            else {
                opts[this.context].crop = "Default";
                autoResize();
            }

            // set default zoom
            if (itemSetting.zoom) opts[this.context].zoom = itemSetting.zoom;
            else {
                opts[this.context].zoom = 1;
                autoResize();
            }

            if (itemSetting.subtitles) totalSubs += Object.keys(itemSetting.subtitles).length;
        }

        opts[this.context].subDelay = 0;

        if (totalSubs > 0) this.find(".wcp-subtitle-but").show(0);

    }
    var style = window.getComputedStyle(this.find(".wcp-status")[0]);
    if (style.display !== 'none') this.find(".wcp-status").fadeOut(1200);

    // hide playlist
    hidePlaylist.call(this);

    // update playlist action button
    this.find(".wcp-playlist .wcp-menu-selected").addClass("state-playing");
}

function hasStopped() {
    opts[this.context].keepHidden = true;
    this.zoom(0);

    $(this.canvas).hide();
    $(this.video).hide();

    this.find(".wcp-time-current").text("");
    this.find(".wcp-time-total").text("");
    this.find(".wcp-title").text("");

    // update playlist action button
    this.find(".wcp-playlist .wcp-menu").removeClass("state-playing");

    setPlaybackMode.call(this, 0);
    allowSleep();
}

function hasEnded() {
    opts[this.context].keepHidden = true;
    this.zoom(0);

    if (this.currentItem() +1 < this.itemCount()) {
        this.next();
    }
    else {
        hasStopped.call(this);
    }

    // switchClass(this.find(".wcp-pause"),"wcp-pause","wcp-replay");
    // if (this.time() > 0) {
    //     if (opts[this.context].lastPos < 0.95) {
    //         // Reconnect if connection to server lost
    //         this.vlc.playlist.currentItem =opts[this.context].lastItem;
    //         this.vlc.playlist.play();
    //         this.vlc.position = opts[this.context].lastPos;

    //         wjsButton = this.find(".wcp-play");
    //         if (wjsButton.length != 0) wjsButton.removeClass("wcp-play").addClass("wcp-pause");

    //         wjsButton = this.find(".wcp-replay");
    //         if (wjsButton.length != 0) wjsButton.removeClass("wcp-replay").addClass("wcp-pause");

    //         positionChanged.call(this,0);
    //         this.find(".wcp-time-current").text("");
    //         this.find(".wcp-time-total").text("");
    //         // End Reconnect if connection to server lost
    //     } else {
    //         if (opts[this.context].loop && this.currentItem() +1 == this.itemCount()) this.playItem(this.currentItem());
    //         else if (this.currentItem() +1 < this.itemCount()) this.next();
    //     }
    // }
}
// end player event handlers

function singleResize(width,height) {
    if(DEBUG_RESIZE) {
        console.log("singleResize: width=" + width + " height=" + height + " zoom=" + opts[this.context].zoom);
    }
    var container = $(this.context),
        canvasParent = $(this.canvas).parent()[0];

    if(width == -1) {
        width = container.width();
        if(DEBUG_RESIZE) {
            console.log("singleResize: use container width: " + width);
        }
    }

    if(height == -1) {
        height = container.height();
        if(DEBUG_RESIZE) {
            console.log("singleResize: use container height: " + height);
        }
    }

    this.canvas.width = width;
    this.canvas.height = height;

    this.video.width = width;
    this.video.height = height;

    if (opts[this.context].aspectRatio != "Default" && opts[this.context].aspectRatio.indexOf(":") > -1) {
        var res = opts[this.context].aspectRatio.split(":");
        var ratio = gcd(this.canvas.width,this.canvas.height);
    }
    var destAspect = container.width() / container.height();

    if (ratio) var sourceAspect = (ratio * parseFloat(res[0])) / (ratio * parseFloat(res[1]));
    else var sourceAspect = this.canvas.width / this.canvas.height;

    if (opts[this.context].crop != "Default" && opts[this.context].crop.indexOf(":") > -1) {
        var res = opts[this.context].crop.split(":");
        var ratio = gcd(this.canvas.width,this.canvas.height);
        var sourceAspect = (ratio * parseFloat(res[0])) / (ratio * parseFloat(res[1]));
    }

    var cond = destAspect > sourceAspect;

    if (opts[this.context].crop != "Default" && opts[this.context].crop.indexOf(":") > -1) {
        if (cond) {
            canvasParent.style.height = "100%";
            canvasParent.style.width = ( ((container.height() * sourceAspect) / container.width() ) * 100) + "%";
        } else {
            canvasParent.style.height = ( ((container.width() / sourceAspect) /container.height() ) * 100) + "%";
            canvasParent.style.width = "100%";
        }
        var sourceAspect = this.canvas.width / this.canvas.height;
        futureWidth = ( ((canvasParent.offsetHeight * sourceAspect) / canvasParent.offsetWidth ) *canvasParent.offsetWidth);
        if (futureWidth < canvasParent.offsetWidth) {
            var sourceAspect = this.canvas.height / this.canvas.width;
            this.canvas.style.width = canvasParent.offsetWidth+"px";
            this.canvas.style.height = ( ((canvasParent.offsetWidth * sourceAspect) / canvasParent.offsetHeight ) *canvasParent.offsetHeight) + "px";
        } else {
            this.canvas.style.height = canvasParent.offsetHeight+"px";
            this.canvas.style.width = ( ((canvasParent.offsetHeight * sourceAspect) / canvasParent.offsetWidth ) *canvasParent.offsetWidth) + "px";
        }

        this.video.style.width = this.canvas.style.width;
        this.video.style.height = this.canvas.style.height;
    } else {
        if (cond) {
            canvasParent.style.height = (100*opts[this.context].zoom)+"%";
            canvasParent.style.width = ( ((container.height() * sourceAspect) / container.width() ) * 100 *opts[this.context].zoom) + "%";
        } else {
            canvasParent.style.height = ( ((container.width() / sourceAspect) /container.height() ) * 100*opts[this.context].zoom) + "%";
            canvasParent.style.width = (100*opts[this.context].zoom)+"%";
        }
        this.canvas.style.height = "100%";
        this.canvas.style.width = "100%";

        this.video.style.height = "100%";
        this.video.style.width = "100%";
    }
}

function autoResize() {
    $('.webchimeras').each(function(i, obj) {
        wjsPlayer = getContext(obj);
        if (wjsPlayer.wrapper[0]) {
            // resize status font size
            fontSize = calcFontSize(wjsPlayer);

            wjsPlayer.find(".wcp-status").css('fontSize', fontSize);
            wjsPlayer.find(".wcp-notif").css('fontSize', fontSize);
            wjsPlayer.find(".wcp-subtitle-text").css('fontSize', fontSize);

            if(DEBUG_RESIZE) {
                console.log("autoResize: canvas.width=" + wjsPlayer.canvas.width + " canvas.height=" + wjsPlayer.canvas.height);
            }
            singleResize.call(wjsPlayer,wjsPlayer.canvas.width,wjsPlayer.canvas.height);
        }
    });
}

function hideUI() {
    if (!(vlcs[this.context].multiscreen && window.document.webkitFullscreenElement == null)) {
        if (seekDrag || volDrag || ($(this.find(".wcp-toolbar").selector + ":hover").length > 0 && vlcs[this.context].timestampUI + 20 > Math.floor(Date.now() / 1000))) {
            vlcs[this.context].hideUI = setTimeout(function(i) { return function() { hideUI.call(i); } }(this),3000);
            return;
        }
        if (window.document.webkitFullscreenElement == null) {
            if (["both","minimized"].indexOf(opts[this.context].titleBar) > -1) this.find(".wcp-titlebar").stop().fadeOut();
        } else {
            if (["both","fullscreen"].indexOf(opts[this.context].titleBar) > -1) this.find(".wcp-titlebar").stop().fadeOut();
        }
        this.find(".wcp-toolbar").stop().fadeOut();
        this.find(".wcp-tooltip").stop().fadeOut();
        this.wrapper.css({cursor: 'none'});
    }
}

function showPlaylist() {
    if (!this.find(".wcp-playlist").is(":visible")) {
        if (this.find(".wcp-subtitles").is(":visible")) this.find(".wcp-subtitles").hide(0);
        this.find(".wcp-playlist").show(0);
        printPlaylist.call(this);
    }
}

function hidePlaylist() {
    if (this.find(".wcp-playlist").is(":visible")) {
        this.find(".wcp-playlist-items .items-container").sortable("destroy");
        this.find(".wcp-playlist").hide(0);
    }
}

function showSubtitles() {
    if (!this.find(".wcp-subtitles").is(":visible")) {
        if (this.find(".wcp-playlist").is(":visible")) {
            this.find(".wcp-playlist-items .items-container").sortable("destroy");
            this.find(".wcp-playlist").hide(0);
        }
        this.find(".wcp-subtitles").show(0);
        printSubtitles.call(this);
    }
}

function printPlaylist() {
    playlistItems = this.find(".wcp-playlist-items");
    oi = 0;
    if (this.itemCount() > 0) {
        generatePlaylist = "";
        for (oi = 0; oi < this.itemCount(); oi++) {
            if (this.vlc.playlist.items[oi].title.indexOf("[custom]") != 0) {
                var plstring = this.itemDesc(oi).title;
                if (plstring.indexOf("http://") == 0) {
                    // extract filename from url
                    var tempPlstring = plstring.substring(plstring.lastIndexOf('/')+1);
                    if (tempPlstring.length > 3) plstring = tempPlstring;
                    delete tempPlstring;
                }
                if (plstring.indexOf(".") > -1) {
                    // remove extension
                    var tempPlstring = plstring.replace("."+plstring.split('.').pop(),"");
                    if (tempPlstring.length > 3) plstring = tempPlstring;
                    delete tempPlstring;
                }
                plstring = unescape(plstring);
                plstring = plstring.split('_').join(' ');
                plstring = plstring.split('.').join(' ');
                plstring = plstring.split('  ').join(' ');
                plstring = plstring.split('  ').join(' ');
                plstring = plstring.split('  ').join(' ');

                // capitalize first letter
                plstring = plstring.charAt(0).toUpperCase() + plstring.slice(1);

                if (plstring != this.itemDesc(oi).title) this.vlc.playlist.items[oi].title = "[custom]"+plstring;
            }
            generatePlaylist += '<li class="wcp-menu-item wcp-playlist-item';
            if (oi == this.currentItem()) {
                generatePlaylist += ' wcp-menu-selected';
                if(this.playing()) {
                    generatePlaylist += ' state-playing';
                }
            }
            if (this.itemDesc(oi).disabled) {
                generatePlaylist += ' wcp-disabled';
            }
            generatePlaylist += '"><div class="wcp-disabler-hold"><div class="wcp-disabler"><div class="wcp-disabler-dot"></div></div></div>';
            generatePlaylist += '<div class="playlist-item-title">'+this.itemDesc(oi).title+'</div>';
            generatePlaylist += '<div class="playlist-item-actions">';
            generatePlaylist += '<div class="playlist-item-action-play"></div>';
            generatePlaylist += '</div>';
            generatePlaylist += '</li>';
        }
        // playlistItems.css('overflowY', 'scroll');
        playlistItems.find(".items-container").html("");
        playlistItems.find(".items-container").html(generatePlaylist);

        // playlistItems.css('overflow', 'hidden');
        playlistItems.mCustomScrollbar({
            axis: "y"
        });

        if (playlistItems.outerHeight() < (oi* parseInt(playlistItems.find(".wcp-playlist-item").css("height")))) {
            playlistItems.css("cursor","pointer");
        } else playlistItems.css("cursor","default");

        this.find(".wcp-disabler-hold").click(function(e) {
            if (!e) var e = window.event;
            e.cancelBubble = true;
            if (e.stopPropagation) e.stopPropagation();
            plItem = $(this).parent();
            wjsPlayer = getContext(this);
            if (!plItem.hasClass("wcp-menu-selected")) {
                if (!wjsPlayer.itemDesc(plItem.index()).disabled) {
                    plItem.addClass("wcp-disabled");
                    wjsPlayer.vlc.playlist.items[plItem.index()].disabled = true;
                } else {
                    plItem.removeClass("wcp-disabled");
                    wjsPlayer.vlc.playlist.items[plItem.index()].disabled = false;
                }
            }
        });
        this.find(".wcp-playlist-item .playlist-item-action-play").click(function() {
            wjsPlayer = getContext(this);
            if (wjsPlayer.itemDesc($(this).index()).disabled) {
                wjsPlayer.vlc.playlist.items[$(this).index()].disabled = false;
                $(this).removeClass("wcp-disabled");
            }

            if ($(this).parent().parent().hasClass("wcp-menu-selected")) {
                wjsPlayer.togglePause();
            }
            else {
                wjsPlayer.playItem($(this).index());
                printPlaylist.call(wjsPlayer);
            }
        });
        this.find(".wcp-playlist-items .items-container").sortable({
          placeholder: "sortable-placeholder",
          delay: 250,
          start: function(e,ui) {
              $(ui.item[0]).addClass("sortable-dragging");
              var start_pos = ui.item.index();
              ui.item.data('start_pos', start_pos);
          },
          stop: function(e,ui) {
              $(this).parents(".wcp-wrapper").find(".sortable-dragging").removeClass("sortable-dragging");
          },
          update: function(e,ui) {
              var start_pos = ui.item.data('start_pos');
              var end_pos = ui.item.index();
              getContext(this).advanceItem(start_pos,(end_pos - start_pos));
          }
        });
    } else playlistItems.html("");
}

function printSubtitles() {
    playlistItems = this.find(".wcp-subtitles-items");

    generatePlaylist = "";
    generatePlaylist += '<li class="wcp-menu-item wcp-subtitles-item';
    if (opts[this.context].currentSub == 0) generatePlaylist += ' wcp-menu-selected';
    generatePlaylist += '">None</li>';
    if (this.vlc.subtitles.count > 0) {
        for (oi = 1; oi < this.vlc.subtitles.count; oi++) {
            generatePlaylist += '<li class="wcp-menu-item wcp-subtitles-item';
            if (oi == opts[this.context].currentSub) generatePlaylist += ' wcp-menu-selected';
            generatePlaylist += '">'+this.vlc.subtitles[oi]+'</li>';
        }
    } else oi = 1;

    itemSetting = this.itemDesc(this.currentItem()).setting;

    if (itemSetting.subtitles) {
        itemSubtitles = itemSetting.subtitles;
        for (var k in itemSubtitles) if (itemSubtitles.hasOwnProperty(k)) {
            generatePlaylist += '<li class="wcp-menu-item wcp-subtitles-item';
            if (oi == opts[this.context].currentSub) generatePlaylist += ' wcp-menu-selected';
            generatePlaylist += '">'+k+'</li>';
            oi++;
        }
    }

    playlistItems.html("");
    playlistItems.html(generatePlaylist);

    if (playlistItems.outerHeight() < (oi* parseInt(playlistItems.find(".wcp-subtitles-item").css("height")))) {
        playlistItems.css("cursor","pointer");
    } else playlistItems.css("cursor","default");

    this.find(".wcp-subtitles-item").click(function() {
        wjsPlayer = getContext(this);
        if ($(this).index() == 0) {
            wjsPlayer.vlc.subtitles.track = 0;
            clearSubtitles.call(wjsPlayer);
            wjsPlayer.notify("Subtitle Unloaded");
        } else if ($(this).index() < wjsPlayer.vlc.subtitles.count) {
            wjsPlayer.find(".wcp-subtitle-text").html("");
            opts[wjsPlayer.context].subtitles = [];
            wjsPlayer.vlc.subtitles.track = $(this).index();
            wjsPlayer.notify("Subtitle: "+wjsPlayer.subDesc($(this).index()).language);
        } else {
            wjsPlayer.find(".wcp-subtitle-text").html("");
            opts[wjsPlayer.context].subtitles = [];
            if (wjsPlayer.vlc.subtitles.track > 0) wjsPlayer.vlc.subtitles.track = 0;
            newSub = $(this).index() - wjsPlayer.vlc.subtitles.count;
            if (wjsPlayer.vlc.subtitles.count) newSub++;
            itemSubtitles = itemSetting.subtitles;
            for (var k in itemSubtitles) if (itemSubtitles.hasOwnProperty(k)) {
                newSub--;
                if (newSub == 0) {
                    loadSubtitle.call(wjsPlayer,itemSubtitles[k]);
                    wjsPlayer.notify("Subtitle: "+k);
                    break;
                }
            }
        }
        wjsPlayer.find(".wcp-subtitles").hide(0);
        opts[wjsPlayer.context].currentSub = $(this).index();
        opts[wjsPlayer.context].subDelay = 0;
    });

}

function clearSubtitles() {
    this.find(".wcp-subtitle-text").html("");
    opts[this.context].currentSub = 0;
    opts[this.context].subtitles = [];
    if (this.vlc.subtitles.track > 0) this.vlc.subtitles.track = 0;
    if (this.find(".wcp-subtitles").is(":visible")) printSubtitles.call(this);
}

function loadSubtitle(subtitleElement) {
    if (typeof opts[this.context].subtitles === "undefined") opts[this.context].subtitles = [];
    else if (opts[this.context].subtitles.length) opts[this.context].subtitles = [];

    if (subtitleElement.indexOf("http://dl.opensubtitles.org/") == 0) subtitleElement = "http://dl.opensubtitles.org/en/download/subencoding-utf8/file/"+subtitleElement.split('/').pop();

    wjsPlayer = this;

    var ext = subtitleElement.split('.').pop().toLowerCase();
    if (ext.indexOf("?") > -1) ext = ext.substr(0,ext.indexOf("?"));

    if (subtitleElement.startsWith("http://") || subtitleElement.startsWith("https://")) {
        request(subtitleElement, function (error, response, srt) {
            if (!error && response.statusCode == 200) processSub.call(wjsPlayer,srt,ext);
            else wjsPlayer.notify("Subtitle Error");
        });
    } else {
        fs.readFile(subtitleElement, function (err, srt) {
            console.log(srt.toString('utf8'));
            if (!err) processSub.call(wjsPlayer,srt.toString('utf8'),ext);
            else wjsPlayer.notify("SubtitleError");
        });
    }
}

function processSub(srt,extension) {
    opts[this.context].subtitles = [];

    if (extension == "srt" || extension == "vtt") {

        srt = strip(srt.replace(/\r\n|\r|\n/g, '\n'));

        var srty = srt.split('\n\n'),
            si = 0;

        if (srty[0].substr(0,6).toLowerCase() == "webvtt") si = 1;

        for (s = si; s < srty.length; s++) {
            var st = srty[s].split('\n');
            if (st.length >=2) {
                var n = -1;
                if (st[0].indexOf(' --> ') > -1) var n = 0;
                else if (st[1].indexOf(' --> ') > -1) var n = 1;
                else if (st[2].indexOf(' --> ') > -1)  var n = 2;
                else if (st[3].indexOf(' --> ') > -1)  var n = 3;
                if (n > -1) {
                    stOrigin = st[n]
                    var is = Math.round(toSeconds(strip(stOrigin.split(' --> ')[0])));
                    var os = Math.round(toSeconds(strip(stOrigin.split(' --> ')[1])));
                    var t = st[n+1];
                    if (st.length > n+2) for (j=n+2; j<st.length; j++) t = t + '\n'+st[j];
                    opts[this.context].subtitles[is] = {i:is, o: os, t: t};
                }
            }
        }
    } else if (extension == "sub") {
        srt = srt.replace(/\r\n|\r|\n/g, '\n');

        srt = strip(srt);
        var srty = srt.split('\n');

        var s = 0;
        for (s = 0; s < srty.length; s++) {
            var st = srty[s].split('}{');
            if (st.length >=2) {
              var is = Math.round(st[0].substr(1) /10);
              var os = Math.round(st[1].split('}')[0] /10);
              var t = st[1].split('}')[1].replace('|', '\n');
              if (is != 1 && os != 1) opts[this.context].subtitles[is] = {i:is, o: os, t: t};
            }
        }
    }
    opts[this.context].trackSub = -1;
}

function preventSleep() {
    if(powerSaveBlocker || sleep) {
        powerSaveBlocker?(!sleepId||!powerSaveBlocker.isStarted(sleepId))?sleepId=powerSaveBlocker.start('prevent-display-sleep'):false:sleep.prevent();
    }
}
function allowSleep() {
    if(powerSaveBlocker || sleep) {
        powerSaveBlocker?powerSaveBlocker.isStarted(sleepId)?powerSaveBlocker.stop(sleepId):false:sleep.allow();
    }
}
function getContext(el) {
    if ($(el).hasClass("webchimeras")) return players["#"+$(el).find(".wcp-wrapper")[0].id];
    else if ($(el).hasClass("wcp-wrapper")) return players["#"+el.id];
    else return players["#"+$(el).parents(".wcp-wrapper")[0].id];
}
function parseTime(t,total) {
    if (typeof total === 'undefined') total = t;
    tempHour = ("0" + Math.floor(t / 3600000)).slice(-2);
    tempMinute = ("0" + (Math.floor(t / 60000) %60)).slice(-2);
    tempSecond = ("0" + (Math.floor(t / 1000) %60)).slice(-2);
    if (total >= 3600000) return tempHour+":"+tempMinute+":"+tempSecond;
    else return tempMinute+":"+tempSecond;
}
function nl2br(str,is_xhtml) {
    breakTag=(is_xhtml||typeof is_xhtml==='undefined')?'<br />':'<br>';return (str+'').replace(/([^>\r\n]?)(\r\n|\n\r|\r|\n)/g,'$1'+breakTag+'$2');
}
function calcFontSize(wjsPlayer) {
    if (wjsPlayer.wrapper.width() > 220 && wjsPlayer.wrapper.width() <= 982) {
        fontSize = ((wjsPlayer.wrapper.width() -220) /40) +9;
        if (fontSize < 16) fontSize = 16;
    } else if (wjsPlayer.wrapper.width() > 982 && wjsPlayer.wrapper.width() <= 1600) {
        fontSize = wjsPlayer.wrapper.height()/15;
        if (fontSize > 31) fontSize = 31;
    } else if (wjsPlayer.wrapper.width() > 1600) {
        fontSize = ((wjsPlayer.wrapper.width() - 1600) / 35.5) +31;
    } else fontSize = 20;
    return fontSize;
}
function toSeconds(t){s = 0.0;if(t){p=t.split(':');for(i=0;i<p.length;i++)s=s*60+parseFloat(p[i].replace(',', '.'))};return s}
function strip(s){return s.replace(/^\s+|\s+$/g,"")}
function gcd(a,b){if(b>a){temp=a;a=b;b=temp}while(b!=0){m=a%b;a=b;b=m;}return a}
function sel(context){return $($(this).parents(".wcp-wrapper")[0]).find(context)}
function switchClass(el,fclass,sclass){if(el.hasClass(fclass))el.removeClass(fclass).addClass(sclass)}
function hideSubtitles(){if(this.find(".wcp-subtitles").is(":visible"))this.find(".wcp-subtitles").hide(0)}
wjs.prototype.audioCount=function(){return this.vlc.audio.count}
wjs.prototype.itemCount=function(){return this.vlc.playlist.itemCount}
wjs.prototype.playing=function(){return this.vlc.playing}
wjs.prototype.length=function(){return this.vlc.length}
wjs.prototype.fps=function(){return this.vlc.input.fps}
wjs.prototype.width=function(){return this.canvas.width}
wjs.prototype.height=function(){return this.canvas.height}
wjs.prototype.stateInt=function(){return this.vlc.state}
wjs.prototype.find=function(el){return this.wrapper.find(el)}
wjs.prototype.onMediaChanged=function(wjsFunction){this.catchEvent("MediaChanged",wjsFunction);return this}
wjs.prototype.onIdle=function(wjsFunction){this.catchEvent("NothingSpecial",wjsFunction);return this}
wjs.prototype.onOpening=function(wjsFunction){this.catchEvent("Opening",wjsFunction);return this}
wjs.prototype.onBuffering=function(wjsFunction){this.catchEvent("Buffering",wjsFunction);return this}
wjs.prototype.onPlaying=function(wjsFunction){this.catchEvent("Playing",wjsFunction);return this}
wjs.prototype.onPaused=function(wjsFunction){this.catchEvent("Paused",wjsFunction);return this}
wjs.prototype.onForward=function(wjsFunction){this.catchEvent("Forward",wjsFunction);return this}
wjs.prototype.onBackward=function(wjsFunction){this.catchEvent("Backward",wjsFunction);return this}
wjs.prototype.onError=function(wjsFunction){this.catchEvent("EncounteredError",wjsFunction);return this}
wjs.prototype.onEnded=function(wjsFunction){this.catchEvent("EndReached",wjsFunction);return this}
wjs.prototype.onStopped=function(wjsFunction){this.catchEvent("Stopped",wjsFunction);return this}
wjs.prototype.onState=function(wjsFunction){vlcs[this.context].events.on('StateChanged',wjsFunction);return this}
wjs.prototype.onStateInt=function(wjsFunction){vlcs[this.context].events.on('StateChangedInt',wjsFunction);return this}
wjs.prototype.onTime=function(wjsFunction){this.catchEvent("TimeChanged",wjsFunction);return this}
wjs.prototype.onPosition=function(wjsFunction){this.catchEvent("PositionChanged",wjsFunction);return this}
wjs.prototype.onFrameSetup=function(wjsFunction){vlcs[this.context].events.on('FrameSetup',wjsFunction);return this}

// export
window.wjs = wjs;
}();/*!
 * jQuery contextMenu v2.2.5-dev - Plugin for simple contextMenu handling
 *
 * Version: v2.2.5-dev
 *
 * Authors: Björn Brala (SWIS.nl), Rodney Rehm, Addy Osmani (patches for FF)
 * Web: http://swisnl.github.io/jQuery-contextMenu/
 *
 * Copyright (c) 2011-2016 SWIS BV and contributors
 *
 * Licensed under
 *   MIT License http://www.opensource.org/licenses/mit-license
 *   GPL v3 http://opensource.org/licenses/GPL-3.0
 *
 * Date: 2016-08-27T11:09:09.141Z
 */
!function(e){"function"==typeof define&&define.amd?define(["jquery"],e):e("object"==typeof exports?require("jquery"):TorrentStream.jQuery)}(function(e){"use strict";function t(e){for(var t,n=e.split(/\s+/),a=[],o=0;t=n[o];o++)t=t.charAt(0).toUpperCase(),a.push(t);return a}function n(t){return t.id&&e('label[for="'+t.id+'"]').val()||t.name}function a(t,o,s){return s||(s=0),o.each(function(){var o,i,c=e(this),r=this,l=this.nodeName.toLowerCase();switch("label"===l&&c.find("input, textarea, select").length&&(o=c.text(),c=c.children().first(),r=c.get(0),l=r.nodeName.toLowerCase()),l){case"menu":i={name:c.attr("label"),items:{}},s=a(i.items,c.children(),s);break;case"a":case"button":i={name:c.text(),disabled:!!c.attr("disabled"),callback:function(){return function(){c.click()}}()};break;case"menuitem":case"command":switch(c.attr("type")){case void 0:case"command":case"menuitem":i={name:c.attr("label"),disabled:!!c.attr("disabled"),icon:c.attr("icon"),callback:function(){return function(){c.click()}}()};break;case"checkbox":i={type:"checkbox",disabled:!!c.attr("disabled"),name:c.attr("label"),selected:!!c.attr("checked")};break;case"radio":i={type:"radio",disabled:!!c.attr("disabled"),name:c.attr("label"),radio:c.attr("radiogroup"),value:c.attr("id"),selected:!!c.attr("checked")};break;default:i=void 0}break;case"hr":i="-------";break;case"input":switch(c.attr("type")){case"text":i={type:"text",name:o||n(r),disabled:!!c.attr("disabled"),value:c.val()};break;case"checkbox":i={type:"checkbox",name:o||n(r),disabled:!!c.attr("disabled"),selected:!!c.attr("checked")};break;case"radio":i={type:"radio",name:o||n(r),disabled:!!c.attr("disabled"),radio:!!c.attr("name"),value:c.val(),selected:!!c.attr("checked")};break;default:i=void 0}break;case"select":i={type:"select",name:o||n(r),disabled:!!c.attr("disabled"),selected:c.val(),options:{}},c.children().each(function(){i.options[this.value]=e(this).text()});break;case"textarea":i={type:"textarea",name:o||n(r),disabled:!!c.attr("disabled"),value:c.val()};break;case"label":break;default:i={type:"html",html:c.clone(!0)}}i&&(s++,t["key"+s]=i)}),s}e.support.htmlMenuitem="HTMLMenuItemElement"in window,e.support.htmlCommand="HTMLCommandElement"in window,e.support.eventSelectstart="onselectstart"in document.documentElement,e.ui&&e.widget||(e.cleanData=function(t){return function(n){var a,o,s;for(s=0;null!=n[s];s++){o=n[s];try{a=e._data(o,"events"),a&&a.remove&&e(o).triggerHandler("remove")}catch(i){}}t(n)}}(e.cleanData));var o=null,s=!1,i=e(window),c=0,r={},l={},u={},d={selector:null,appendTo:null,trigger:"right",autoHide:!1,delay:200,reposition:!0,classNames:{hover:"context-menu-hover",disabled:"context-menu-disabled",visible:"context-menu-visible",notSelectable:"context-menu-not-selectable",icon:"context-menu-icon",iconEdit:"context-menu-icon-edit",iconCut:"context-menu-icon-cut",iconCopy:"context-menu-icon-copy",iconPaste:"context-menu-icon-paste",iconDelete:"context-menu-icon-delete",iconAdd:"context-menu-icon-add",iconQuit:"context-menu-icon-quit"},determinePosition:function(t){if(e.ui&&e.ui.position)t.css("display","block").position({my:"center top",at:"center bottom",of:this,offset:"0 5",collision:"fit"}).css("display","none");else{var n=this.offset();n.top+=this.outerHeight(),n.left+=this.outerWidth()/2-t.outerWidth()/2,t.css(n)}},position:function(e,t,n){var a;if(!t&&!n)return void e.determinePosition.call(this,e.$menu);a="maintain"===t&&"maintain"===n?e.$menu.position():{top:n,left:t};var o=i.scrollTop()+i.height(),s=i.scrollLeft()+i.width(),c=e.$menu.outerHeight(),r=e.$menu.outerWidth();a.top+c>o&&(a.top-=c),a.top<0&&(a.top=0),a.left+r>s&&(a.left-=r),a.left<0&&(a.left=0),e.$menu.css(a)},positionSubmenu:function(t){if(e.ui&&e.ui.position)t.css("display","block").position({my:"left top",at:"right top",of:this,collision:"flipfit fit"}).css("display","");else{var n={top:0,left:this.outerWidth()};t.css(n)}},zIndex:1,animation:{duration:50,show:"slideDown",hide:"slideUp"},events:{show:e.noop,hide:e.noop},callback:null,items:{}},m={timer:null,pageX:null,pageY:null},p=function(e){for(var t=0,n=e;;)if(t=Math.max(t,parseInt(n.css("z-index"),10)||0),n=n.parent(),!n||!n.length||"html body".indexOf(n.prop("nodeName").toLowerCase())>-1)break;return t},f={abortevent:function(e){e.preventDefault(),e.stopImmediatePropagation()},contextmenu:function(t){var n=e(this);if("right"===t.data.trigger&&(t.preventDefault(),t.stopImmediatePropagation()),!("right"!==t.data.trigger&&"demand"!==t.data.trigger&&t.originalEvent||!(void 0===t.mouseButton||!t.data||"left"===t.data.trigger&&0===t.mouseButton||"right"===t.data.trigger&&2===t.mouseButton)||n.hasClass("context-menu-active")||n.hasClass("context-menu-disabled"))){if(o=n,t.data.build){var a=t.data.build(o,t);if(a===!1)return;if(t.data=e.extend(!0,{},d,t.data,a||{}),!t.data.items||e.isEmptyObject(t.data.items))throw window.console&&(console.error||console.log).call(console,"No items specified to show in contextMenu"),new Error("No Items specified");t.data.$trigger=o,h.create(t.data)}var s=!1;for(var i in t.data.items)if(t.data.items.hasOwnProperty(i)){var c;c=e.isFunction(t.data.items[i].visible)?t.data.items[i].visible.call(e(t.currentTarget),i,t.data):"undefined"==typeof i.visible||t.data.items[i].visible===!0,c&&(s=!0)}s&&h.show.call(n,t.data,t.pageX,t.pageY)}},click:function(t){t.preventDefault(),t.stopImmediatePropagation(),e(this).trigger(e.Event("contextmenu",{data:t.data,pageX:t.pageX,pageY:t.pageY}))},mousedown:function(t){var n=e(this);o&&o.length&&!o.is(n)&&o.data("contextMenu").$menu.trigger("contextmenu:hide"),2===t.button&&(o=n.data("contextMenuActive",!0))},mouseup:function(t){var n=e(this);n.data("contextMenuActive")&&o&&o.length&&o.is(n)&&!n.hasClass("context-menu-disabled")&&(t.preventDefault(),t.stopImmediatePropagation(),o=n,n.trigger(e.Event("contextmenu",{data:t.data,pageX:t.pageX,pageY:t.pageY}))),n.removeData("contextMenuActive")},mouseenter:function(t){var n=e(this),a=e(t.relatedTarget),s=e(document);a.is(".context-menu-list")||a.closest(".context-menu-list").length||o&&o.length||(m.pageX=t.pageX,m.pageY=t.pageY,m.data=t.data,s.on("mousemove.contextMenuShow",f.mousemove),m.timer=setTimeout(function(){m.timer=null,s.off("mousemove.contextMenuShow"),o=n,n.trigger(e.Event("contextmenu",{data:m.data,pageX:m.pageX,pageY:m.pageY}))},t.data.delay))},mousemove:function(e){m.pageX=e.pageX,m.pageY=e.pageY},mouseleave:function(t){var n=e(t.relatedTarget);if(!n.is(".context-menu-list")&&!n.closest(".context-menu-list").length){try{clearTimeout(m.timer)}catch(t){}m.timer=null}},layerClick:function(t){var n,a,o=e(this),s=o.data("contextMenuRoot"),c=t.button,r=t.pageX,l=t.pageY;t.preventDefault(),t.stopImmediatePropagation(),setTimeout(function(){var o,u="left"===s.trigger&&0===c||"right"===s.trigger&&2===c;if(document.elementFromPoint&&s.$layer&&(s.$layer.hide(),n=document.elementFromPoint(r-i.scrollLeft(),l-i.scrollTop()),s.$layer.show()),s.reposition&&u)if(document.elementFromPoint){if(s.$trigger.is(n)||s.$trigger.has(n).length)return void s.position.call(s.$trigger,s,r,l)}else if(a=s.$trigger.offset(),o=e(window),a.top+=o.scrollTop(),a.top<=t.pageY&&(a.left+=o.scrollLeft(),a.left<=t.pageX&&(a.bottom=a.top+s.$trigger.outerHeight(),a.bottom>=t.pageY&&(a.right=a.left+s.$trigger.outerWidth(),a.right>=t.pageX))))return void s.position.call(s.$trigger,s,r,l);n&&u&&s.$trigger.one("contextmenu:hidden",function(){e(n).contextMenu({x:r,y:l,button:c})}),null!=s&&null!=s.$menu&&s.$menu.trigger("contextmenu:hide")},50)},keyStop:function(e,t){t.isInput||e.preventDefault(),e.stopPropagation()},key:function(e){var t={};o&&(t=o.data("contextMenu")||{}),void 0===t.zIndex&&(t.zIndex=0);var n=0,a=function(e){""!==e.style.zIndex?n=e.style.zIndex:null!==e.offsetParent&&void 0!==e.offsetParent?a(e.offsetParent):null!==e.parentElement&&void 0!==e.parentElement&&a(e.parentElement)};if(a(e.target),!(n>t.zIndex)){switch(e.keyCode){case 9:case 38:if(f.keyStop(e,t),t.isInput){if(9===e.keyCode&&e.shiftKey)return e.preventDefault(),t.$selected&&t.$selected.find("input, textarea, select").blur(),void t.$menu.trigger("prevcommand");if(38===e.keyCode&&"checkbox"===t.$selected.find("input, textarea, select").prop("type"))return void e.preventDefault()}else if(9!==e.keyCode||e.shiftKey)return void t.$menu.trigger("prevcommand");break;case 40:if(f.keyStop(e,t),!t.isInput)return void t.$menu.trigger("nextcommand");if(9===e.keyCode)return e.preventDefault(),t.$selected&&t.$selected.find("input, textarea, select").blur(),void t.$menu.trigger("nextcommand");if(40===e.keyCode&&"checkbox"===t.$selected.find("input, textarea, select").prop("type"))return void e.preventDefault();break;case 37:if(f.keyStop(e,t),t.isInput||!t.$selected||!t.$selected.length)break;if(!t.$selected.parent().hasClass("context-menu-root")){var s=t.$selected.parent().parent();return t.$selected.trigger("contextmenu:blur"),void(t.$selected=s)}break;case 39:if(f.keyStop(e,t),t.isInput||!t.$selected||!t.$selected.length)break;var i=t.$selected.data("contextMenu")||{};if(i.$menu&&t.$selected.hasClass("context-menu-submenu"))return t.$selected=null,i.$selected=null,void i.$menu.trigger("nextcommand");break;case 35:case 36:return t.$selected&&t.$selected.find("input, textarea, select").length?void 0:((t.$selected&&t.$selected.parent()||t.$menu).children(":not(."+t.classNames.disabled+", ."+t.classNames.notSelectable+")")[36===e.keyCode?"first":"last"]().trigger("contextmenu:focus"),void e.preventDefault());case 13:if(f.keyStop(e,t),t.isInput){if(t.$selected&&!t.$selected.is("textarea, select"))return void e.preventDefault();break}return void("undefined"!=typeof t.$selected&&null!==t.$selected&&t.$selected.trigger("mouseup"));case 32:case 33:case 34:return void f.keyStop(e,t);case 27:return f.keyStop(e,t),void t.$menu.trigger("contextmenu:hide");default:var c=String.fromCharCode(e.keyCode).toUpperCase();if(t.accesskeys&&t.accesskeys[c])return void t.accesskeys[c].$node.trigger(t.accesskeys[c].$menu?"contextmenu:focus":"mouseup")}e.stopPropagation(),"undefined"!=typeof t.$selected&&null!==t.$selected&&t.$selected.trigger(e)}},prevItem:function(t){t.stopPropagation();var n=e(this).data("contextMenu")||{},a=e(this).data("contextMenuRoot")||{};if(n.$selected){var o=n.$selected;n=n.$selected.parent().data("contextMenu")||{},n.$selected=o}for(var s=n.$menu.children(),i=n.$selected&&n.$selected.prev().length?n.$selected.prev():s.last(),c=i;i.hasClass(a.classNames.disabled)||i.hasClass(a.classNames.notSelectable)||i.is(":hidden");)if(i=i.prev().length?i.prev():s.last(),i.is(c))return;n.$selected&&f.itemMouseleave.call(n.$selected.get(0),t),f.itemMouseenter.call(i.get(0),t);var r=i.find("input, textarea, select");r.length&&r.focus()},nextItem:function(t){t.stopPropagation();var n=e(this).data("contextMenu")||{},a=e(this).data("contextMenuRoot")||{};if(n.$selected){var o=n.$selected;n=n.$selected.parent().data("contextMenu")||{},n.$selected=o}for(var s=n.$menu.children(),i=n.$selected&&n.$selected.next().length?n.$selected.next():s.first(),c=i;i.hasClass(a.classNames.disabled)||i.hasClass(a.classNames.notSelectable)||i.is(":hidden");)if(i=i.next().length?i.next():s.first(),i.is(c))return;n.$selected&&f.itemMouseleave.call(n.$selected.get(0),t),f.itemMouseenter.call(i.get(0),t);var r=i.find("input, textarea, select");r.length&&r.focus()},focusInput:function(){var t=e(this).closest(".context-menu-item"),n=t.data(),a=n.contextMenu,o=n.contextMenuRoot;o.$selected=a.$selected=t,o.isInput=a.isInput=!0},blurInput:function(){var t=e(this).closest(".context-menu-item"),n=t.data(),a=n.contextMenu,o=n.contextMenuRoot;o.isInput=a.isInput=!1},menuMouseenter:function(){var t=e(this).data().contextMenuRoot;t.hovering=!0},menuMouseleave:function(t){var n=e(this).data().contextMenuRoot;n.$layer&&n.$layer.is(t.relatedTarget)&&(n.hovering=!1)},itemMouseenter:function(t){var n=e(this),a=n.data(),o=a.contextMenu,s=a.contextMenuRoot;return s.hovering=!0,t&&s.$layer&&s.$layer.is(t.relatedTarget)&&(t.preventDefault(),t.stopImmediatePropagation()),(o.$menu?o:s).$menu.children("."+s.classNames.hover).trigger("contextmenu:blur").children(".hover").trigger("contextmenu:blur"),n.hasClass(s.classNames.disabled)||n.hasClass(s.classNames.notSelectable)?void(o.$selected=null):void n.trigger("contextmenu:focus")},itemMouseleave:function(t){var n=e(this),a=n.data(),o=a.contextMenu,s=a.contextMenuRoot;return s!==o&&s.$layer&&s.$layer.is(t.relatedTarget)?("undefined"!=typeof s.$selected&&null!==s.$selected&&s.$selected.trigger("contextmenu:blur"),t.preventDefault(),t.stopImmediatePropagation(),void(s.$selected=o.$selected=o.$node)):void n.trigger("contextmenu:blur")},itemClick:function(t){var n,a=e(this),o=a.data(),s=o.contextMenu,i=o.contextMenuRoot,c=o.contextMenuKey;if(s.items[c]&&!a.is("."+i.classNames.disabled+", .context-menu-submenu, .context-menu-separator, ."+i.classNames.notSelectable)){if(t.preventDefault(),t.stopImmediatePropagation(),e.isFunction(s.callbacks[c])&&Object.prototype.hasOwnProperty.call(s.callbacks,c))n=s.callbacks[c];else{if(!e.isFunction(i.callback))return;n=i.callback}n.call(i.$trigger,c,i)!==!1?i.$menu.trigger("contextmenu:hide"):i.$menu.parent().length&&h.update.call(i.$trigger,i)}},inputClick:function(e){e.stopImmediatePropagation()},hideMenu:function(t,n){var a=e(this).data("contextMenuRoot");h.hide.call(a.$trigger,a,n&&n.force)},focusItem:function(t){t.stopPropagation();var n=e(this),a=n.data(),o=a.contextMenu,s=a.contextMenuRoot;n.hasClass(s.classNames.disabled)||n.hasClass(s.classNames.notSelectable)||(n.addClass([s.classNames.hover,s.classNames.visible].join(" ")).parent().find(".context-menu-item").not(n).removeClass(s.classNames.visible).filter("."+s.classNames.hover).trigger("contextmenu:blur"),o.$selected=s.$selected=n,o.$node&&s.positionSubmenu.call(o.$node,o.$menu))},blurItem:function(t){t.stopPropagation();var n=e(this),a=n.data(),o=a.contextMenu,s=a.contextMenuRoot;o.autoHide&&n.removeClass(s.classNames.visible),n.removeClass(s.classNames.hover),o.$selected=null}},h={show:function(t,n,a){var s=e(this),i={};if(e("#context-menu-layer").trigger("mousedown"),t.$trigger=s,t.events.show.call(s,t)===!1)return void(o=null);if(h.update.call(s,t),t.position.call(s,t,n,a),t.zIndex){var c=t.zIndex;"function"==typeof t.zIndex&&(c=t.zIndex.call(s,t)),i.zIndex=p(s)+c}h.layer.call(t.$menu,t,i.zIndex),t.$menu.find("ul").css("zIndex",i.zIndex+1),t.$menu.css(i)[t.animation.show](t.animation.duration,function(){s.trigger("contextmenu:visible")}),s.data("contextMenu",t).addClass("context-menu-active"),e(document).off("keydown.contextMenu").on("keydown.contextMenu",f.key),t.autoHide&&e(document).on("mousemove.contextMenuAutoHide",function(e){var n=s.offset();n.right=n.left+s.outerWidth(),n.bottom=n.top+s.outerHeight(),!t.$layer||t.hovering||e.pageX>=n.left&&e.pageX<=n.right&&e.pageY>=n.top&&e.pageY<=n.bottom||setTimeout(function(){t.hovering||null==t.$menu||t.$menu.trigger("contextmenu:hide")},50)})},hide:function(t,n){var a=e(this);if(t||(t=a.data("contextMenu")||{}),n||!t.events||t.events.hide.call(a,t)!==!1){if(a.removeData("contextMenu").removeClass("context-menu-active"),t.$layer){setTimeout(function(e){return function(){e.remove()}}(t.$layer),10);try{delete t.$layer}catch(s){t.$layer=null}}o=null,t.$menu.find("."+t.classNames.hover).trigger("contextmenu:blur"),t.$selected=null,t.$menu.find("."+t.classNames.visible).removeClass(t.classNames.visible),e(document).off(".contextMenuAutoHide").off("keydown.contextMenu"),t.$menu&&t.$menu[t.animation.hide](t.animation.duration,function(){t.build&&(t.$menu.remove(),e.each(t,function(e){switch(e){case"ns":case"selector":case"build":case"trigger":return!0;default:t[e]=void 0;try{delete t[e]}catch(n){}return!0}})),setTimeout(function(){a.trigger("contextmenu:hidden")},10)})}},create:function(n,a){function o(t){var n=e("<span></span>");if(t._accesskey)t._beforeAccesskey&&n.append(document.createTextNode(t._beforeAccesskey)),e("<span></span>").addClass("context-menu-accesskey").text(t._accesskey).appendTo(n),t._afterAccesskey&&n.append(document.createTextNode(t._afterAccesskey));else if(t.isHtmlName){if("undefined"!=typeof t.accesskey)throw new Error("accesskeys are not compatible with HTML names and cannot be used together in the same item");n.html(t.name)}else n.text(t.name);return n}void 0===a&&(a=n),n.$menu=e('<ul class="context-menu-list"></ul>').addClass(n.className||"").data({contextMenu:n,contextMenuRoot:a}),e.each(["callbacks","commands","inputs"],function(e,t){n[t]={},a[t]||(a[t]={})}),a.accesskeys||(a.accesskeys={}),e.each(n.items,function(s,i){var c=e('<li class="context-menu-item"></li>').addClass(i.className||""),r=null,l=null;if(c.on("click",e.noop),"string"!=typeof i&&"cm_separator"!==i.type||(i={type:"cm_seperator"}),i.$node=c.data({contextMenu:n,contextMenuRoot:a,contextMenuKey:s}),"undefined"!=typeof i.accesskey)for(var d,m=t(i.accesskey),p=0;d=m[p];p++)if(!a.accesskeys[d]){a.accesskeys[d]=i;var x=i.name.match(new RegExp("^(.*?)("+d+")(.*)$","i"));x&&(i._beforeAccesskey=x[1],i._accesskey=x[2],i._afterAccesskey=x[3]);break}if(i.type&&u[i.type])u[i.type].call(c,i,n,a),e.each([n,a],function(t,a){a.commands[s]=i,!e.isFunction(i.callback)||void 0!==a.callbacks[s]&&void 0!==n.type||(a.callbacks[s]=i.callback)});else{switch("cm_seperator"===i.type?c.addClass("context-menu-separator "+a.classNames.notSelectable):"html"===i.type?c.addClass("context-menu-html "+a.classNames.notSelectable):i.type?(r=e("<label></label>").appendTo(c),o(i).appendTo(r),c.addClass("context-menu-input"),n.hasTypes=!0,e.each([n,a],function(e,t){t.commands[s]=i,t.inputs[s]=i})):i.items&&(i.type="sub"),i.type){case"cm_seperator":break;case"text":l=e('<input type="text" value="1" name="" value="">').attr("name","context-menu-input-"+s).val(i.value||"").appendTo(r);break;case"textarea":l=e('<textarea name=""></textarea>').attr("name","context-menu-input-"+s).val(i.value||"").appendTo(r),i.height&&l.height(i.height);break;case"checkbox":l=e('<input type="checkbox" value="1" name="" value="">').attr("name","context-menu-input-"+s).val(i.value||"").prop("checked",!!i.selected).prependTo(r);break;case"radio":l=e('<input type="radio" value="1" name="" value="">').attr("name","context-menu-input-"+i.radio).val(i.value||"").prop("checked",!!i.selected).prependTo(r);break;case"select":l=e('<select name="">').attr("name","context-menu-input-"+s).appendTo(r),i.options&&(e.each(i.options,function(t,n){e("<option></option>").val(t).text(n).appendTo(l)}),l.val(i.selected));break;case"sub":o(i).appendTo(c),i.appendTo=i.$node,h.create(i,a),c.data("contextMenu",i).addClass("context-menu-submenu"),i.callback=null;break;case"html":e(i.html).appendTo(c);break;default:e.each([n,a],function(t,a){a.commands[s]=i,!e.isFunction(i.callback)||void 0!==a.callbacks[s]&&void 0!==n.type||(a.callbacks[s]=i.callback)}),o(i).appendTo(c)}i.type&&"sub"!==i.type&&"html"!==i.type&&"cm_seperator"!==i.type&&(l.on("focus",f.focusInput).on("blur",f.blurInput),i.events&&l.on(i.events,n)),i.icon&&(e.isFunction(i.icon)?i._icon=i.icon.call(this,this,c,s,i):"string"==typeof i.icon&&"fa-"==i.icon.substring(0,3)?i._icon=a.classNames.icon+" "+a.classNames.icon+"--fa fa "+i.icon:i._icon=a.classNames.icon+" "+a.classNames.icon+"-"+i.icon,c.addClass(i._icon))}i.$input=l,i.$label=r,c.appendTo(n.$menu),!n.hasTypes&&e.support.eventSelectstart&&c.on("selectstart.disableTextSelect",f.abortevent)}),n.$node||n.$menu.css("display","none").addClass("context-menu-root"),n.$menu.appendTo(n.appendTo||document.body)},resize:function(t,n){var a;t.css({position:"absolute",display:"block"}),t.data("width",(a=t.get(0)).getBoundingClientRect?Math.ceil(a.getBoundingClientRect().width):t.outerWidth()+1),t.css({position:"static",minWidth:"0px",maxWidth:"100000px"}),t.find("> li > ul").each(function(){h.resize(e(this),!0)}),n||t.find("ul").addBack().css({position:"",display:"",minWidth:"",maxWidth:""}).outerWidth(function(){return e(this).data("width")})},update:function(t,n){var a=this;void 0===n&&(n=t,h.resize(t.$menu)),t.$menu.children().each(function(){var o,s=e(this),i=s.data("contextMenuKey"),c=t.items[i],r=e.isFunction(c.disabled)&&c.disabled.call(a,i,n)||c.disabled===!0;if(o=e.isFunction(c.visible)?c.visible.call(a,i,n):"undefined"==typeof c.visible||c.visible===!0,s[o?"show":"hide"](),s[r?"addClass":"removeClass"](n.classNames.disabled),e.isFunction(c.icon)&&(s.removeClass(c._icon),c._icon=c.icon.call(this,a,s,i,c),s.addClass(c._icon)),c.type)switch(s.find("input, select, textarea").prop("disabled",r),c.type){case"text":case"textarea":c.$input.val(c.value||"");break;case"checkbox":case"radio":c.$input.val(c.value||"").prop("checked",!!c.selected);break;case"select":c.$input.val(c.selected||"")}c.$menu&&h.update.call(a,c,n)})},layer:function(t,n){var a=t.$layer=e('<div id="context-menu-layer" style="position:fixed; z-index:'+n+'; top:0; left:0; opacity: 0; filter: alpha(opacity=0); background-color: #000;"></div>').css({height:i.height(),width:i.width(),display:"block"}).data("contextMenuRoot",t).insertBefore(this).on("contextmenu",f.abortevent).on("mousedown",f.layerClick);return void 0===document.body.style.maxWidth&&a.css({position:"absolute",height:e(document).height()}),a}};e.fn.contextMenu=function(t){var n=this,a=t;if(this.length>0)if(void 0===t)this.first().trigger("contextmenu");else if(void 0!==t.x&&void 0!==t.y)this.first().trigger(e.Event("contextmenu",{pageX:t.x,pageY:t.y,mouseButton:t.button}));else if("hide"===t){var o=this.first().data("contextMenu")?this.first().data("contextMenu").$menu:null;o&&o.trigger("contextmenu:hide")}else"destroy"===t?e.contextMenu("destroy",{context:this}):e.isPlainObject(t)?(t.context=this,e.contextMenu("create",t)):t?this.removeClass("context-menu-disabled"):t||this.addClass("context-menu-disabled");else e.each(l,function(){this.selector===n.selector&&(a.data=this,e.extend(a.data,{trigger:"demand"}))}),f.contextmenu.call(a.target,a);return this},e.contextMenu=function(t,n){"string"!=typeof t&&(n=t,t="create"),"string"==typeof n?n={selector:n}:void 0===n&&(n={});var a=e.extend(!0,{},d,n||{}),o=e(document),i=o,u=!1;switch(a.context&&a.context.length?(i=e(a.context).first(),a.context=i.get(0),u=!e(a.context).is(document)):a.context=document,t){case"create":if(!a.selector)throw new Error("No selector specified");if(a.selector.match(/.context-menu-(list|item|input)($|\s)/))throw new Error('Cannot bind to selector "'+a.selector+'" as it contains a reserved className');if(!a.build&&(!a.items||e.isEmptyObject(a.items)))throw new Error("No Items specified");if(c++,a.ns=".contextMenu"+c,u||(r[a.selector]=a.ns),l[a.ns]=a,a.trigger||(a.trigger="right"),!s){var m="click"===a.itemClickEvent?"click.contextMenu":"mouseup.contextMenu",p={"contextmenu:focus.contextMenu":f.focusItem,"contextmenu:blur.contextMenu":f.blurItem,"contextmenu.contextMenu":f.abortevent,"mouseenter.contextMenu":f.itemMouseenter,"mouseleave.contextMenu":f.itemMouseleave};p[m]=f.itemClick,o.on({"contextmenu:hide.contextMenu":f.hideMenu,"prevcommand.contextMenu":f.prevItem,"nextcommand.contextMenu":f.nextItem,"contextmenu.contextMenu":f.abortevent,"mouseenter.contextMenu":f.menuMouseenter,"mouseleave.contextMenu":f.menuMouseleave},".context-menu-list").on("mouseup.contextMenu",".context-menu-input",f.inputClick).on(p,".context-menu-item"),s=!0}switch(i.on("contextmenu"+a.ns,a.selector,a,f.contextmenu),u&&i.on("remove"+a.ns,function(){e(this).contextMenu("destroy")}),a.trigger){case"hover":i.on("mouseenter"+a.ns,a.selector,a,f.mouseenter).on("mouseleave"+a.ns,a.selector,a,f.mouseleave);break;case"left":i.on("click"+a.ns,a.selector,a,f.click)}a.build||h.create(a);break;case"destroy":var x;if(u){var v=a.context;e.each(l,function(t,n){if(!e(v).is(n.selector))return!0;x=e(".context-menu-list").filter(":visible"),x.length&&x.data().contextMenuRoot.$trigger.is(e(n.context).find(n.selector))&&x.trigger("contextmenu:hide",{force:!0});try{l[n.ns].$menu&&l[n.ns].$menu.remove(),delete l[n.ns]}catch(a){l[n.ns]=null}return e(n.context).off(n.ns),!0})}else if(a.selector){if(r[a.selector]){x=e(".context-menu-list").filter(":visible"),x.length&&x.data().contextMenuRoot.$trigger.is(a.selector)&&x.trigger("contextmenu:hide",{force:!0});try{l[r[a.selector]].$menu&&l[r[a.selector]].$menu.remove(),delete l[r[a.selector]]}catch(g){l[r[a.selector]]=null}o.off(r[a.selector])}}else o.off(".contextMenu .contextMenuAutoHide"),e.each(l,function(t,n){e(n.context).off(n.ns)}),r={},l={},c=0,s=!1,e("#context-menu-layer, .context-menu-list").remove();break;case"html5":(!e.support.htmlCommand&&!e.support.htmlMenuitem||"boolean"==typeof n&&n)&&e('menu[type="context"]').each(function(){this.id&&e.contextMenu({selector:"[contextmenu="+this.id+"]",items:e.contextMenu.fromMenu(this)})}).css("display","none");break;default:throw new Error('Unknown operation "'+t+'"')}return this},e.contextMenu.setInputValues=function(t,n){void 0===n&&(n={}),e.each(t.inputs,function(e,t){switch(t.type){case"text":case"textarea":t.value=n[e]||"";break;case"checkbox":t.selected=!!n[e];break;case"radio":t.selected=(n[t.radio]||"")===t.value;break;case"select":t.selected=n[e]||""}})},e.contextMenu.getInputValues=function(t,n){return void 0===n&&(n={}),e.each(t.inputs,function(e,t){switch(t.type){case"text":case"textarea":case"select":n[e]=t.$input.val();break;case"checkbox":n[e]=t.$input.prop("checked");break;case"radio":t.$input.prop("checked")&&(n[t.radio]=t.value)}}),n},e.contextMenu.fromMenu=function(t){var n=e(t),o={};return a(o,n.children()),o},e.contextMenu.defaults=d,e.contextMenu.types=u,e.contextMenu.handle=f,e.contextMenu.op=h,e.contextMenu.menus=l});
//# sourceMappingURL=jquery.contextMenu.min.js.map
/* == jquery mousewheel plugin == Version: 3.1.13, License: MIT License (MIT) */
!function(a){"function"==typeof define&&define.amd?define(["jquery"],a):"object"==typeof exports?module.exports=a:a(TorrentStream.jQuery)}(function(a){function b(b){var g=b||window.event,h=i.call(arguments,1),j=0,l=0,m=0,n=0,o=0,p=0;if(b=a.event.fix(g),b.type="mousewheel","detail"in g&&(m=-1*g.detail),"wheelDelta"in g&&(m=g.wheelDelta),"wheelDeltaY"in g&&(m=g.wheelDeltaY),"wheelDeltaX"in g&&(l=-1*g.wheelDeltaX),"axis"in g&&g.axis===g.HORIZONTAL_AXIS&&(l=-1*m,m=0),j=0===m?l:m,"deltaY"in g&&(m=-1*g.deltaY,j=m),"deltaX"in g&&(l=g.deltaX,0===m&&(j=-1*l)),0!==m||0!==l){if(1===g.deltaMode){var q=a.data(this,"mousewheel-line-height");j*=q,m*=q,l*=q}else if(2===g.deltaMode){var r=a.data(this,"mousewheel-page-height");j*=r,m*=r,l*=r}if(n=Math.max(Math.abs(m),Math.abs(l)),(!f||f>n)&&(f=n,d(g,n)&&(f/=40)),d(g,n)&&(j/=40,l/=40,m/=40),j=Math[j>=1?"floor":"ceil"](j/f),l=Math[l>=1?"floor":"ceil"](l/f),m=Math[m>=1?"floor":"ceil"](m/f),k.settings.normalizeOffset&&this.getBoundingClientRect){var s=this.getBoundingClientRect();o=b.clientX-s.left,p=b.clientY-s.top}return b.deltaX=l,b.deltaY=m,b.deltaFactor=f,b.offsetX=o,b.offsetY=p,b.deltaMode=0,h.unshift(b,j,l,m),e&&clearTimeout(e),e=setTimeout(c,200),(a.event.dispatch||a.event.handle).apply(this,h)}}function c(){f=null}function d(a,b){return k.settings.adjustOldDeltas&&"mousewheel"===a.type&&b%120===0}var e,f,g=["wheel","mousewheel","DOMMouseScroll","MozMousePixelScroll"],h="onwheel"in document||document.documentMode>=9?["wheel"]:["mousewheel","DomMouseScroll","MozMousePixelScroll"],i=Array.prototype.slice;if(a.event.fixHooks)for(var j=g.length;j;)a.event.fixHooks[g[--j]]=a.event.mouseHooks;var k=a.event.special.mousewheel={version:"3.1.12",setup:function(){if(this.addEventListener)for(var c=h.length;c;)this.addEventListener(h[--c],b,!1);else this.onmousewheel=b;a.data(this,"mousewheel-line-height",k.getLineHeight(this)),a.data(this,"mousewheel-page-height",k.getPageHeight(this))},teardown:function(){if(this.removeEventListener)for(var c=h.length;c;)this.removeEventListener(h[--c],b,!1);else this.onmousewheel=null;a.removeData(this,"mousewheel-line-height"),a.removeData(this,"mousewheel-page-height")},getLineHeight:function(b){var c=a(b),d=c["offsetParent"in a.fn?"offsetParent":"parent"]();return d.length||(d=a("body")),parseInt(d.css("fontSize"),10)||parseInt(c.css("fontSize"),10)||16},getPageHeight:function(b){return a(b).height()},settings:{adjustOldDeltas:!0,normalizeOffset:!0}};a.fn.extend({mousewheel:function(a){return a?this.bind("mousewheel",a):this.trigger("mousewheel")},unmousewheel:function(a){return this.unbind("mousewheel",a)}})});!function(a){"function"==typeof define&&define.amd?define(["jquery"],a):"object"==typeof exports?module.exports=a:a(TorrentStream.jQuery)}(function(a){function b(b){var g=b||window.event,h=i.call(arguments,1),j=0,l=0,m=0,n=0,o=0,p=0;if(b=a.event.fix(g),b.type="mousewheel","detail"in g&&(m=-1*g.detail),"wheelDelta"in g&&(m=g.wheelDelta),"wheelDeltaY"in g&&(m=g.wheelDeltaY),"wheelDeltaX"in g&&(l=-1*g.wheelDeltaX),"axis"in g&&g.axis===g.HORIZONTAL_AXIS&&(l=-1*m,m=0),j=0===m?l:m,"deltaY"in g&&(m=-1*g.deltaY,j=m),"deltaX"in g&&(l=g.deltaX,0===m&&(j=-1*l)),0!==m||0!==l){if(1===g.deltaMode){var q=a.data(this,"mousewheel-line-height");j*=q,m*=q,l*=q}else if(2===g.deltaMode){var r=a.data(this,"mousewheel-page-height");j*=r,m*=r,l*=r}if(n=Math.max(Math.abs(m),Math.abs(l)),(!f||f>n)&&(f=n,d(g,n)&&(f/=40)),d(g,n)&&(j/=40,l/=40,m/=40),j=Math[j>=1?"floor":"ceil"](j/f),l=Math[l>=1?"floor":"ceil"](l/f),m=Math[m>=1?"floor":"ceil"](m/f),k.settings.normalizeOffset&&this.getBoundingClientRect){var s=this.getBoundingClientRect();o=b.clientX-s.left,p=b.clientY-s.top}return b.deltaX=l,b.deltaY=m,b.deltaFactor=f,b.offsetX=o,b.offsetY=p,b.deltaMode=0,h.unshift(b,j,l,m),e&&clearTimeout(e),e=setTimeout(c,200),(a.event.dispatch||a.event.handle).apply(this,h)}}function c(){f=null}function d(a,b){return k.settings.adjustOldDeltas&&"mousewheel"===a.type&&b%120===0}var e,f,g=["wheel","mousewheel","DOMMouseScroll","MozMousePixelScroll"],h="onwheel"in document||document.documentMode>=9?["wheel"]:["mousewheel","DomMouseScroll","MozMousePixelScroll"],i=Array.prototype.slice;if(a.event.fixHooks)for(var j=g.length;j;)a.event.fixHooks[g[--j]]=a.event.mouseHooks;var k=a.event.special.mousewheel={version:"3.1.12",setup:function(){if(this.addEventListener)for(var c=h.length;c;)this.addEventListener(h[--c],b,!1);else this.onmousewheel=b;a.data(this,"mousewheel-line-height",k.getLineHeight(this)),a.data(this,"mousewheel-page-height",k.getPageHeight(this))},teardown:function(){if(this.removeEventListener)for(var c=h.length;c;)this.removeEventListener(h[--c],b,!1);else this.onmousewheel=null;a.removeData(this,"mousewheel-line-height"),a.removeData(this,"mousewheel-page-height")},getLineHeight:function(b){var c=a(b),d=c["offsetParent"in a.fn?"offsetParent":"parent"]();return d.length||(d=a("body")),parseInt(d.css("fontSize"),10)||parseInt(c.css("fontSize"),10)||16},getPageHeight:function(b){return a(b).height()},settings:{adjustOldDeltas:!0,normalizeOffset:!0}};a.fn.extend({mousewheel:function(a){return a?this.bind("mousewheel",a):this.trigger("mousewheel")},unmousewheel:function(a){return this.unbind("mousewheel",a)}})});
/* == malihu jquery custom scrollbar plugin == Version: 3.1.5, License: MIT License (MIT) */
!function(e){"function"==typeof define&&define.amd?define(["jquery"],e):"undefined"!=typeof module&&module.exports?module.exports=e:e(TorrentStream.jQuery,window,document)}(function(e){!function(t){var o="function"==typeof define&&define.amd,a="undefined"!=typeof module&&module.exports,n="https:"==document.location.protocol?"https:":"http:",i="cdnjs.cloudflare.com/ajax/libs/jquery-mousewheel/3.1.13/jquery.mousewheel.min.js";o||(a?require("jquery-mousewheel")(e):e.event.special.mousewheel||e("head").append(decodeURI("%3Cscript src="+n+"//"+i+"%3E%3C/script%3E"))),t()}(function(){var t,o="mCustomScrollbar",a="mCS",n=".mCustomScrollbar",i={setTop:0,setLeft:0,axis:"y",scrollbarPosition:"inside",scrollInertia:950,autoDraggerLength:!0,alwaysShowScrollbar:0,snapOffset:0,mouseWheel:{enable:!0,scrollAmount:"auto",axis:"y",deltaFactor:"auto",disableOver:["select","option","keygen","datalist","textarea"]},scrollButtons:{scrollType:"stepless",scrollAmount:"auto"},keyboard:{enable:!0,scrollType:"stepless",scrollAmount:"auto"},contentTouchScroll:25,documentTouchScroll:!0,advanced:{autoScrollOnFocus:"input,textarea,select,button,datalist,keygen,a[tabindex],area,object,[contenteditable='true']",updateOnContentResize:!0,updateOnImageLoad:"auto",autoUpdateTimeout:60},theme:"light",callbacks:{onTotalScrollOffset:0,onTotalScrollBackOffset:0,alwaysTriggerOffsets:!0}},r=0,l={},s=window.attachEvent&&!window.addEventListener?1:0,c=!1,d=["mCSB_dragger_onDrag","mCSB_scrollTools_onDrag","mCS_img_loaded","mCS_disabled","mCS_destroyed","mCS_no_scrollbar","mCS-autoHide","mCS-dir-rtl","mCS_no_scrollbar_y","mCS_no_scrollbar_x","mCS_y_hidden","mCS_x_hidden","mCSB_draggerContainer","mCSB_buttonUp","mCSB_buttonDown","mCSB_buttonLeft","mCSB_buttonRight"],u={init:function(t){var t=e.extend(!0,{},i,t),o=f.call(this);if(t.live){var s=t.liveSelector||this.selector||n,c=e(s);if("off"===t.live)return void m(s);l[s]=setTimeout(function(){c.mCustomScrollbar(t),"once"===t.live&&c.length&&m(s)},500)}else m(s);return t.setWidth=t.set_width?t.set_width:t.setWidth,t.setHeight=t.set_height?t.set_height:t.setHeight,t.axis=t.horizontalScroll?"x":p(t.axis),t.scrollInertia=t.scrollInertia>0&&t.scrollInertia<17?17:t.scrollInertia,"object"!=typeof t.mouseWheel&&1==t.mouseWheel&&(t.mouseWheel={enable:!0,scrollAmount:"auto",axis:"y",preventDefault:!1,deltaFactor:"auto",normalizeDelta:!1,invert:!1}),t.mouseWheel.scrollAmount=t.mouseWheelPixels?t.mouseWheelPixels:t.mouseWheel.scrollAmount,t.mouseWheel.normalizeDelta=t.advanced.normalizeMouseWheelDelta?t.advanced.normalizeMouseWheelDelta:t.mouseWheel.normalizeDelta,t.scrollButtons.scrollType=g(t.scrollButtons.scrollType),h(t),e(o).each(function(){var o=e(this);if(!o.data(a)){o.data(a,{idx:++r,opt:t,scrollRatio:{y:null,x:null},overflowed:null,contentReset:{y:null,x:null},bindEvents:!1,tweenRunning:!1,sequential:{},langDir:o.css("direction"),cbOffsets:null,trigger:null,poll:{size:{o:0,n:0},img:{o:0,n:0},change:{o:0,n:0}}});var n=o.data(a),i=n.opt,l=o.data("mcs-axis"),s=o.data("mcs-scrollbar-position"),c=o.data("mcs-theme");l&&(i.axis=l),s&&(i.scrollbarPosition=s),c&&(i.theme=c,h(i)),v.call(this),n&&i.callbacks.onCreate&&"function"==typeof i.callbacks.onCreate&&i.callbacks.onCreate.call(this),e("#mCSB_"+n.idx+"_container img:not(."+d[2]+")").addClass(d[2]),u.update.call(null,o)}})},update:function(t,o){var n=t||f.call(this);return e(n).each(function(){var t=e(this);if(t.data(a)){var n=t.data(a),i=n.opt,r=e("#mCSB_"+n.idx+"_container"),l=e("#mCSB_"+n.idx),s=[e("#mCSB_"+n.idx+"_dragger_vertical"),e("#mCSB_"+n.idx+"_dragger_horizontal")];if(!r.length)return;n.tweenRunning&&Q(t),o&&n&&i.callbacks.onBeforeUpdate&&"function"==typeof i.callbacks.onBeforeUpdate&&i.callbacks.onBeforeUpdate.call(this),t.hasClass(d[3])&&t.removeClass(d[3]),t.hasClass(d[4])&&t.removeClass(d[4]),l.css("max-height","none"),l.height()!==t.height()&&l.css("max-height",t.height()),_.call(this),"y"===i.axis||i.advanced.autoExpandHorizontalScroll||r.css("width",x(r)),n.overflowed=y.call(this),M.call(this),i.autoDraggerLength&&S.call(this),b.call(this),T.call(this);var c=[Math.abs(r[0].offsetTop),Math.abs(r[0].offsetLeft)];"x"!==i.axis&&(n.overflowed[0]?s[0].height()>s[0].parent().height()?B.call(this):(G(t,c[0].toString(),{dir:"y",dur:0,overwrite:"none"}),n.contentReset.y=null):(B.call(this),"y"===i.axis?k.call(this):"yx"===i.axis&&n.overflowed[1]&&G(t,c[1].toString(),{dir:"x",dur:0,overwrite:"none"}))),"y"!==i.axis&&(n.overflowed[1]?s[1].width()>s[1].parent().width()?B.call(this):(G(t,c[1].toString(),{dir:"x",dur:0,overwrite:"none"}),n.contentReset.x=null):(B.call(this),"x"===i.axis?k.call(this):"yx"===i.axis&&n.overflowed[0]&&G(t,c[0].toString(),{dir:"y",dur:0,overwrite:"none"}))),o&&n&&(2===o&&i.callbacks.onImageLoad&&"function"==typeof i.callbacks.onImageLoad?i.callbacks.onImageLoad.call(this):3===o&&i.callbacks.onSelectorChange&&"function"==typeof i.callbacks.onSelectorChange?i.callbacks.onSelectorChange.call(this):i.callbacks.onUpdate&&"function"==typeof i.callbacks.onUpdate&&i.callbacks.onUpdate.call(this)),N.call(this)}})},scrollTo:function(t,o){if("undefined"!=typeof t&&null!=t){var n=f.call(this);return e(n).each(function(){var n=e(this);if(n.data(a)){var i=n.data(a),r=i.opt,l={trigger:"external",scrollInertia:r.scrollInertia,scrollEasing:"mcsEaseInOut",moveDragger:!1,timeout:60,callbacks:!0,onStart:!0,onUpdate:!0,onComplete:!0},s=e.extend(!0,{},l,o),c=Y.call(this,t),d=s.scrollInertia>0&&s.scrollInertia<17?17:s.scrollInertia;c[0]=X.call(this,c[0],"y"),c[1]=X.call(this,c[1],"x"),s.moveDragger&&(c[0]*=i.scrollRatio.y,c[1]*=i.scrollRatio.x),s.dur=ne()?0:d,setTimeout(function(){null!==c[0]&&"undefined"!=typeof c[0]&&"x"!==r.axis&&i.overflowed[0]&&(s.dir="y",s.overwrite="all",G(n,c[0].toString(),s)),null!==c[1]&&"undefined"!=typeof c[1]&&"y"!==r.axis&&i.overflowed[1]&&(s.dir="x",s.overwrite="none",G(n,c[1].toString(),s))},s.timeout)}})}},stop:function(){var t=f.call(this);return e(t).each(function(){var t=e(this);t.data(a)&&Q(t)})},disable:function(t){var o=f.call(this);return e(o).each(function(){var o=e(this);if(o.data(a)){o.data(a);N.call(this,"remove"),k.call(this),t&&B.call(this),M.call(this,!0),o.addClass(d[3])}})},destroy:function(){var t=f.call(this);return e(t).each(function(){var n=e(this);if(n.data(a)){var i=n.data(a),r=i.opt,l=e("#mCSB_"+i.idx),s=e("#mCSB_"+i.idx+"_container"),c=e(".mCSB_"+i.idx+"_scrollbar");r.live&&m(r.liveSelector||e(t).selector),N.call(this,"remove"),k.call(this),B.call(this),n.removeData(a),$(this,"mcs"),c.remove(),s.find("img."+d[2]).removeClass(d[2]),l.replaceWith(s.contents()),n.removeClass(o+" _"+a+"_"+i.idx+" "+d[6]+" "+d[7]+" "+d[5]+" "+d[3]).addClass(d[4])}})}},f=function(){return"object"!=typeof e(this)||e(this).length<1?n:this},h=function(t){var o=["rounded","rounded-dark","rounded-dots","rounded-dots-dark"],a=["rounded-dots","rounded-dots-dark","3d","3d-dark","3d-thick","3d-thick-dark","inset","inset-dark","inset-2","inset-2-dark","inset-3","inset-3-dark"],n=["minimal","minimal-dark"],i=["minimal","minimal-dark"],r=["minimal","minimal-dark"];t.autoDraggerLength=e.inArray(t.theme,o)>-1?!1:t.autoDraggerLength,t.autoExpandScrollbar=e.inArray(t.theme,a)>-1?!1:t.autoExpandScrollbar,t.scrollButtons.enable=e.inArray(t.theme,n)>-1?!1:t.scrollButtons.enable,t.autoHideScrollbar=e.inArray(t.theme,i)>-1?!0:t.autoHideScrollbar,t.scrollbarPosition=e.inArray(t.theme,r)>-1?"outside":t.scrollbarPosition},m=function(e){l[e]&&(clearTimeout(l[e]),$(l,e))},p=function(e){return"yx"===e||"xy"===e||"auto"===e?"yx":"x"===e||"horizontal"===e?"x":"y"},g=function(e){return"stepped"===e||"pixels"===e||"step"===e||"click"===e?"stepped":"stepless"},v=function(){var t=e(this),n=t.data(a),i=n.opt,r=i.autoExpandScrollbar?" "+d[1]+"_expand":"",l=["<div id='mCSB_"+n.idx+"_scrollbar_vertical' class='mCSB_scrollTools mCSB_"+n.idx+"_scrollbar mCS-"+i.theme+" mCSB_scrollTools_vertical"+r+"'><div class='"+d[12]+"'><div id='mCSB_"+n.idx+"_dragger_vertical' class='mCSB_dragger' style='position:absolute;'><div class='mCSB_dragger_bar' /></div><div class='mCSB_draggerRail' /></div></div>","<div id='mCSB_"+n.idx+"_scrollbar_horizontal' class='mCSB_scrollTools mCSB_"+n.idx+"_scrollbar mCS-"+i.theme+" mCSB_scrollTools_horizontal"+r+"'><div class='"+d[12]+"'><div id='mCSB_"+n.idx+"_dragger_horizontal' class='mCSB_dragger' style='position:absolute;'><div class='mCSB_dragger_bar' /></div><div class='mCSB_draggerRail' /></div></div>"],s="yx"===i.axis?"mCSB_vertical_horizontal":"x"===i.axis?"mCSB_horizontal":"mCSB_vertical",c="yx"===i.axis?l[0]+l[1]:"x"===i.axis?l[1]:l[0],u="yx"===i.axis?"<div id='mCSB_"+n.idx+"_container_wrapper' class='mCSB_container_wrapper' />":"",f=i.autoHideScrollbar?" "+d[6]:"",h="x"!==i.axis&&"rtl"===n.langDir?" "+d[7]:"";i.setWidth&&t.css("width",i.setWidth),i.setHeight&&t.css("height",i.setHeight),i.setLeft="y"!==i.axis&&"rtl"===n.langDir?"989999px":i.setLeft,t.addClass(o+" _"+a+"_"+n.idx+f+h).wrapInner("<div id='mCSB_"+n.idx+"' class='mCustomScrollBox mCS-"+i.theme+" "+s+"'><div id='mCSB_"+n.idx+"_container' class='mCSB_container' style='position:relative; top:"+i.setTop+"; left:"+i.setLeft+";' dir='"+n.langDir+"' /></div>");var m=e("#mCSB_"+n.idx),p=e("#mCSB_"+n.idx+"_container");"y"===i.axis||i.advanced.autoExpandHorizontalScroll||p.css("width",x(p)),"outside"===i.scrollbarPosition?("static"===t.css("position")&&t.css("position","relative"),t.css("overflow","visible"),m.addClass("mCSB_outside").after(c)):(m.addClass("mCSB_inside").append(c),p.wrap(u)),w.call(this);var g=[e("#mCSB_"+n.idx+"_dragger_vertical"),e("#mCSB_"+n.idx+"_dragger_horizontal")];g[0].css("min-height",g[0].height()),g[1].css("min-width",g[1].width())},x=function(t){var o=[t[0].scrollWidth,Math.max.apply(Math,t.children().map(function(){return e(this).outerWidth(!0)}).get())],a=t.parent().width();return o[0]>a?o[0]:o[1]>a?o[1]:"100%"},_=function(){var t=e(this),o=t.data(a),n=o.opt,i=e("#mCSB_"+o.idx+"_container");if(n.advanced.autoExpandHorizontalScroll&&"y"!==n.axis){i.css({width:"auto","min-width":0,"overflow-x":"scroll"});var r=Math.ceil(i[0].scrollWidth);3===n.advanced.autoExpandHorizontalScroll||2!==n.advanced.autoExpandHorizontalScroll&&r>i.parent().width()?i.css({width:r,"min-width":"100%","overflow-x":"inherit"}):i.css({"overflow-x":"inherit",position:"absolute"}).wrap("<div class='mCSB_h_wrapper' style='position:relative; left:0; width:999999px;' />").css({width:Math.ceil(i[0].getBoundingClientRect().right+.4)-Math.floor(i[0].getBoundingClientRect().left),"min-width":"100%",position:"relative"}).unwrap()}},w=function(){var t=e(this),o=t.data(a),n=o.opt,i=e(".mCSB_"+o.idx+"_scrollbar:first"),r=oe(n.scrollButtons.tabindex)?"tabindex='"+n.scrollButtons.tabindex+"'":"",l=["<a href='#' class='"+d[13]+"' "+r+" />","<a href='#' class='"+d[14]+"' "+r+" />","<a href='#' class='"+d[15]+"' "+r+" />","<a href='#' class='"+d[16]+"' "+r+" />"],s=["x"===n.axis?l[2]:l[0],"x"===n.axis?l[3]:l[1],l[2],l[3]];n.scrollButtons.enable&&i.prepend(s[0]).append(s[1]).next(".mCSB_scrollTools").prepend(s[2]).append(s[3])},S=function(){var t=e(this),o=t.data(a),n=e("#mCSB_"+o.idx),i=e("#mCSB_"+o.idx+"_container"),r=[e("#mCSB_"+o.idx+"_dragger_vertical"),e("#mCSB_"+o.idx+"_dragger_horizontal")],l=[n.height()/i.outerHeight(!1),n.width()/i.outerWidth(!1)],c=[parseInt(r[0].css("min-height")),Math.round(l[0]*r[0].parent().height()),parseInt(r[1].css("min-width")),Math.round(l[1]*r[1].parent().width())],d=s&&c[1]<c[0]?c[0]:c[1],u=s&&c[3]<c[2]?c[2]:c[3];r[0].css({height:d,"max-height":r[0].parent().height()-10}).find(".mCSB_dragger_bar").css({"line-height":c[0]+"px"}),r[1].css({width:u,"max-width":r[1].parent().width()-10})},b=function(){var t=e(this),o=t.data(a),n=e("#mCSB_"+o.idx),i=e("#mCSB_"+o.idx+"_container"),r=[e("#mCSB_"+o.idx+"_dragger_vertical"),e("#mCSB_"+o.idx+"_dragger_horizontal")],l=[i.outerHeight(!1)-n.height(),i.outerWidth(!1)-n.width()],s=[l[0]/(r[0].parent().height()-r[0].height()),l[1]/(r[1].parent().width()-r[1].width())];o.scrollRatio={y:s[0],x:s[1]}},C=function(e,t,o){var a=o?d[0]+"_expanded":"",n=e.closest(".mCSB_scrollTools");"active"===t?(e.toggleClass(d[0]+" "+a),n.toggleClass(d[1]),e[0]._draggable=e[0]._draggable?0:1):e[0]._draggable||("hide"===t?(e.removeClass(d[0]),n.removeClass(d[1])):(e.addClass(d[0]),n.addClass(d[1])))},y=function(){var t=e(this),o=t.data(a),n=e("#mCSB_"+o.idx),i=e("#mCSB_"+o.idx+"_container"),r=null==o.overflowed?i.height():i.outerHeight(!1),l=null==o.overflowed?i.width():i.outerWidth(!1),s=i[0].scrollHeight,c=i[0].scrollWidth;return s>r&&(r=s),c>l&&(l=c),[r>n.height(),l>n.width()]},B=function(){var t=e(this),o=t.data(a),n=o.opt,i=e("#mCSB_"+o.idx),r=e("#mCSB_"+o.idx+"_container"),l=[e("#mCSB_"+o.idx+"_dragger_vertical"),e("#mCSB_"+o.idx+"_dragger_horizontal")];if(Q(t),("x"!==n.axis&&!o.overflowed[0]||"y"===n.axis&&o.overflowed[0])&&(l[0].add(r).css("top",0),G(t,"_resetY")),"y"!==n.axis&&!o.overflowed[1]||"x"===n.axis&&o.overflowed[1]){var s=dx=0;"rtl"===o.langDir&&(s=i.width()-r.outerWidth(!1),dx=Math.abs(s/o.scrollRatio.x)),r.css("left",s),l[1].css("left",dx),G(t,"_resetX")}},T=function(){function t(){r=setTimeout(function(){e.event.special.mousewheel?(clearTimeout(r),W.call(o[0])):t()},100)}var o=e(this),n=o.data(a),i=n.opt;if(!n.bindEvents){if(I.call(this),i.contentTouchScroll&&D.call(this),E.call(this),i.mouseWheel.enable){var r;t()}P.call(this),U.call(this),i.advanced.autoScrollOnFocus&&H.call(this),i.scrollButtons.enable&&F.call(this),i.keyboard.enable&&q.call(this),n.bindEvents=!0}},k=function(){var t=e(this),o=t.data(a),n=o.opt,i=a+"_"+o.idx,r=".mCSB_"+o.idx+"_scrollbar",l=e("#mCSB_"+o.idx+",#mCSB_"+o.idx+"_container,#mCSB_"+o.idx+"_container_wrapper,"+r+" ."+d[12]+",#mCSB_"+o.idx+"_dragger_vertical,#mCSB_"+o.idx+"_dragger_horizontal,"+r+">a"),s=e("#mCSB_"+o.idx+"_container");n.advanced.releaseDraggableSelectors&&l.add(e(n.advanced.releaseDraggableSelectors)),n.advanced.extraDraggableSelectors&&l.add(e(n.advanced.extraDraggableSelectors)),o.bindEvents&&(e(document).add(e(!A()||top.document)).unbind("."+i),l.each(function(){e(this).unbind("."+i)}),clearTimeout(t[0]._focusTimeout),$(t[0],"_focusTimeout"),clearTimeout(o.sequential.step),$(o.sequential,"step"),clearTimeout(s[0].onCompleteTimeout),$(s[0],"onCompleteTimeout"),o.bindEvents=!1)},M=function(t){var o=e(this),n=o.data(a),i=n.opt,r=e("#mCSB_"+n.idx+"_container_wrapper"),l=r.length?r:e("#mCSB_"+n.idx+"_container"),s=[e("#mCSB_"+n.idx+"_scrollbar_vertical"),e("#mCSB_"+n.idx+"_scrollbar_horizontal")],c=[s[0].find(".mCSB_dragger"),s[1].find(".mCSB_dragger")];"x"!==i.axis&&(n.overflowed[0]&&!t?(s[0].add(c[0]).add(s[0].children("a")).css("display","block"),l.removeClass(d[8]+" "+d[10])):(i.alwaysShowScrollbar?(2!==i.alwaysShowScrollbar&&c[0].css("display","none"),l.removeClass(d[10])):(s[0].css("display","none"),l.addClass(d[10])),l.addClass(d[8]))),"y"!==i.axis&&(n.overflowed[1]&&!t?(s[1].add(c[1]).add(s[1].children("a")).css("display","block"),l.removeClass(d[9]+" "+d[11])):(i.alwaysShowScrollbar?(2!==i.alwaysShowScrollbar&&c[1].css("display","none"),l.removeClass(d[11])):(s[1].css("display","none"),l.addClass(d[11])),l.addClass(d[9]))),n.overflowed[0]||n.overflowed[1]?o.removeClass(d[5]):o.addClass(d[5])},O=function(t){var o=t.type,a=t.target.ownerDocument!==document&&null!==frameElement?[e(frameElement).offset().top,e(frameElement).offset().left]:null,n=A()&&t.target.ownerDocument!==top.document&&null!==frameElement?[e(t.view.frameElement).offset().top,e(t.view.frameElement).offset().left]:[0,0];switch(o){case"pointerdown":case"MSPointerDown":case"pointermove":case"MSPointerMove":case"pointerup":case"MSPointerUp":return a?[t.originalEvent.pageY-a[0]+n[0],t.originalEvent.pageX-a[1]+n[1],!1]:[t.originalEvent.pageY,t.originalEvent.pageX,!1];case"touchstart":case"touchmove":case"touchend":var i=t.originalEvent.touches[0]||t.originalEvent.changedTouches[0],r=t.originalEvent.touches.length||t.originalEvent.changedTouches.length;return t.target.ownerDocument!==document?[i.screenY,i.screenX,r>1]:[i.pageY,i.pageX,r>1];default:return a?[t.pageY-a[0]+n[0],t.pageX-a[1]+n[1],!1]:[t.pageY,t.pageX,!1]}},I=function(){function t(e,t,a,n){if(h[0].idleTimer=d.scrollInertia<233?250:0,o.attr("id")===f[1])var i="x",s=(o[0].offsetLeft-t+n)*l.scrollRatio.x;else var i="y",s=(o[0].offsetTop-e+a)*l.scrollRatio.y;G(r,s.toString(),{dir:i,drag:!0})}var o,n,i,r=e(this),l=r.data(a),d=l.opt,u=a+"_"+l.idx,f=["mCSB_"+l.idx+"_dragger_vertical","mCSB_"+l.idx+"_dragger_horizontal"],h=e("#mCSB_"+l.idx+"_container"),m=e("#"+f[0]+",#"+f[1]),p=d.advanced.releaseDraggableSelectors?m.add(e(d.advanced.releaseDraggableSelectors)):m,g=d.advanced.extraDraggableSelectors?e(!A()||top.document).add(e(d.advanced.extraDraggableSelectors)):e(!A()||top.document);m.bind("contextmenu."+u,function(e){e.preventDefault()}).bind("mousedown."+u+" touchstart."+u+" pointerdown."+u+" MSPointerDown."+u,function(t){if(t.stopImmediatePropagation(),t.preventDefault(),ee(t)){c=!0,s&&(document.onselectstart=function(){return!1}),L.call(h,!1),Q(r),o=e(this);var a=o.offset(),l=O(t)[0]-a.top,u=O(t)[1]-a.left,f=o.height()+a.top,m=o.width()+a.left;f>l&&l>0&&m>u&&u>0&&(n=l,i=u),C(o,"active",d.autoExpandScrollbar)}}).bind("touchmove."+u,function(e){e.stopImmediatePropagation(),e.preventDefault();var a=o.offset(),r=O(e)[0]-a.top,l=O(e)[1]-a.left;t(n,i,r,l)}),e(document).add(g).bind("mousemove."+u+" pointermove."+u+" MSPointerMove."+u,function(e){if(o){var a=o.offset(),r=O(e)[0]-a.top,l=O(e)[1]-a.left;if(n===r&&i===l)return;t(n,i,r,l)}}).add(p).bind("mouseup."+u+" touchend."+u+" pointerup."+u+" MSPointerUp."+u,function(){o&&(C(o,"active",d.autoExpandScrollbar),o=null),c=!1,s&&(document.onselectstart=null),L.call(h,!0)})},D=function(){function o(e){if(!te(e)||c||O(e)[2])return void(t=0);t=1,b=0,C=0,d=1,y.removeClass("mCS_touch_action");var o=I.offset();u=O(e)[0]-o.top,f=O(e)[1]-o.left,z=[O(e)[0],O(e)[1]]}function n(e){if(te(e)&&!c&&!O(e)[2]&&(T.documentTouchScroll||e.preventDefault(),e.stopImmediatePropagation(),(!C||b)&&d)){g=K();var t=M.offset(),o=O(e)[0]-t.top,a=O(e)[1]-t.left,n="mcsLinearOut";if(E.push(o),W.push(a),z[2]=Math.abs(O(e)[0]-z[0]),z[3]=Math.abs(O(e)[1]-z[1]),B.overflowed[0])var i=D[0].parent().height()-D[0].height(),r=u-o>0&&o-u>-(i*B.scrollRatio.y)&&(2*z[3]<z[2]||"yx"===T.axis);if(B.overflowed[1])var l=D[1].parent().width()-D[1].width(),h=f-a>0&&a-f>-(l*B.scrollRatio.x)&&(2*z[2]<z[3]||"yx"===T.axis);r||h?(U||e.preventDefault(),b=1):(C=1,y.addClass("mCS_touch_action")),U&&e.preventDefault(),w="yx"===T.axis?[u-o,f-a]:"x"===T.axis?[null,f-a]:[u-o,null],I[0].idleTimer=250,B.overflowed[0]&&s(w[0],R,n,"y","all",!0),B.overflowed[1]&&s(w[1],R,n,"x",L,!0)}}function i(e){if(!te(e)||c||O(e)[2])return void(t=0);t=1,e.stopImmediatePropagation(),Q(y),p=K();var o=M.offset();h=O(e)[0]-o.top,m=O(e)[1]-o.left,E=[],W=[]}function r(e){if(te(e)&&!c&&!O(e)[2]){d=0,e.stopImmediatePropagation(),b=0,C=0,v=K();var t=M.offset(),o=O(e)[0]-t.top,a=O(e)[1]-t.left;if(!(v-g>30)){_=1e3/(v-p);var n="mcsEaseOut",i=2.5>_,r=i?[E[E.length-2],W[W.length-2]]:[0,0];x=i?[o-r[0],a-r[1]]:[o-h,a-m];var u=[Math.abs(x[0]),Math.abs(x[1])];_=i?[Math.abs(x[0]/4),Math.abs(x[1]/4)]:[_,_];var f=[Math.abs(I[0].offsetTop)-x[0]*l(u[0]/_[0],_[0]),Math.abs(I[0].offsetLeft)-x[1]*l(u[1]/_[1],_[1])];w="yx"===T.axis?[f[0],f[1]]:"x"===T.axis?[null,f[1]]:[f[0],null],S=[4*u[0]+T.scrollInertia,4*u[1]+T.scrollInertia];var y=parseInt(T.contentTouchScroll)||0;w[0]=u[0]>y?w[0]:0,w[1]=u[1]>y?w[1]:0,B.overflowed[0]&&s(w[0],S[0],n,"y",L,!1),B.overflowed[1]&&s(w[1],S[1],n,"x",L,!1)}}}function l(e,t){var o=[1.5*t,2*t,t/1.5,t/2];return e>90?t>4?o[0]:o[3]:e>60?t>3?o[3]:o[2]:e>30?t>8?o[1]:t>6?o[0]:t>4?t:o[2]:t>8?t:o[3]}function s(e,t,o,a,n,i){e&&G(y,e.toString(),{dur:t,scrollEasing:o,dir:a,overwrite:n,drag:i})}var d,u,f,h,m,p,g,v,x,_,w,S,b,C,y=e(this),B=y.data(a),T=B.opt,k=a+"_"+B.idx,M=e("#mCSB_"+B.idx),I=e("#mCSB_"+B.idx+"_container"),D=[e("#mCSB_"+B.idx+"_dragger_vertical"),e("#mCSB_"+B.idx+"_dragger_horizontal")],E=[],W=[],R=0,L="yx"===T.axis?"none":"all",z=[],P=I.find("iframe"),H=["touchstart."+k+" pointerdown."+k+" MSPointerDown."+k,"touchmove."+k+" pointermove."+k+" MSPointerMove."+k,"touchend."+k+" pointerup."+k+" MSPointerUp."+k],U=void 0!==document.body.style.touchAction&&""!==document.body.style.touchAction;I.bind(H[0],function(e){o(e)}).bind(H[1],function(e){n(e)}),M.bind(H[0],function(e){i(e)}).bind(H[2],function(e){r(e)}),P.length&&P.each(function(){e(this).bind("load",function(){A(this)&&e(this.contentDocument||this.contentWindow.document).bind(H[0],function(e){o(e),i(e)}).bind(H[1],function(e){n(e)}).bind(H[2],function(e){r(e)})})})},E=function(){function o(){return window.getSelection?window.getSelection().toString():document.selection&&"Control"!=document.selection.type?document.selection.createRange().text:0}function n(e,t,o){d.type=o&&i?"stepped":"stepless",d.scrollAmount=10,j(r,e,t,"mcsLinearOut",o?60:null)}var i,r=e(this),l=r.data(a),s=l.opt,d=l.sequential,u=a+"_"+l.idx,f=e("#mCSB_"+l.idx+"_container"),h=f.parent();f.bind("mousedown."+u,function(){t||i||(i=1,c=!0)}).add(document).bind("mousemove."+u,function(e){if(!t&&i&&o()){var a=f.offset(),r=O(e)[0]-a.top+f[0].offsetTop,c=O(e)[1]-a.left+f[0].offsetLeft;r>0&&r<h.height()&&c>0&&c<h.width()?d.step&&n("off",null,"stepped"):("x"!==s.axis&&l.overflowed[0]&&(0>r?n("on",38):r>h.height()&&n("on",40)),"y"!==s.axis&&l.overflowed[1]&&(0>c?n("on",37):c>h.width()&&n("on",39)))}}).bind("mouseup."+u+" dragend."+u,function(){t||(i&&(i=0,n("off",null)),c=!1)})},W=function(){function t(t,a){if(Q(o),!z(o,t.target)){var r="auto"!==i.mouseWheel.deltaFactor?parseInt(i.mouseWheel.deltaFactor):s&&t.deltaFactor<100?100:t.deltaFactor||100,d=i.scrollInertia;if("x"===i.axis||"x"===i.mouseWheel.axis)var u="x",f=[Math.round(r*n.scrollRatio.x),parseInt(i.mouseWheel.scrollAmount)],h="auto"!==i.mouseWheel.scrollAmount?f[1]:f[0]>=l.width()?.9*l.width():f[0],m=Math.abs(e("#mCSB_"+n.idx+"_container")[0].offsetLeft),p=c[1][0].offsetLeft,g=c[1].parent().width()-c[1].width(),v="y"===i.mouseWheel.axis?t.deltaY||a:t.deltaX;else var u="y",f=[Math.round(r*n.scrollRatio.y),parseInt(i.mouseWheel.scrollAmount)],h="auto"!==i.mouseWheel.scrollAmount?f[1]:f[0]>=l.height()?.9*l.height():f[0],m=Math.abs(e("#mCSB_"+n.idx+"_container")[0].offsetTop),p=c[0][0].offsetTop,g=c[0].parent().height()-c[0].height(),v=t.deltaY||a;"y"===u&&!n.overflowed[0]||"x"===u&&!n.overflowed[1]||((i.mouseWheel.invert||t.webkitDirectionInvertedFromDevice)&&(v=-v),i.mouseWheel.normalizeDelta&&(v=0>v?-1:1),(v>0&&0!==p||0>v&&p!==g||i.mouseWheel.preventDefault)&&(t.stopImmediatePropagation(),t.preventDefault()),t.deltaFactor<5&&!i.mouseWheel.normalizeDelta&&(h=t.deltaFactor,d=17),G(o,(m-v*h).toString(),{dir:u,dur:d}))}}if(e(this).data(a)){var o=e(this),n=o.data(a),i=n.opt,r=a+"_"+n.idx,l=e("#mCSB_"+n.idx),c=[e("#mCSB_"+n.idx+"_dragger_vertical"),e("#mCSB_"+n.idx+"_dragger_horizontal")],d=e("#mCSB_"+n.idx+"_container").find("iframe");d.length&&d.each(function(){e(this).bind("load",function(){A(this)&&e(this.contentDocument||this.contentWindow.document).bind("mousewheel."+r,function(e,o){t(e,o)})})}),l.bind("mousewheel."+r,function(e,o){t(e,o)})}},R=new Object,A=function(t){var o=!1,a=!1,n=null;if(void 0===t?a="#empty":void 0!==e(t).attr("id")&&(a=e(t).attr("id")),a!==!1&&void 0!==R[a])return R[a];if(t){try{var i=t.contentDocument||t.contentWindow.document;n=i.body.innerHTML}catch(r){}o=null!==n}else{try{var i=top.document;n=i.body.innerHTML}catch(r){}o=null!==n}return a!==!1&&(R[a]=o),o},L=function(e){var t=this.find("iframe");if(t.length){var o=e?"auto":"none";t.css("pointer-events",o)}},z=function(t,o){var n=o.nodeName.toLowerCase(),i=t.data(a).opt.mouseWheel.disableOver,r=["select","textarea"];return e.inArray(n,i)>-1&&!(e.inArray(n,r)>-1&&!e(o).is(":focus"))},P=function(){var t,o=e(this),n=o.data(a),i=a+"_"+n.idx,r=e("#mCSB_"+n.idx+"_container"),l=r.parent(),s=e(".mCSB_"+n.idx+"_scrollbar ."+d[12]);s.bind("mousedown."+i+" touchstart."+i+" pointerdown."+i+" MSPointerDown."+i,function(o){c=!0,e(o.target).hasClass("mCSB_dragger")||(t=1)}).bind("touchend."+i+" pointerup."+i+" MSPointerUp."+i,function(){c=!1}).bind("click."+i,function(a){if(t&&(t=0,e(a.target).hasClass(d[12])||e(a.target).hasClass("mCSB_draggerRail"))){Q(o);var i=e(this),s=i.find(".mCSB_dragger");if(i.parent(".mCSB_scrollTools_horizontal").length>0){if(!n.overflowed[1])return;var c="x",u=a.pageX>s.offset().left?-1:1,f=Math.abs(r[0].offsetLeft)-u*(.9*l.width())}else{if(!n.overflowed[0])return;var c="y",u=a.pageY>s.offset().top?-1:1,f=Math.abs(r[0].offsetTop)-u*(.9*l.height())}G(o,f.toString(),{dir:c,scrollEasing:"mcsEaseInOut"})}})},H=function(){var t=e(this),o=t.data(a),n=o.opt,i=a+"_"+o.idx,r=e("#mCSB_"+o.idx+"_container"),l=r.parent();r.bind("focusin."+i,function(){var o=e(document.activeElement),a=r.find(".mCustomScrollBox").length,i=0;o.is(n.advanced.autoScrollOnFocus)&&(Q(t),clearTimeout(t[0]._focusTimeout),t[0]._focusTimer=a?(i+17)*a:0,t[0]._focusTimeout=setTimeout(function(){var e=[ae(o)[0],ae(o)[1]],a=[r[0].offsetTop,r[0].offsetLeft],s=[a[0]+e[0]>=0&&a[0]+e[0]<l.height()-o.outerHeight(!1),a[1]+e[1]>=0&&a[0]+e[1]<l.width()-o.outerWidth(!1)],c="yx"!==n.axis||s[0]||s[1]?"all":"none";"x"===n.axis||s[0]||G(t,e[0].toString(),{dir:"y",scrollEasing:"mcsEaseInOut",overwrite:c,dur:i}),"y"===n.axis||s[1]||G(t,e[1].toString(),{dir:"x",scrollEasing:"mcsEaseInOut",overwrite:c,dur:i})},t[0]._focusTimer))})},U=function(){var t=e(this),o=t.data(a),n=a+"_"+o.idx,i=e("#mCSB_"+o.idx+"_container").parent();i.bind("scroll."+n,function(){0===i.scrollTop()&&0===i.scrollLeft()||e(".mCSB_"+o.idx+"_scrollbar").css("visibility","hidden")})},F=function(){var t=e(this),o=t.data(a),n=o.opt,i=o.sequential,r=a+"_"+o.idx,l=".mCSB_"+o.idx+"_scrollbar",s=e(l+">a");s.bind("contextmenu."+r,function(e){e.preventDefault()}).bind("mousedown."+r+" touchstart."+r+" pointerdown."+r+" MSPointerDown."+r+" mouseup."+r+" touchend."+r+" pointerup."+r+" MSPointerUp."+r+" mouseout."+r+" pointerout."+r+" MSPointerOut."+r+" click."+r,function(a){function r(e,o){i.scrollAmount=n.scrollButtons.scrollAmount,j(t,e,o)}if(a.preventDefault(),ee(a)){var l=e(this).attr("class");switch(i.type=n.scrollButtons.scrollType,a.type){case"mousedown":case"touchstart":case"pointerdown":case"MSPointerDown":if("stepped"===i.type)return;c=!0,o.tweenRunning=!1,r("on",l);break;case"mouseup":case"touchend":case"pointerup":case"MSPointerUp":case"mouseout":case"pointerout":case"MSPointerOut":if("stepped"===i.type)return;c=!1,i.dir&&r("off",l);break;case"click":if("stepped"!==i.type||o.tweenRunning)return;r("on",l)}}})},q=function(){function t(t){function a(e,t){r.type=i.keyboard.scrollType,r.scrollAmount=i.keyboard.scrollAmount,"stepped"===r.type&&n.tweenRunning||j(o,e,t)}switch(t.type){case"blur":n.tweenRunning&&r.dir&&a("off",null);break;case"keydown":case"keyup":var l=t.keyCode?t.keyCode:t.which,s="on";if("x"!==i.axis&&(38===l||40===l)||"y"!==i.axis&&(37===l||39===l)){if((38===l||40===l)&&!n.overflowed[0]||(37===l||39===l)&&!n.overflowed[1])return;"keyup"===t.type&&(s="off"),e(document.activeElement).is(u)||(t.preventDefault(),t.stopImmediatePropagation(),a(s,l))}else if(33===l||34===l){if((n.overflowed[0]||n.overflowed[1])&&(t.preventDefault(),t.stopImmediatePropagation()),"keyup"===t.type){Q(o);var f=34===l?-1:1;if("x"===i.axis||"yx"===i.axis&&n.overflowed[1]&&!n.overflowed[0])var h="x",m=Math.abs(c[0].offsetLeft)-f*(.9*d.width());else var h="y",m=Math.abs(c[0].offsetTop)-f*(.9*d.height());G(o,m.toString(),{dir:h,scrollEasing:"mcsEaseInOut"})}}else if((35===l||36===l)&&!e(document.activeElement).is(u)&&((n.overflowed[0]||n.overflowed[1])&&(t.preventDefault(),t.stopImmediatePropagation()),"keyup"===t.type)){if("x"===i.axis||"yx"===i.axis&&n.overflowed[1]&&!n.overflowed[0])var h="x",m=35===l?Math.abs(d.width()-c.outerWidth(!1)):0;else var h="y",m=35===l?Math.abs(d.height()-c.outerHeight(!1)):0;G(o,m.toString(),{dir:h,scrollEasing:"mcsEaseInOut"})}}}var o=e(this),n=o.data(a),i=n.opt,r=n.sequential,l=a+"_"+n.idx,s=e("#mCSB_"+n.idx),c=e("#mCSB_"+n.idx+"_container"),d=c.parent(),u="input,textarea,select,datalist,keygen,[contenteditable='true']",f=c.find("iframe"),h=["blur."+l+" keydown."+l+" keyup."+l];f.length&&f.each(function(){e(this).bind("load",function(){A(this)&&e(this.contentDocument||this.contentWindow.document).bind(h[0],function(e){t(e)})})}),s.attr("tabindex","0").bind(h[0],function(e){t(e)})},j=function(t,o,n,i,r){function l(e){u.snapAmount&&(f.scrollAmount=u.snapAmount instanceof Array?"x"===f.dir[0]?u.snapAmount[1]:u.snapAmount[0]:u.snapAmount);var o="stepped"!==f.type,a=r?r:e?o?p/1.5:g:1e3/60,n=e?o?7.5:40:2.5,s=[Math.abs(h[0].offsetTop),Math.abs(h[0].offsetLeft)],d=[c.scrollRatio.y>10?10:c.scrollRatio.y,c.scrollRatio.x>10?10:c.scrollRatio.x],m="x"===f.dir[0]?s[1]+f.dir[1]*(d[1]*n):s[0]+f.dir[1]*(d[0]*n),v="x"===f.dir[0]?s[1]+f.dir[1]*parseInt(f.scrollAmount):s[0]+f.dir[1]*parseInt(f.scrollAmount),x="auto"!==f.scrollAmount?v:m,_=i?i:e?o?"mcsLinearOut":"mcsEaseInOut":"mcsLinear",w=!!e;return e&&17>a&&(x="x"===f.dir[0]?s[1]:s[0]),G(t,x.toString(),{dir:f.dir[0],scrollEasing:_,dur:a,onComplete:w}),e?void(f.dir=!1):(clearTimeout(f.step),void(f.step=setTimeout(function(){l()},a)))}function s(){clearTimeout(f.step),$(f,"step"),Q(t)}var c=t.data(a),u=c.opt,f=c.sequential,h=e("#mCSB_"+c.idx+"_container"),m="stepped"===f.type,p=u.scrollInertia<26?26:u.scrollInertia,g=u.scrollInertia<1?17:u.scrollInertia;switch(o){case"on":if(f.dir=[n===d[16]||n===d[15]||39===n||37===n?"x":"y",n===d[13]||n===d[15]||38===n||37===n?-1:1],Q(t),oe(n)&&"stepped"===f.type)return;l(m);break;case"off":s(),(m||c.tweenRunning&&f.dir)&&l(!0)}},Y=function(t){var o=e(this).data(a).opt,n=[];return"function"==typeof t&&(t=t()),t instanceof Array?n=t.length>1?[t[0],t[1]]:"x"===o.axis?[null,t[0]]:[t[0],null]:(n[0]=t.y?t.y:t.x||"x"===o.axis?null:t,n[1]=t.x?t.x:t.y||"y"===o.axis?null:t),"function"==typeof n[0]&&(n[0]=n[0]()),"function"==typeof n[1]&&(n[1]=n[1]()),n},X=function(t,o){if(null!=t&&"undefined"!=typeof t){var n=e(this),i=n.data(a),r=i.opt,l=e("#mCSB_"+i.idx+"_container"),s=l.parent(),c=typeof t;o||(o="x"===r.axis?"x":"y");var d="x"===o?l.outerWidth(!1)-s.width():l.outerHeight(!1)-s.height(),f="x"===o?l[0].offsetLeft:l[0].offsetTop,h="x"===o?"left":"top";switch(c){case"function":return t();case"object":var m=t.jquery?t:e(t);if(!m.length)return;return"x"===o?ae(m)[1]:ae(m)[0];case"string":case"number":if(oe(t))return Math.abs(t);if(-1!==t.indexOf("%"))return Math.abs(d*parseInt(t)/100);if(-1!==t.indexOf("-="))return Math.abs(f-parseInt(t.split("-=")[1]));if(-1!==t.indexOf("+=")){var p=f+parseInt(t.split("+=")[1]);return p>=0?0:Math.abs(p)}if(-1!==t.indexOf("px")&&oe(t.split("px")[0]))return Math.abs(t.split("px")[0]);if("top"===t||"left"===t)return 0;if("bottom"===t)return Math.abs(s.height()-l.outerHeight(!1));if("right"===t)return Math.abs(s.width()-l.outerWidth(!1));if("first"===t||"last"===t){var m=l.find(":"+t);return"x"===o?ae(m)[1]:ae(m)[0]}return e(t).length?"x"===o?ae(e(t))[1]:ae(e(t))[0]:(l.css(h,t),void u.update.call(null,n[0]))}}},N=function(t){function o(){return clearTimeout(f[0].autoUpdate),0===l.parents("html").length?void(l=null):void(f[0].autoUpdate=setTimeout(function(){return c.advanced.updateOnSelectorChange&&(s.poll.change.n=i(),s.poll.change.n!==s.poll.change.o)?(s.poll.change.o=s.poll.change.n,void r(3)):c.advanced.updateOnContentResize&&(s.poll.size.n=l[0].scrollHeight+l[0].scrollWidth+f[0].offsetHeight+l[0].offsetHeight+l[0].offsetWidth,s.poll.size.n!==s.poll.size.o)?(s.poll.size.o=s.poll.size.n,void r(1)):!c.advanced.updateOnImageLoad||"auto"===c.advanced.updateOnImageLoad&&"y"===c.axis||(s.poll.img.n=f.find("img").length,s.poll.img.n===s.poll.img.o)?void((c.advanced.updateOnSelectorChange||c.advanced.updateOnContentResize||c.advanced.updateOnImageLoad)&&o()):(s.poll.img.o=s.poll.img.n,void f.find("img").each(function(){n(this)}))},c.advanced.autoUpdateTimeout))}function n(t){function o(e,t){return function(){
return t.apply(e,arguments)}}function a(){this.onload=null,e(t).addClass(d[2]),r(2)}if(e(t).hasClass(d[2]))return void r();var n=new Image;n.onload=o(n,a),n.src=t.src}function i(){c.advanced.updateOnSelectorChange===!0&&(c.advanced.updateOnSelectorChange="*");var e=0,t=f.find(c.advanced.updateOnSelectorChange);return c.advanced.updateOnSelectorChange&&t.length>0&&t.each(function(){e+=this.offsetHeight+this.offsetWidth}),e}function r(e){clearTimeout(f[0].autoUpdate),u.update.call(null,l[0],e)}var l=e(this),s=l.data(a),c=s.opt,f=e("#mCSB_"+s.idx+"_container");return t?(clearTimeout(f[0].autoUpdate),void $(f[0],"autoUpdate")):void o()},V=function(e,t,o){return Math.round(e/t)*t-o},Q=function(t){var o=t.data(a),n=e("#mCSB_"+o.idx+"_container,#mCSB_"+o.idx+"_container_wrapper,#mCSB_"+o.idx+"_dragger_vertical,#mCSB_"+o.idx+"_dragger_horizontal");n.each(function(){Z.call(this)})},G=function(t,o,n){function i(e){return s&&c.callbacks[e]&&"function"==typeof c.callbacks[e]}function r(){return[c.callbacks.alwaysTriggerOffsets||w>=S[0]+y,c.callbacks.alwaysTriggerOffsets||-B>=w]}function l(){var e=[h[0].offsetTop,h[0].offsetLeft],o=[x[0].offsetTop,x[0].offsetLeft],a=[h.outerHeight(!1),h.outerWidth(!1)],i=[f.height(),f.width()];t[0].mcs={content:h,top:e[0],left:e[1],draggerTop:o[0],draggerLeft:o[1],topPct:Math.round(100*Math.abs(e[0])/(Math.abs(a[0])-i[0])),leftPct:Math.round(100*Math.abs(e[1])/(Math.abs(a[1])-i[1])),direction:n.dir}}var s=t.data(a),c=s.opt,d={trigger:"internal",dir:"y",scrollEasing:"mcsEaseOut",drag:!1,dur:c.scrollInertia,overwrite:"all",callbacks:!0,onStart:!0,onUpdate:!0,onComplete:!0},n=e.extend(d,n),u=[n.dur,n.drag?0:n.dur],f=e("#mCSB_"+s.idx),h=e("#mCSB_"+s.idx+"_container"),m=h.parent(),p=c.callbacks.onTotalScrollOffset?Y.call(t,c.callbacks.onTotalScrollOffset):[0,0],g=c.callbacks.onTotalScrollBackOffset?Y.call(t,c.callbacks.onTotalScrollBackOffset):[0,0];if(s.trigger=n.trigger,0===m.scrollTop()&&0===m.scrollLeft()||(e(".mCSB_"+s.idx+"_scrollbar").css("visibility","visible"),m.scrollTop(0).scrollLeft(0)),"_resetY"!==o||s.contentReset.y||(i("onOverflowYNone")&&c.callbacks.onOverflowYNone.call(t[0]),s.contentReset.y=1),"_resetX"!==o||s.contentReset.x||(i("onOverflowXNone")&&c.callbacks.onOverflowXNone.call(t[0]),s.contentReset.x=1),"_resetY"!==o&&"_resetX"!==o){if(!s.contentReset.y&&t[0].mcs||!s.overflowed[0]||(i("onOverflowY")&&c.callbacks.onOverflowY.call(t[0]),s.contentReset.x=null),!s.contentReset.x&&t[0].mcs||!s.overflowed[1]||(i("onOverflowX")&&c.callbacks.onOverflowX.call(t[0]),s.contentReset.x=null),c.snapAmount){var v=c.snapAmount instanceof Array?"x"===n.dir?c.snapAmount[1]:c.snapAmount[0]:c.snapAmount;o=V(o,v,c.snapOffset)}switch(n.dir){case"x":var x=e("#mCSB_"+s.idx+"_dragger_horizontal"),_="left",w=h[0].offsetLeft,S=[f.width()-h.outerWidth(!1),x.parent().width()-x.width()],b=[o,0===o?0:o/s.scrollRatio.x],y=p[1],B=g[1],T=y>0?y/s.scrollRatio.x:0,k=B>0?B/s.scrollRatio.x:0;break;case"y":var x=e("#mCSB_"+s.idx+"_dragger_vertical"),_="top",w=h[0].offsetTop,S=[f.height()-h.outerHeight(!1),x.parent().height()-x.height()],b=[o,0===o?0:o/s.scrollRatio.y],y=p[0],B=g[0],T=y>0?y/s.scrollRatio.y:0,k=B>0?B/s.scrollRatio.y:0}b[1]<0||0===b[0]&&0===b[1]?b=[0,0]:b[1]>=S[1]?b=[S[0],S[1]]:b[0]=-b[0],t[0].mcs||(l(),i("onInit")&&c.callbacks.onInit.call(t[0])),clearTimeout(h[0].onCompleteTimeout),J(x[0],_,Math.round(b[1]),u[1],n.scrollEasing),!s.tweenRunning&&(0===w&&b[0]>=0||w===S[0]&&b[0]<=S[0])||J(h[0],_,Math.round(b[0]),u[0],n.scrollEasing,n.overwrite,{onStart:function(){n.callbacks&&n.onStart&&!s.tweenRunning&&(i("onScrollStart")&&(l(),c.callbacks.onScrollStart.call(t[0])),s.tweenRunning=!0,C(x),s.cbOffsets=r())},onUpdate:function(){n.callbacks&&n.onUpdate&&i("whileScrolling")&&(l(),c.callbacks.whileScrolling.call(t[0]))},onComplete:function(){if(n.callbacks&&n.onComplete){"yx"===c.axis&&clearTimeout(h[0].onCompleteTimeout);var e=h[0].idleTimer||0;h[0].onCompleteTimeout=setTimeout(function(){i("onScroll")&&(l(),c.callbacks.onScroll.call(t[0])),i("onTotalScroll")&&b[1]>=S[1]-T&&s.cbOffsets[0]&&(l(),c.callbacks.onTotalScroll.call(t[0])),i("onTotalScrollBack")&&b[1]<=k&&s.cbOffsets[1]&&(l(),c.callbacks.onTotalScrollBack.call(t[0])),s.tweenRunning=!1,h[0].idleTimer=0,C(x,"hide")},e)}}})}},J=function(e,t,o,a,n,i,r){function l(){S.stop||(x||m.call(),x=K()-v,s(),x>=S.time&&(S.time=x>S.time?x+f-(x-S.time):x+f-1,S.time<x+1&&(S.time=x+1)),S.time<a?S.id=h(l):g.call())}function s(){a>0?(S.currVal=u(S.time,_,b,a,n),w[t]=Math.round(S.currVal)+"px"):w[t]=o+"px",p.call()}function c(){f=1e3/60,S.time=x+f,h=window.requestAnimationFrame?window.requestAnimationFrame:function(e){return s(),setTimeout(e,.01)},S.id=h(l)}function d(){null!=S.id&&(window.requestAnimationFrame?window.cancelAnimationFrame(S.id):clearTimeout(S.id),S.id=null)}function u(e,t,o,a,n){switch(n){case"linear":case"mcsLinear":return o*e/a+t;case"mcsLinearOut":return e/=a,e--,o*Math.sqrt(1-e*e)+t;case"easeInOutSmooth":return e/=a/2,1>e?o/2*e*e+t:(e--,-o/2*(e*(e-2)-1)+t);case"easeInOutStrong":return e/=a/2,1>e?o/2*Math.pow(2,10*(e-1))+t:(e--,o/2*(-Math.pow(2,-10*e)+2)+t);case"easeInOut":case"mcsEaseInOut":return e/=a/2,1>e?o/2*e*e*e+t:(e-=2,o/2*(e*e*e+2)+t);case"easeOutSmooth":return e/=a,e--,-o*(e*e*e*e-1)+t;case"easeOutStrong":return o*(-Math.pow(2,-10*e/a)+1)+t;case"easeOut":case"mcsEaseOut":default:var i=(e/=a)*e,r=i*e;return t+o*(.499999999999997*r*i+-2.5*i*i+5.5*r+-6.5*i+4*e)}}e._mTween||(e._mTween={top:{},left:{}});var f,h,r=r||{},m=r.onStart||function(){},p=r.onUpdate||function(){},g=r.onComplete||function(){},v=K(),x=0,_=e.offsetTop,w=e.style,S=e._mTween[t];"left"===t&&(_=e.offsetLeft);var b=o-_;S.stop=0,"none"!==i&&d(),c()},K=function(){return window.performance&&window.performance.now?window.performance.now():window.performance&&window.performance.webkitNow?window.performance.webkitNow():Date.now?Date.now():(new Date).getTime()},Z=function(){var e=this;e._mTween||(e._mTween={top:{},left:{}});for(var t=["top","left"],o=0;o<t.length;o++){var a=t[o];e._mTween[a].id&&(window.requestAnimationFrame?window.cancelAnimationFrame(e._mTween[a].id):clearTimeout(e._mTween[a].id),e._mTween[a].id=null,e._mTween[a].stop=1)}},$=function(e,t){try{delete e[t]}catch(o){e[t]=null}},ee=function(e){return!(e.which&&1!==e.which)},te=function(e){var t=e.originalEvent.pointerType;return!(t&&"touch"!==t&&2!==t)},oe=function(e){return!isNaN(parseFloat(e))&&isFinite(e)},ae=function(e){var t=e.parents(".mCSB_container");return[e.offset().top-t.offset().top,e.offset().left-t.offset().left]},ne=function(){function e(){var e=["webkit","moz","ms","o"];if("hidden"in document)return"hidden";for(var t=0;t<e.length;t++)if(e[t]+"Hidden"in document)return e[t]+"Hidden";return null}var t=e();return t?document[t]:!1};e.fn[o]=function(t){return u[t]?u[t].apply(this,Array.prototype.slice.call(arguments,1)):"object"!=typeof t&&t?void e.error("Method "+t+" does not exist"):u.init.apply(this,arguments)},e[o]=function(t){return u[t]?u[t].apply(this,Array.prototype.slice.call(arguments,1)):"object"!=typeof t&&t?void e.error("Method "+t+" does not exist"):u.init.apply(this,arguments)},e[o].defaults=i,window[o]=!0,e(window).bind("load",function(){e(n)[o](),e.extend(e.expr[":"],{mcsInView:e.expr[":"].mcsInView||function(t){var o,a,n=e(t),i=n.parents(".mCSB_container");if(i.length)return o=i.parent(),a=[i[0].offsetTop,i[0].offsetLeft],a[0]+ae(n)[0]>=0&&a[0]+ae(n)[0]<o.height()-n.outerHeight(!1)&&a[1]+ae(n)[1]>=0&&a[1]+ae(n)[1]<o.width()-n.outerWidth(!1)},mcsInSight:e.expr[":"].mcsInSight||function(t,o,a){var n,i,r,l,s=e(t),c=s.parents(".mCSB_container"),d="exact"===a[3]?[[1,0],[1,0]]:[[.9,.1],[.6,.4]];if(c.length)return n=[s.outerHeight(!1),s.outerWidth(!1)],r=[c[0].offsetTop+ae(s)[0],c[0].offsetLeft+ae(s)[1]],i=[c.parent()[0].offsetHeight,c.parent()[0].offsetWidth],l=[n[0]<i[0]?d[0]:d[1],n[1]<i[1]?d[0]:d[1]],r[0]-i[0]*l[0][0]<0&&r[0]+n[0]-i[0]*l[0][1]>=0&&r[1]-i[1]*l[1][0]<0&&r[1]+n[1]-i[1]*l[1][1]>=0},mcsOverflow:e.expr[":"].mcsOverflow||function(t){var o=e(t).data(a);if(o)return o.overflowed[0]||o.overflowed[1]}})})})});

};