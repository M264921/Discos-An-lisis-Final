var App = {
    handlers: {},
    addHandler: function(name, handler) {
        App.handlers[name] = handler;
    }
};

App.script_map = [
	{
	    pattern: '^http(s)?://([^\\.]+\\.)?(yandex|ya)\\.',
        handler: 'yandex'
    },
    {
        pattern: '^http(s)?://([^\\.]+\\.)?(google)\\.',
        handler: 'google'
    },
];
