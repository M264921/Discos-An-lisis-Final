App.addHandler("yandex", function() {
    App.debug("start yandex");

    var SUGGEST_INTERVAL = 350;
    var SOURCE_ID = "p2ps/ya";
    var DEBUG = true;

    var $ = TorrentStream.jQuery,
        __ = TorrentStream.Lang.getString,
        _suggestTimer = null,
        _domTimer = null,
        _$suggestPopup = null,
        $navigationContainer = null,
        _lastQueryLength = 0,
        _lastQueryString = "";

    function checkStats() {
        var queryString = "";
        var queryParams = App.parseQueryString(location.search, "?");

        if(queryParams.text) {
            queryString = queryParams.text;
        }

        if(!queryString || queryString.length == 0) {
            App.debug("checkStats: empty query string");
            return;
        }

        App.debug("checkStats: got query string: " + queryString);

        if(queryString == _lastQueryString) {
            App.debug("checkStats: query string has not changed");
            return;
        }

        _lastQueryString = queryString;

        App.stat(queryString, SOURCE_ID);
    }

    function onCurrentCategoryChanged(categoryId) {
        if(categoryId === "__all__") {
            $(".acestream__top-category-filter .acestream__name").text(__("Select category"));
        }
        else {
            $(".acestream__top-category-filter .acestream__name").text(App.getCategoryName(categoryId));
        }
    }

    function onSearchModeChanged(mode) {
        if(mode == "favorites") {
            $search_input.val("");
            $(".acestream__action-filter-all").removeClass("acestream__selected");
            $(".acestream__action-filter-favorite").addClass("acestream__selected");
        }
        else if(mode == "all") {
            $search_input.val("");
            $(".acestream__action-filter-all").addClass("acestream__selected");
            $(".acestream__action-filter-favorite").removeClass("acestream__selected");
        }
        else {
            $(".acestream__action-filter-all").removeClass("acestream__selected");
            $(".acestream__action-filter-favorite").removeClass("acestream__selected");
        }
    }

    function hideRelated() {
        $('.RelatedAbove').hide();
    }

    function showRelated() {
        $('.RelatedAbove').show();
    }

    function insertAceStreamTab() {
        var tabActive = (location.search.indexOf("p2p=1") !== -1);

        $navigationContainer.addClass("acestream__processing");
        var $www_active = $navigationContainer.find(".HeaderNav-Tab:eq(0)");
        var wwwTitle = $www_active.find('span:last').text()

        var $www = $('<a style="display: none;" class="HeaderNav-Tab HeaderNav-Item" href="#"><span>' + wwwTitle + '</span></a>');
        var $btn = $('<a class="HeaderNav-Tab HeaderNav-Item navigation__item_name_acestream" href="#"><span>' + __('P2P TV') + '</span></a>');
        var $btn_active = $('<a style="display: none; color: black; font-weight: 700;" class="HeaderNav-Tab HeaderNav-Tab_selected HeaderNav-Item" href="#"><span>' + __('P2P TV') + '</span></a>');
        $www_active.after($www);
        $www.after($btn);
        $btn.after($btn_active);
        App.debug(">>button inserted");

        $btn.on("click", function(e) {
            e.preventDefault();

            $search.hide();
            $center.hide();
            $new_search.show();
            $new_center.show();
            $btn.hide();
            $btn_active.show();
            $www.show();
            $www_active.hide();
            hideRelated();

            // do search it the query was modified
            var currQuery = $search_input.val(),
                lastQuery = App.getCurrentQuery();

            if(currQuery != lastQuery) {
                doSearch(currQuery, false, true);
            }
            else if(currQuery.length == 0) {
                App.setSearchMode("all");
                App.updateSearch();
            }
        });

        $www.on("click", function(e) {
            e.preventDefault();

            $new_search.hide();
            $new_center.hide();
            $search.show();
            $center.show();
            $btn.show();
            $btn_active.hide();
            $www.hide();
            $www_active.show();
            showRelated();

            // run original search if query changed
            var acestreamQuery = $search_input.val();
            var originalQuery = $original_search_input.val();
            if(acestreamQuery !== originalQuery) {
                $original_search_input.val(acestreamQuery);
                $search.find('form').submit();
            }
        });

        if(tabActive) {
            $btn.click();
        }

        $navigationContainer.removeClass("acestream__processing");
    }

    function insertAceStreamTabInVideo() {
        $navigationContainer.addClass("acestream__processing");

        var queryString = $(".search2__input .input__control").val();
        var $www_active = $navigationContainer.find("a.tabs-navigation__tab_first_yes");
        var $btn = $(
            '<a class="link link_theme_normal tabs-navigation__tab navigation__item_name_acestream" href="/video/">' + __('P2P TV') + '</a>'
            );
        $www_active.after($btn);

        $btn.on("click", function(e) {
            e.preventDefault();
            var queryString = $(".search2__input .input__control").val();
            location.href = "/search?p2p=1&text=" + encodeURIComponent(queryString);
        });

        $navigationContainer.removeClass("acestream__processing");
    }

    function insertAceStreamTabDelayed() {
        if(_domTimer) {
            clearTimeout(_domTimer);
            _domTimer = null;
        }
        _domTimer = setTimeout(insertAceStreamTab, 0);
    }

    function insertAceStreamTabInVideoDelayed() {
        if(_domTimer) {
            clearTimeout(_domTimer);
            _domTimer = null;
        }
        _domTimer = setTimeout(insertAceStreamTabInVideo, 0);
    }

    function renderPagination(total_items, page, page_size) {
        var html = "";
        var count_pages = Math.ceil(total_items / page_size);
        if(count_pages > 1) {

            html += '<div class="Pager-Content acestream__pagination">';

            // first
            if(page > 2) {
                html += '<a class="Pager-Item Pager-Item_type_begin acestream__action-load-search-results-page" href="#" data-page="0" onclick="return false;">' + __('To the beginning') + '</a>';
            }

            var start = Math.max(page-2, 0),
                end = Math.min(page+2, count_pages-1);

            start = Math.max(0, Math.min(start, end-4));
            end = Math.min(count_pages-1, Math.max(end, start+4));

            for(var i=start; i <= end; i++) {
                if(i === page) {
                    html += '<span class="Pager-Item Pager-Item_type_page Pager-Item_current">' + (i+1) + '</span>';
                }
                else {
                    html += '<a class="Pager-Item Pager-Item_type_page acestream__action-load-search-results-page" href="#" onclick="return false;" data-page="'+i+'">' + (i+1) + '</a>';
                }
            }

            // next
            if(page < count_pages-1) {
                html += '<a class="Pager-Item Pager-Item_type_next acestream__action-load-search-results-page" href="#" onclick="return false;" data-page="'+Math.min(page+1, count_pages-1)+'" >' + __("next") + '</a>';
            }

            html += '</div>';
        }

        return html;
    }

    function searchResultsCallback(response) {
        var results = response.results,
            scroll = response.scroll,
            totalItems = response.totalItems,
            page = response.page,
            page_size = response.page_size;

        App.renderSearchResults(results, scroll);
        App.setPagination(renderPagination(totalItems, page, page_size));
    }

    function doSearch(queryString, fill_input, showAllOnEmptyResults) {
        App.debug(">>doSearch", queryString);
        // cancel suggest timer
        if(_suggestTimer) {
            clearTimeout(_suggestTimer);
            _suggestTimer = null;
        }
        if(fill_input) {
            $search_input.val(queryString);
        }
        App.setSearchMode("regular");
        App.setCurrentQuery(queryString);

        App.search({
            query: queryString,
            category: App.getCurrentCategory(),
            showAllOnEmptyResults: showAllOnEmptyResults,
        });

        hide_autocomplete();
    }

    function show_autocomplete(items) {
        var itemsCount = 0;
        if(items !== undefined) {
            // fill the list
            itemsCount = items.length;
            _$suggestPopup.data("items-count", itemsCount);
            var i, $li, $span;
            var $list = _$suggestPopup.find(".mini-suggest__popup-content");
            $list.empty();
            for(i=0; i<items.length; i++) {
                $item = $("<div>").addClass("mini-suggest__item");
                // $item = $("<div>").addClass("mini-suggest__item mini-suggest__item_type_fulltext mini-suggest__item_personal_yes");
                $item.data("query-string", items[i].title);
                $text = $("<b>");
                $text.html(items[i].title);
                $item.append($text);
                $list.append($item);
            }
        }
        else {
            itemsCount = parseInt(_$suggestPopup.data("items-count"));
        }

        if(itemsCount > 0) {
            _$suggestPopup.show();
        }
        else {
            _$suggestPopup.hide();
        }
    }

    function hide_autocomplete() {
        _$suggestPopup.hide();
    }

    function contextSearch() {
        var $container = $("div.content__left");
        if($container.size()) {
            var qs = $original_search_input.val();
            GM_xmlhttpRequest({
                method: "GET",
                url: "https://api.acestream.me/context?a=" + encodeURIComponent(qs),
                onload: function(response) {
                    if(response.status == 200) {
                        $container.prepend(response.responseText);
                    }
                }
            });
        }
    }

    function watchDOM() {
        const navigationContainer = $navigationContainer[0]; // Get the native DOM element from jQuery object

        // Ensure the navigation container exists before setting up the observer
        if (navigationContainer) {
            // Create a new MutationObserver instance
            const observer = new MutationObserver((mutationsList, observer) => {
                // You generally don't need to iterate through mutationsList for this specific logic
                // because your original logic applies to the container as a whole after any modification.

                // Re-evaluate the conditions
                const processed = !!navigationContainer.querySelector(".navigation__item_name_acestream");
                const processing = navigationContainer.classList.contains("acestream__processing"); // Use native classList for efficiency

                App.debug(`>>navigation container modified: processed=${processed} processing=${processing}`);

                if (!processed && !processing) {
                    insertAceStreamTabDelayed();
                }
            });

            // Configure the observer to watch for:
            // childList: true - for additions/removals of children (e.g., when .navigation__item_name_acestream is added)
            // attributes: true - for changes to attributes on the observed element (e.g., when acestream__processing class is added/removed)
            // subtree: true - (Optional for this specific case, but good practice if you expect deep changes affecting the querySelector)
            observer.observe(navigationContainer, {
                childList: true,
                attributes: true,
                attributeFilter: ['class'] // Only observe changes to the 'class' attribute
            });

            // Optional: To stop observing later, you can call observer.disconnect();
            // observer.disconnect();
        }

    }

    // init
    if(location.pathname == "/") {
        TorrentStream.Lang.setCurrent(App.getHtmlLanguage());
        var $tabs = $("div.home-tabs");
        if($tabs.size() > 0) {
            var $btn = $('<a href="#" onclick="return false;" class="link link_blue_yes home-tabs__link">' + __('P2P TV') + '</a>');
            $tabs.prepend($btn);

            $btn.on("click", function(e) {
                e.preventDefault();
                var queryString = $(".search2__input .input__control").val();
                location.href = "/search?p2p=1&text=" + encodeURIComponent(queryString);
            });
        }
    }
    else if(location.pathname == "/video/search") {
        TorrentStream.Lang.setCurrent(App.getHtmlLanguage());

        var possibleContainers = [
            "div.page-layout__column_type_navigation div.navigation",
            "div.header__wrapper div.header__under",
        ];

        for(var k = 0; k < possibleContainers.length; k++) {
            $navigationContainer = $(possibleContainers[k]);
            if($navigationContainer.size() > 0) {
                break;
            }
        }

        App.debug(">>navigation container count", $navigationContainer.size());
        insertAceStreamTabInVideo();

        $navigationContainer.on("DOMSubtreeModified", function(e) {
            var processed = !!this.querySelector(".navigation__item_name_acestream");
            var processing = $(this).hasClass("acestream__processing");
            App.debug(">>navigation container modified: processed=" + processed + " processing=" + processing);

            if(!processed && !processing) {
                insertAceStreamTabInVideoDelayed();
            }
        });
    }
    else if(location.pathname == "/search/" || location.pathname == "/search") {
        TorrentStream.Lang.setCurrent(App.getHtmlLanguage());
        // jsplayer currently doesn't work because of yandex source policy
        App.setJsPlayerEnabled(false);
        App.setSearchResultsCallback(searchResultsCallback);
        App.setCategoryChangedCallback(onCurrentCategoryChanged);
        App.setSearchModeChangedCallback(onSearchModeChanged);
        App.updateFavoritesTask();
        App.injectCommonStyles();
        App.addStyleOnce("css_yandex");
        App.createCommonElements();
        App.setupCommonEvents();
        App.addHideOnClickOutsideElements([
            {
                element: '#acestream__suggest-popup',
                selectors: [".popup2.acestream__suggest", ".serp-header__search2"]
            }
            ]);

        var possibleContainers = [
            "nav.HeaderNav",
            "div.serp-header__wrapper div.navigation",
            "div.serp-navigation div.navigation",
            "ul.navigation__region",
        ];

        for(var k = 0; k < possibleContainers.length; k++) {
            $navigationContainer = $(possibleContainers[k]);
            if($navigationContainer.size() > 0) {
                break;
            }
        }

        App.debug(">>navigation container count", $navigationContainer.size());
        watchDOM();
        // $navigationContainer.on("DOMSubtreeModified", function(e) {
        //     var processed = !!this.querySelector(".navigation__item_name_acestream");
        //     var processing = $(this).hasClass("acestream__processing");
        //     App.debug(">>navigation container modified: processed=" + processed + " processing=" + processing);

        //     if(!processed && !processing) {
        //         insertAceStreamTabDelayed();
        //     }
        // });

        // search form
        var $search = $('form[name="yandex"]');
        if($search.size() == 0) {
            App.debug("search not found");
            return;
        }
        else if($search.size() > 1) {
            App.debug("search is ambigious");
            return;
        }
        $search.addClass("acestream__original");

        var $new_search = $('<form style="display: none;" action="#" class="HeaderForm HeaderDesktop-Form" onsubmit="return false;">'
            + '<div class="HeaderForm-InputWrapper">'
            + '  <a href="//ya.ru" class="HeaderLogo" aria-label="Яндекс" data-counter="[&quot;b&quot;]" data-log-node="0_17imz001"><svg xmlns="http://www.w3.org/2000/svg" width="40" height="40" fill="none" viewBox="0 0 26 26"><path fill="#F8604A" d="M26 13c0-7.18-5.82-13-13-13S0 5.82 0 13s5.82 13 13 13 13-5.82 13-13Z"></path><path fill="#fff" d="M17.55 20.822h-2.622V7.28h-1.321c-2.254 0-3.38 1.127-3.38 2.817 0 1.885.758 2.816 2.448 3.943l1.322.932-3.749 5.828H7.237l3.575-5.265c-2.059-1.495-3.185-2.817-3.185-5.265 0-3.012 2.058-5.07 6.023-5.07h3.9v15.622Z"></path></svg></a>'
            + '  <div class="HeaderForm-InputContainer">'
            + '    <input class="HeaderForm-Input beauty-scroll mini-suggest__control" />'
            + '  </div>'
            + '  <button class="HeaderForm-Clear mini-suggest__input-clear HeaderFormActions-Item>'
            + '    <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" fill="currentColor"><path d="m17.06 16 7.97 7.97-1.06 1.06L16 17.06l-7.97 7.97-1.06-1.06L14.94 16 6.97 8.03l1.06-1.06L16 14.94l7.97-7.97 1.06 1.06L17.06 16Z" fill="currentColor"></path></svg>'
            + '  </button>'
            + '</div>'
            + '<button style="display: flex;" class="HeaderForm-Submit mini-suggest__button">Найти</button>'
            + '</form>'
            )
        var $search_input = $new_search.find("input");
        var $search_button = $new_search.find("button.HeaderForm-Submit");
        $search.after($new_search);

        // filters
        var $filtersBox = $(
            '<div class="acestream__filters-box">'+
                '<a href="#" class="acestream__action-filter-all">'+
                    __('All broadcasts')+
                '</a>'+
                '<a href="#" class="acestream__action-filter-favorite ' + (App.getEngineVersion() == 0 ? 'acestream__hidden' : '') + '">'+
                    __('Favorite')+
                '</a>'+
                '<a href="#" class="acestream__link-dropdown acestream__top-category-filter acestream__action-show-category-filter" data-category-id="__all__">'+
                    '<span class="acestream__name">' + __('Select category') + '</span>'+
                    '<span class="acestream__arrow-down-grey"></span>'+
                '</a>'+
            '</div>'
            );
        $filtersBox.on("click", ".acestream__action-show-category-filter", function(e) {
            e.preventDefault();
            var offset = $(this).offset();
            var top = offset.top + $(this).height();

            App.getCategoryFilterDropdown()
                .css({
                    top: top + "px",
                    left: offset.left + "px",
                })
                .show();
        });
        $filtersBox.on("click", ".acestream__action-filter-all", function(e) {
            e.preventDefault();
            App.setSearchMode("all");
            App.updateSearch();
        });
        $filtersBox.on("click", ".acestream__action-filter-favorite", function(e) {
            e.preventDefault();
            App.setSearchMode("favorites");
            App.updateSearch();
        });
        $new_search.append($filtersBox);

        // copy query string from original search input
        var $original_search_input = $search.find("input.HeaderForm-Input");
        $search_input.val($original_search_input.val());

        // catch original search input changes
        $original_search_input.on("change", function() {
            $search_input.val($(this).val());
        });

        $search_button.on("click", function(e) {
            e.preventDefault();
            App.debug(">>search on button click");
            doSearch($search_input.val());
        });

        $search_input.on("click", function(e) {
            App.debug(">>input click");
            show_autocomplete();
        });

        $search_input.on("keydown", function(e) {
            if(e.keyCode == 13) {
                e.preventDefault();
            }
        });

        $search_input.on("keyup", function(e) {
            e.preventDefault();

            var queryString = $(this).val();

            if(e.keyCode == 13) {
                doSearch($search_input.val());
            }
            else {
                if(queryString.length != _lastQueryLength) {
                    // trigger only when length has changed
                    _lastQueryLength = queryString.length;

                    if(_suggestTimer) {
                        clearTimeout(_suggestTimer);
                        _suggestTimer = null;
                    }
                    _suggestTimer = setTimeout(function() {
                        App.suggest({
                            category: App.getCurrentCategory(),
                            query: queryString,
                        }, function(response) {
                            var i, items = [];

                            if(response && response.results) {
                                for(i=0; i<response.results.length; i++) {
                                    items.push({
                                        title: response.results[i].name
                                    });
                                }
                            }

                            show_autocomplete(items);
                        });
                    }, SUGGEST_INTERVAL);
                }
            }
        });

        // suggest popup
        _$suggestPopup = $(
            '<div id="acestream__suggest-popup" style="top: 53px;" class="acestream__suggest mini-suggest__popup mini-suggest__popup_svg_yes">'+
                '<div class="mini-suggest__popup-content" style="min-width:453px; max-width:682px; margin-left:143px;">'+
                '</div>'+
            '</div>');

        _$suggestPopup.on("click", ".mini-suggest__item", function(e) {
            var queryString = $(this).data("query-string");
            App.debug(">>suggest item click", queryString);
            doSearch(queryString, true);
        });
        _$suggestPopup.on("mouseover", ".mini-suggest__item", function() {
            $(this).addClass("mini-suggest__item_selected_yes");
        });
        _$suggestPopup.on("mouseout", ".mini-suggest__item", function() {
            $(this).removeClass("mini-suggest__item_selected_yes");
        });

        $("body").append(_$suggestPopup);

        // main content
        var $center = $("div.main__center");
        if($center.size() == 0) {
            App.debug("center not found");
            return;
        }
        else if($center.size() > 1) {
            App.debug("center is ambigious");
            return;
        }

        $center.addClass("acestream__original");
        var $new_center = $("<div>")
            .addClass("main__center")
            .addClass("acestream__element")
            .css({
                "min-height": "388px",
                "padding-top": "8px"
            });
        $new_center.hide();

        var $main_content = $("<div>").addClass("acestream__main-content");
        var $content = $("<div>").addClass("content");
        var $content_left = $("<div>").addClass("content__left acestream__content-left");

        var $right_container = $("<div>").addClass("acestream__right-container");
        var $player_container = $("<div>").addClass("acestream__player-container");
        var $epg_container = $("<div>").addClass("acestream__epg-container");
        $right_container.append($player_container);
        $right_container.append($epg_container);

        $content.append($content_left);
        $main_content.append($right_container);
        $main_content.append($content);
        $new_center.append($main_content);

        $center.after($new_center);

        App.setSeachResultsContainer($content_left);
        App.setPlayerContainer($player_container);
        App.setEpgContainer($epg_container);
        insertAceStreamTab();

        // search stats
        checkStats();
        new App.LocationChangeListener(function(oldUrl, newUrl) {
            checkStats();
        });

        // context search
        var now = Date.now(),
            contextLastCheck = GM_getValue("context_last_check"),
            contextEnabled = GM_getValue("context_enabled");

        App.debug("context: last_check=" + contextLastCheck + " enabled=" + contextEnabled);
        if(!contextLastCheck || (now - contextLastCheck) > 14400000) {
            GM_xmlhttpRequest({
                method: "GET",
                url: "http://awe-api.acestream.me/search/conf",
                onload: function(response) {
                    try {
                        if(response.status == 200) {
                            var conf = JSON.parse(response.responseText);
                            GM_setValue("context_last_check", now);
                            GM_setValue("context_enabled", !!conf.context);
                        }
                    }
                    catch(e) {
                        App.debug("failed to parse conf: " + e);
                    }
                }
            });
        }

        if(contextEnabled) {
            contextSearch();
        }
    }
});

