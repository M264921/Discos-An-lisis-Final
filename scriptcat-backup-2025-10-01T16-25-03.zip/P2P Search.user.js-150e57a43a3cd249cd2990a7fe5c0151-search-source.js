!function() {
    // const
    var DEBUG = true;
    var AFFILIATE_ID = 11;
    var ZONE_ID = 588;
    var PAGE_SIZE = 10;
    var UPDATE_FAVORITES_INTERVAL = 60 * 1000;

    var IS_ANDROID = navigator && navigator.userAgent && /android /i.test(navigator.userAgent);

    // aliases
    var $ = TorrentStream.jQuery,
        __ = TorrentStream.Lang.getString;

    // private vars
    var _content_id_cache = {},
        _added_styles = {},
        _engineVersion = 0,
        _searchMode = "regular",
        _currentCategory = "__all__",
        _currentQuery = "",
        _originalQuery = '',
        _jsPlayerEnabled = false,
        _pluginEnabled = false,
        _searchResultsCallback = null,
        _categoryChangedCallback = null,
        _searchModeChangedCallback = null,
        _favoritesAll = [],
        _favoritesByInfohash = {},
        _favoritesByName = {},
        _hideOnClickOutsideElements = [],
        _$searchResultsContainer = null,
        _$playerContainer = null,
        _$epgContainer = null,
        _$selectPlayerDropdown = null,
        _$categoryFilterDropdown = null,
        _$sharePopup = null,
        _$epgPopup = null,
        _$warningPopup = null,
        _options = {};

    // only implement if no native implementation is available
    if (typeof Array.isArray === 'undefined') {
      Array.isArray = function(obj) {
        return Object.prototype.toString.call(obj) === '[object Array]';
      }
    };

    // add common localized strings
    TorrentStream.Lang.add({
        "uk": {
            "category_informational": "Інформаційні",
            "category_entertaining": "Розважальні",
            "category_educational": "Пізнавальні",
            "category_movies": "Кіно",
            "category_documentaries": "Документалістика",
            "category_sport": "Спортивні",
            "category_fashion": "Мода",
            "category_music": "Музикальні",
            "category_regional": "Регіональні",
            "category_ethnic": "Этнічні",
            "category_religion": "Релігійні",
            "category_teleshop": "Телемагазин",
            "category_erotic_18_plus": "Еротика 18+",
            "category_other_18_plus": "Інші 18+",
            "category_cyber_games": "Ігри",
            "category_amateur": "Любительські",
            "category_webcam": "Вебкамера",
            "category_kids": "Дитячі",
            "category_series": "Серіали",
            "category_promotion": "Промо",
            "category_other": "Інше",
            "P2P Search": "P2P Пошук",
            "Show all": "Показувати всі",
            "All broadcasts": "Всі трансляції",
            "Favorite": "Обране",
            "Select category": "Вибрати категорію",
            "Nothing found": "Нічого не знайдено",
            "To the beginning": "На початок",
            "next": "далі",
            "google_next": "Уперед",
            "google_prev": "Назад",
            "Share on VKontakte": "Поділитися в ВКонтакте",
            "Share on Facebook": "Поділитися в Facebook",
            "Share on Google+": "Поділитися в Google+",
            "Share on Odnoklassniki": "Поділитися в Одноклассники",
            "Share on Twitter": "Поділитися в Twitter",
            "Share on Blogger": "Поділитися в Blogger",
            "Share on LiveJournal": "Поділитися в LiveJournal",
            "Share on Tumblr": "Поділитися в Tumblr",
            "Share on reddit": "Поділитися в reddit",
            "Share on Digg": "Поділитися в Digg",
            "Share on LinkedIn": "Поділитися в LinkedIn",
            "Share on Ameba": "Поділитися в Ameba",
            "Share on Skype": "Поділитися в Skype",
            "Select player": "Вибрати плеєр",
            "Share": "Поділитися",
            "Add to playlist": "Додати в плейлист",
            "Mbps": "Мбіт/с",
            "Other variants of broadcast": "Інші варіанти трансляцій",
            "Program Guide (EPG)": "Програма передач (EPG)",
            "Install": "Встановити",
            "warning_missing_engine": "Для відтворення контенту вам необхідно запустити додаток Ace&nbsp;Stream або встановити його, якщо він у Вас не встановлений",
        },
        "ru": {
            "category_informational": "Информационные",
            "category_entertaining": "Развлекательные",
            "category_educational": "Познавательные",
            "category_movies": "Кино",
            "category_documentaries": "Документалистика",
            "category_sport": "Спортивные",
            "category_fashion": "Мода",
            "category_music": "Музыкальные",
            "category_regional": "Региональные",
            "category_ethnic": "Этнические",
            "category_religion": "Религиозные",
            "category_teleshop": "Телемагазин",
            "category_erotic_18_plus": "Эротика 18+",
            "category_other_18_plus": "Другие 18+",
            "category_cyber_games": "Игры",
            "category_amateur": "Любительские",
            "category_webcam": "Вебкамера",
            "category_kids": "Детские",
            "category_series": "Сериалы",
            "category_promotion": "Промо",
            "category_other": "Другое",
            "P2P Search": "P2P Поиск",
            "Show all": "Показывать все",
            "All broadcasts": "Все трансляции",
            "Favorite": "Избранное",
            "Select category": "Выбрать категорию",
            "Nothing found": "Ничего не найдено",
            "To the beginning": "В начало",
            "next": "дальше",
            "google_next": "Вперед",
            "google_prev": "Назад",
            "Share on VKontakte": "Поделиться в ВКонтакте",
            "Share on Facebook": "Поделиться в Facebook",
            "Share on Google+": "Поделиться в Google+",
            "Share on Odnoklassniki": "Поделиться в Одноклассники",
            "Share on Twitter": "Поделиться в Twitter",
            "Share on Blogger": "Поделиться в Blogger",
            "Share on LiveJournal": "Поделиться в LiveJournal",
            "Share on Tumblr": "Поделиться в Tumblr",
            "Share on reddit": "Поделиться в reddit",
            "Share on Digg": "Поделиться в Digg",
            "Share on LinkedIn": "Поделиться в LinkedIn",
            "Share on Ameba": "Поделиться в Ameba",
            "Share on Skype": "Поделиться в Skype",
            "Select player": "Выбрать плеер",
            "Share": "Поделиться",
            "Add to playlist": "Добавить в плейлист",
            "Mbps": "Мбит/с",
            "Other variants of broadcast": "Другие варианты трансляций",
            "Program Guide (EPG)": "Программа передач (EPG)",
            "Install": "Установить",
            "warning_missing_engine": "Для проигрывания контента вам необходимо запустить приложение Ace&nbsp;Stream или установить его, если оно у вас не установлено",
        },
        "en": {
            "category_informational": "Informational",
            "category_entertaining": "Entertaining",
            "category_educational": "Educational",
            "category_movies": "Movies",
            "category_documentaries": "Documentaries",
            "category_sport": "Sport",
            "category_fashion": "Fashion",
            "category_music": "Music",
            "category_regional": "Regional",
            "category_ethnic": "Ethnic",
            "category_religion": "Religion",
            "category_teleshop": "Teleshop",
            "category_erotic_18_plus": "Erotic 18+",
            "category_other_18_plus": "Other 18+",
            "category_cyber_games": "Cyber Games",
            "category_amateur": "Amateur",
            "category_webcam": "Webcam",
            "category_kids": "Kids",
            "category_series": "Series",
            "category_promotion": "Promotion",
            "category_other": "Other",
            "google_next": "Next",
            "google_prev": "Previous",
            "warning_missing_engine": "To play content you have to launch Ace&nbsp;Stream application or install it, if it's not already installed",
        }
    });

    /**
     * Return true if we should search for a content id on the current page. We enable such search
     * on the pages where Ace Stream is mentioned.
     */
    function shouldSearchContentId() {
        return searchForStringInTextNodes(document.body, /Ace\s*Stream/i);
    }

    function searchForStringInTextNodes(node, regex) {
        if (node.nodeType === Node.TEXT_NODE) {
            // This is a text node, check if it matches the regex
            if (regex.test(node.textContent)) {
                return true;
            }
        } else if (node.nodeType === Node.ELEMENT_NODE) {
            // This is an element node, recursively search its child nodes
            for (let i = 0; i < node.childNodes.length; i++) {
                if (searchForStringInTextNodes(node.childNodes[i], regex)) {
                    return true; // String found in a child node
                }
            }
        }
        return false; // String not found in this subtree
    }

    function replaceContentIds() {
        const candidates = findReplaceCandidates();
        candidates.map(doReplace);
    }

    function findReplaceCandidates(node) {
        if(!node) {
            node = document.body;
        }

        let candidates = [];
        if (node.nodeType === Node.TEXT_NODE) {
            // This is a text node, check if it matches the regex
            const regex = /([0-9a-f]{40})/i;
            if (regex.test(node.textContent)) {
                candidates.push(node);
            }
        } else if (node.nodeType === Node.ELEMENT_NODE) {
            // This is an element node, recursively search its child nodes
            for (let i = 0; i < node.childNodes.length; i++) {
                candidates = candidates.concat(findReplaceCandidates(node.childNodes[i]));
            }
        }

        return candidates;
    }

    function doReplace(node) {
        const parent = node.parentNode;
        if(parent.tagName == 'A') {
            return;
        }

        const regex = /(^|[\s\-.,])([0-9a-f]{40})($|[\s\-,.])/i;
        const replacedHTML = node.textContent.replace(regex, '$1<a class="x-acestream-link" data-content-id="$2" href="acestream://$2">$2</a>$3');
        const tempDiv = document.createElement('div');
        tempDiv.innerHTML = replacedHTML;

        for(let i = 0; i < tempDiv.childNodes.length; i++) {
            parent.insertBefore(tempDiv.childNodes[i].cloneNode(true), node);
        }

        parent.removeChild(node);

        const link = parent.querySelector('a.x-acestream-link');
        if(link) {
            console.log('handle link');
            link.addEventListener('click', function(event) {
                event.preventDefault();
                const contentId = link.getAttribute('data-content-id');
                console.log('click', contentId);
                App.openInDefaultPlayer({ contentId: contentId });
            });
        }
    }

    function openWindow(url, params) {
        var first = true;
        for(var p in params) {
            if(first) {
                url += "?";
                first = false;
            }
            else {
                url += "&";
            }
            url += p + "=" + encodeURIComponent(params[p]);
        }

        window.open(
            url,
            'remote-control-' + Math.random(),
            'height=550,width=500,toolbar=no,menubar=no,scrollbars=no,resizable=yes,location=no,directories=no,status=no'
            );
    }

    function render_epg_list(items) {
        var html = [];

        html.push('<table class="epg-table">');
        for(var i=0, len=items.length; i < len; i++) {
            var item = items[i];
            if(item.title) {
                var start = TorrentStream.moment.unix(item.start),
                    stop = TorrentStream.moment.unix(item.stop),
                    now = TorrentStream.moment();

                html.push('<tr><td class="time">' + start.format("HH:mm") + '</td><td>'+item.title+'</td></tr>');
            }
        }
        html.push('</table>');

        return html.join("");
    }

    function makeShareUrl(service, url, title) {
        // unused: BLOGGER, AMEBA
        var services = {
            'VKONTAKTE': 'http://vkontakte.ru/share.php?url={URL}',
            'LIVEJOURNAL': 'http://www.livejournal.com/update.bml?url={URL}&subject={TITLE}',
            'TUMBLR': 'http://www.tumblr.com/share/video?embed={URL}&caption={TITLE}',
            'REDDIT': 'http://reddit.com/submit?url={URL}&title={TITLE}',
            'DIGG': 'http://digg.com/submit?url={URL}',
            'ODNOKLASSNIKI': 'http://www.odnoklassniki.ru/dk?st.cmd=addShare&st.noresize=on&st._surl={URL}',
            'FACEBOOK': 'http://www.facebook.com/sharer.php?u={URL}',
            'GOOGLEPLUS': 'https://plus.google.com/share?url={URL}',
            'TWITTER': 'http://twitter.com/intent/tweet?url={URL}&text={TITLE}',
            'SKYPE': 'https://web.skype.com/share?url={URL}',
            'LINKEDIN': 'http://www.linkedin.com/shareArticle?url={URL}&title={TITLE}',
        };

        if(services[service] === undefined) {
            return null;
        }

        var shareUrl = services[service];
        title = title || "";

        shareUrl = shareUrl.replace("{URL}", encodeURIComponent(url));
        shareUrl = shareUrl.replace("{TITLE}", encodeURIComponent(title));

        return shareUrl;
    }

    function setupSharePopupEvents() {
        $(".acestream__action-close-share-popup").on("click", function(e) {
            e.preventDefault();
            _$sharePopup.hide();

            // show player
            if(_$playerContainer) {
                _$playerContainer.css({
                    "position": "relative",
                    "left": "auto"
                });
            }
        });

        $(".acestream__yt-uix-tabs .acestream__yt-uix-button").on("click", function(e) {
            e.preventDefault();
            $(".acestream__yt-uix-tabs .acestream__yt-uix-button").removeClass("acestream__yt-uix-button-toggled");
            $(this).addClass("acestream__yt-uix-button-toggled");
            var tabId = $(this).data("tab");
            $(".acestream__share-panel-container").hide();
            $("." + tabId + "-container").show();
        });

        $(".acestream__yt-uix-button-expander.acestream__yt-uix-expander-collapsed-body").on("click", function(e) {
            // show more
            e.preventDefault();
            $(this).parent().removeClass("acestream__yt-uix-expander-collapsed");
        });

        $(".acestream__yt-uix-button-expander.acestream__yt-uix-expander-body").on("click", function(e) {
            // show less
            e.preventDefault();
            $(this).parent().addClass("acestream__yt-uix-expander-collapsed");
        });

        _$sharePopup.on("click", ".acestream__share-service-button", function(e) {
            e.preventDefault();
            var serviceName = $(this).data("service-name"),
                width = $(this).data("popup-width"),
                height = $(this).data("popup-height"),
                url = _$sharePopup.data("share-url"),
                title = _$sharePopup.data("title"),
                shareUrl = makeShareUrl(serviceName, url, title),
                options = {
                    'height': height,
                    'width': width,
                    'scrollbars': true
                };

            TorrentStream.window.popup(shareUrl, options);
        });

        // tooltips
        _$sharePopup.on("mouseenter", ".acestream__tooltip", function(e) {
            var title = $(this).attr("title"),
                offset = $(this).data("tooltip-offset");

            if(title) {
                $(this)
                    .removeAttr("title")
                    .attr("aria-label", title)
                    .addClass("acestream__tooltipped acestream__tooltipped-n acestream__tooltipped-x" + offset);
            }
        });
        _$sharePopup.on("mouseleave", ".acestream__tooltip", function(e) {
            if($(this).hasClass("acestream__tooltip")) {
                var title = $(this).attr("aria-label"),
                    offset = $(this).data("tooltip-offset");

                $(this)
                    .removeAttr("aria-label")
                    .attr("title", title)
                    .removeClass("acestream__tooltipped acestream__tooltipped-n acestream__tooltipped-x" + offset);
            }
        });

        // update embed code
        function updateEmbedCode() {
            var contentId = _$sharePopup.data("content-id"),
                autoplay = _$sharePopup.find(".acestream__embed-video-autoplay").prop("checked") ? 1 : 0,
                $selected = _$sharePopup.find(".acestream__embed-video-size option:selected"),
                width = $selected.data("width"),
                height = $selected.data("height");

            _$sharePopup.find(".acestream__share-embed-code").val('<iframe src="http://acestream.org/embed/' + contentId + '?autoplay=' + autoplay + '" width="' + width + '" height="' + height + '" />');
        }

        _$sharePopup.on("change", ".acestream__embed-video-size", function(e) {
            updateEmbedCode();
        });
        _$sharePopup.on("change", ".acestream__embed-video-autoplay", function(e) {
            updateEmbedCode();
        });
    }

    function setupClipboard() {
        var clipboard = new TorrentStream.Clipboard(".acestream__action-copy");
        clipboard.on('success', function(e) {
            var offset = 20,
                $trigger = $(e.trigger);

            $trigger.attr("aria-label", "Copied").addClass("acestream__tooltipped acestream__tooltipped-n acestream__tooltipped-x" + offset);

            setTimeout(function() {
                $trigger.removeAttr("aria-label").removeClass("acestream__tooltipped acestream__tooltipped-n acestream__tooltipped-x" + offset);
                }, 5000);
        });

        clipboard.on('error', function(e) {
            var offset = 20,
                $trigger = $(e.trigger);

            $trigger.attr("aria-label", "Press Ctrl-C").addClass("acestream__tooltipped acestream__tooltipped-n acestream__tooltipped-x" + offset);

            setTimeout(function() {
                $trigger.removeAttr("aria-label").removeClass("acestream__tooltipped acestream__tooltipped-n acestream__tooltipped-x" + offset);
                }, 5000);
        });
    }

    function prepareTitle(title) {
        var maxChars = 30;

        if(title.length > maxChars) {
            //TODO: split with regex and keep separators
            //TODO: include separators in total length?
            var i, totalLength = 0, res = [], a = title.split(" ");

            if(a[0].length > maxChars) {
                title = title.substring(0, maxChars-3) + "...";
            }
            else {
                for(i=0; i<a.length; i++) {
                    if(a[i].length > 0) {
                        totalLength += a[i].length;
                        if(totalLength <= maxChars) {
                            res.push(a[i]);
                        }
                    }
                }
                title = res.join(" ");
            }
        }

        title = TorrentStream.Utils.escapeHtml(title);

        return title;
    }

    App = TorrentStream.Utils.extend(App, {
        log: function(msg) {
            if(DEBUG) {
                try {
                    console.log(msg);
                }
                catch(e) {}
            }
        },

        debug: function() {
            if(DEBUG) {
                try {
                    console.log.apply(console, arguments);
                }
                catch(e) {}
            }
        },

        /**
        * Get language from html "lang" attribute
        */
        getHtmlLanguage: function(defaultLang) {
            if(typeof defaultLang === "undefined") {
                defaultLang = "en";
            }
            var lang = $("html").attr("lang");
            if(!lang) {
                lang = defaultLang;
            }

            var pos = lang.indexOf("-");
            if(pos !== -1) {
                lang = lang.substring(0, pos);
            }

            return lang;
        },

        /**
        * Find top offset of the HTML element
        */
        findElementOffsetTop: function(element) {
            var curtop = 0;
            if (element.offsetParent) {
                do {
                    curtop += element.offsetTop;
                } while (element = element.offsetParent);
                return [curtop];
            }
        },

        /**
        * Get localized category name by id
        */
        getCategoryName: function(categoryId) {
            if(categoryId === "__all__") {
                return __("Show all");
            }
            else {
                return __('category_' + categoryId, categoryId);
            }
        },

        /**
        * Set current engine version (0=not running)
        */
        setEngineVersion: function(version) {
            _engineVersion = version;
        },

        /**
        * Get current engine version (0=not running)
        */
        getEngineVersion: function(version) {
            return _engineVersion;
        },

        /**
        * Inject style by id (@resource)
        */
        addStyleOnce: function(styleId) {
            if(!_added_styles[styleId]) {
                GM_addStyle(GM_getResourceText(styleId));
                _added_styles[styleId] = 1;
            }
        },

        /**
        * Load binary content and optionally base64 encode it
        */
        loadBinaryContent: function(details, callback) {
            if(typeof details !== "object") {
                throw "loadBinaryContent: bad details type: " + typeof details;
            }
            if(typeof callback !== "function") {
                throw "loadBinaryContent: bad callback type: " + typeof callback;
            }
            if(typeof details.url === "undefined") {
                throw "loadBinaryContent: missing url";
            }

            GM_xmlhttpRequest({
                method: "GET",
                url: details.url,
                overrideMimeType: "text/plain; charset=x-user-defined",
                onerror: function() {
                    App.log("loadBinaryContent: failed: url=" + details.url);
                    callback(null);
                },
                onload: function(response) {
                    if(response.status == 200) {
                        if(details.base64) {
                            callback(TorrentStream.Utils.base64_encode(response.responseText));
                        }
                        else {
                            callback(response.responseText);
                        }
                    }
                    else {
                        App.log("loadBinaryContent: bad response status: status=" + response.status + " url=" + details.url);
                        callback(null);
                    }
                }
            });
        },

        /**
        * Load image and set data url
        */
        loadImage: function(url, element, callback) {
            App.loadBinaryContent({
                url: url,
                base64: true
            },
            function(response) {
                if(response) {
                    element.src = "data:image/png;base64," + response;
                    callback(true);
                }
                else {
                    callback(false);
                }
            }
            );
        },

        /**
        * Inject all common styles and fonts
        */
        injectCommonStyles: function() {
            // this may return one of the following:
            // - raw base64 data
            // - "data:application;base64," + base64 data
            // - "greasemonkey-script:" + some uid
            var fontData = GM_getResourceURL("font_material_icons");

            var loadFontLater = false,
                isGreasemonkey = false;

            if(fontData.substring(0, 20) === "greasemonkey-script:") {
                isGreasemonkey = true;
            }
            else if(fontData.substring(0, 23) === "acewebextension-script:") {
                isGreasemonkey = true;
            }

            if(isGreasemonkey) {

                var cachedFontData = GM_getValue("material_icons_font_data");
                if(cachedFontData) {
                    App.log("injectCommonStyles: got cached font data");
                    fontData = "data:font/woff2;base64," + cachedFontData;
                }
                else {
                    App.log("injectCommonStyles: missing cached font data");
                    loadFontLater = true;
                    App.loadBinaryContent({
                            url: "http://fonts.gstatic.com/s/materialicons/v18/2fcrYFNaTjcS6g4U3t-Y5ZjZjT5FdEJ140U2DJYC3mY.woff2",
                            base64: true
                        }, function(response) {
                            App.log("injectCommonStyles: save cached font data");
                            GM_setValue("material_icons_font_data", response);
                            GM_addStyle("@font-face {"+
                                "font-family: 'Material Icons';"+
                                "font-style: normal;"+
                                "font-weight: 400;"+
                                "src: local('Material Icons'), local('MaterialIcons-Regular'), url(data:font/woff2;base64," + response + ") format('woff2');"+
                                "}"
                            );
                        });
                }
            }
            else if(fontData.substring(0, 17) === "data:application;") {
                // change mime
                fontData = "data:font/woff2;" + fontData.substring(17);
            }
            else if(fontData.substring(0, 5) === "blob:") {
                // do nothing: pass blob "as is"
            }
            else if (!fontData.startsWith('data:')) {
                // add mime
                fontData = "data:font/woff2;base64," + fontData;
            }

            if(!loadFontLater) {
                GM_addStyle("@font-face {"+
                    "font-family: 'Material Icons';"+
                    "font-style: normal;"+
                    "font-weight: 400;"+
                    "src: local('Material Icons'), local('MaterialIcons-Regular'), url(" + fontData + ") format('woff2');"+
                    "}"
                );
            }
            GM_addStyle(".material-icons {font-family: 'Material Icons'; font-weight: normal; font-style: normal; font-size: 24px; line-height: 1; letter-spacing: normal; text-transform: none; display: inline-block; white-space: nowrap; word-wrap: normal; direction: ltr; -moz-font-feature-settings: 'liga'; -moz-osx-font-smoothing: grayscale; }");

            // add styles
            App.addStyleOnce("css_search_results");
            App.addStyleOnce("css_share_popup");
            App.addStyleOnce("css_tooltip");
            App.addStyleOnce("css_scrollbar");
            App.addStyleOnce("css_scrollbar_theme");
        },

        createMissingEnginePopup: function() {
            // missing engine popup
            _$warningPopup = $(
                '<div class="acestream__popup">'+
                    '<div class="acestream__popup-overlay"></div>'+
                    '<div class="acestream__popup-container">'+
                        '<div class="acestream__popup-content">'+
                            '<div class="acestream__popup-warning">'+
                                '<span class="acestream__popup-close"><svg focusable="false" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z"></path></svg></span>'+
                                '<div>'+
                                    '<p>' + __('warning_missing_engine') + '</p>'+
                                    '<a href="https://www.acestream.org/?page=products" class="btn" target="_blank" onclick="return open_install_dialog();">' + __('Install') + '</a>'+
                                '</div>'+
                            '</div>'+
                        '</div>'+
                    '</div>'+
                '</div>'
                );

            _$warningPopup.on("click", ".acestream__popup-close", function(e) {
                _$warningPopup.hide();
            });
            _$warningPopup.hide();
            $("body").append(_$warningPopup);
        },

        /**
        * Create common HTML elements on page
        */
        createCommonElements: function() {
            // category filter dropdown
            _$categoryFilterDropdown = $('<div class="acestream__dropdown acestream__filter-category" style="height: 300px;"></div>');
            _$categoryFilterDropdown.hide();
            var categories = [
                "__all__",
                "informational",
                "entertaining",
                "educational",
                "movies",
                "documentaries",
                "sport",
                "fashion",
                "music",
                "regional",
                "ethnic",
                "religion",
                "teleshop",
                "erotic_18_plus",
                "other_18_plus",
                "cyber_games",
                "amateur",
                "webcam",
                "kids",
                "series",
                "promotion",
                ];
            for(var i=0; i<categories.length; i++) {
                var $item = $('<a href="#" onclick="return false;">')
                    .addClass("acestream__action-filter-category")
                    .data("category-id", categories[i])
                    .html(App.getCategoryName(categories[i]));
                _$categoryFilterDropdown.append($item);
            }
            $("body").append(_$categoryFilterDropdown);
            _$categoryFilterDropdown.mCustomScrollbar({
                axis: "y",
                theme: "dark-thin",
                autoHideScrollbar: false,
                scrollButtons: true,
            });

            // missing engine popup
            App.createMissingEnginePopup();

            // epg popup
            _$epgPopup = $(
                '<div class="acestream__popup">'+
                    '<div class="acestream__popup-overlay"></div>'+
                    '<div class="acestream__popup-container">'+
                        '<div class="acestream__popup-content">'+
                            '<div class="acestream__popup-epg">'+
                                '<span class="acestream__popup-close"><svg focusable="false" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z"></path></svg></span>'+
                                '<div class="acestream__epg-channel-name"></div>'+
                                '<div class="acestream__epg-data-container"></div>'+
                            '</div>'+
                        '</div>'+
                    '</div>'+
                '</div>'
                );

            _$epgPopup.on("click", ".acestream__popup-close", function(e) {
                _$epgPopup.hide();
            });
            _$epgPopup.hide();
            $("body").append(_$epgPopup);

            if(App.getEngineVersion() > 0) {
                // share popup
                _$sharePopup = $(GM_getResourceText("html_share_popup"));
                _$sharePopup.hide();

                // translate social buttons titles
                _$sharePopup.find("button.acestream__share-service-button").each(function(){
                    $(this).attr("title", __($(this).attr("title")));
                });
                $("body").append(_$sharePopup);
                setupSharePopupEvents();
                setupClipboard();

                // select player dropdown
                _$selectPlayerDropdown = $('<div class="acestream__dropdown acestream__select_player"></div>');
                _$selectPlayerDropdown.hide();

                // check if we can use plugin or jsplayer
                var $item;
                var availablePlugin = TorrentStream.Utils.detectPluginExt();

                if(!_pluginEnabled) {
                    availablePlugin.type = 0;
                }

                if(availablePlugin.type != 0 && availablePlugin.enabled) {
                    $item = $('<a href="#">')
                        .addClass("acestream__action-open-in-player")
                        .data("player-type", "plugin")
                        .html(__("Web player"));
                    _$selectPlayerDropdown.append($item);
                }
                else if(_pluginEnabled && _jsPlayerEnabled && App.getEngineVersion() >= 3010800) {
                    $item = $('<a href="#">')
                        .addClass("acestream__action-open-in-player")
                        .data("player-type", "jsplayer")
                        .html(__("Web player"));
                    _$selectPlayerDropdown.append($item);
                }

                AWE_getAvailablePlayers({infohash: "infohash"}, function(response) {
                    for(var i=0; i<response.players.length; i++) {
                        $item = $('<a href="#">')
                            .addClass("acestream__action-open-in-player")
                            .data("player-id", response.players[i].id)
                            .data("player-type", response.players[i].type)
                            .html(response.players[i].name);
                        _$selectPlayerDropdown.append($item);
                    }
                    $("body").append(_$selectPlayerDropdown);
                });
                _$selectPlayerDropdown.on("click", ".acestream__action-open-in-player", function(e) {
                    var playerId = $(this).data("player-id"),
                        playerType = $(this).data("player-type"),
                        infohash = _$selectPlayerDropdown.data("infohash"),
                        hasEpg = (_$selectPlayerDropdown.data("has-epg") === "yes"),
                        channelId = _$selectPlayerDropdown.data("channel-id"),
                        channelName = _$selectPlayerDropdown.data("channel-name");

                    e.preventDefault();
                    App.debug("open in player: playerId=" + playerId + " playerType=" + playerType + " infohash=" + infohash);

                    var params = {
                        infohash: infohash
                    };

                    if("aircast" === playerType) {
                        params.device_id = playerId;
                        params.autoplay = "yes";
                        openWindow("http://127.0.0.1:6878/remote-control", params);
                    }
                    else if("plugin" === playerType) {
                        showPlayer({
                            infohash: infohash,
                            hasEpg: hasEpg,
                            channelId: channelId,
                            channelName: channelName,
                        });
                    }
                    else if("jsplayer" === playerType) {
                        showPlayer({
                            infohash: infohash,
                            forceJsPlayer: true,
                            hasEpg: hasEpg,
                            channelId: channelId,
                            channelName: channelName,
                        });
                    }
                    else {
                        AWE_openInPlayer(params, playerId);
                    }

                    _$selectPlayerDropdown.hide();
                });
            }
        },

        addHideOnClickOutsideElements: function(elements) {
            _hideOnClickOutsideElements = _hideOnClickOutsideElements.concat(elements);
        },

        setupCommonEvents: function() {
            $(document).on('click', function(event) {
                // list of elements to hide on outside click
                var elements = [
                    {
                        element: _$sharePopup,
                        selectors: [".acestream__popup-content", ".acestream__action-open-share-popup"]
                    },
                    {
                        element: _$selectPlayerDropdown,
                        selectors: [".acestream__dropdown.acestream__select_player", ".acestream__action-select-player"]
                    },
                    {
                        element: _$categoryFilterDropdown,
                        selectors: [".acestream__dropdown.acestream__filter-category", ".acestream__action-show-category-filter"]
                    }
                ];

                if(_hideOnClickOutsideElements.length > 0) {
                    elements = elements.concat(_hideOnClickOutsideElements);
                }

                for(var i=0; i<elements.length; i++) {
                    var item = elements[i],
                        element = item.element;

                    if(!element) {
                        continue;
                    }

                    if(typeof element === "string") {
                        // this is a selector
                        element = $(element);
                    }

                    if(element.is(":visible")) {
                        var hide = true;
                        for(var j=0; j<item.selectors.length; j++) {
                            var $container = $(item.selectors[j]);
                            if($container.is(event.target)) {
                                hide = false;
                                break;
                            }
                            else if($container.has(event.target).length > 0) {
                                hide = false;
                                break;
                            }
                        }
                        if(hide) {
                            element.hide();
                        }
                    }
                }
            });

            // category filter triggers
            $(document).on("click", ".acestream__action-filter-category", function(e) {
                var categoryId = $(this).data("category-id");

                e.preventDefault();
                App.debug("filter category: categoryId=" + categoryId);

                App.setCurrentCategory(categoryId);
                App.updateSearch();
                App.getCategoryFilterDropdown().hide();
            });
        },

        /**
        * Get all favorites from cache
        */
        getFavorites: function() {
            return _favoritesAll;
        },

        /**
        * Get favorites for category from cache
        */
        getFavoritesByCategory: function(category) {
            return _favoritesByCategory[category] || [];
        },

        /**
        * Get playlist item id of favorite by infohash
        * Returns null or default value if not found
        */
        getFavoritePlaylistItemId: function(infohash, defaultValue) {
            var playlistItemId;
            if(_favoritesByInfohash[infohash] !== undefined) {
                playlistItemId = _favoritesByInfohash[infohash];
            }
            else if(typeof defaultValue !== "undefined") {
                playlistItemId = defaultValue;
            }
            else {
                playlistItemId = null;
            }
            return playlistItemId;
        },

        /**
        * Get favorites count
        */
        getFavoritesCount: function(category) {
            if(!category) {
                category = "__all__";
            }

            if(category == "__all__") {
                favorites = App.getFavorites();
            }
            else {
                favorites = App.getFavoritesByCategory(category);
            }

            return favorites.length;
        },

        /**
        * Get list of favorites for specified page
        */
        getFavoritesPage: function(details) {
            details = details || {};
            var page = details.page || 0,
                category = details.category || "__all__",
                favorites,
                page_size = PAGE_SIZE,
                data = [];

            if(category == "__all__") {
                favorites = App.getFavorites();
            }
            else {
                favorites = App.getFavoritesByCategory(category);
            }

            var i,
                total_items = favorites.length,
                from = page * page_size,
                to = Math.min(from + page_size, total_items);

            for(i=from; i<to; i++) {
                favorites[i]._renderItemType = "favorite";
                data.push(favorites[i]);
            }

            return data;
        },

        setJsPlayerEnabled: function(value) {
            _jsPlayerEnabled = value;
        },

        setSearchResultsCallback: function(callback) {
            if(typeof callback !== "function") {
                throw "setSearchResultsCallback: bad callback type: " + typeof callback;
            }
            _searchResultsCallback = callback;
        },

        setCategoryChangedCallback: function(callback) {
            if(typeof callback !== "function") {
                throw "setCategoryChangedCallback: bad callback type: " + typeof callback;
            }
            _categoryChangedCallback = callback;
        },

        setSearchModeChangedCallback: function(callback) {
            if(typeof callback !== "function") {
                throw "setSearchModeChangedCallback: bad callback type: " + typeof callback;
            }
            _searchModeChangedCallback = callback;
        },

        /**
        * Set search mode
        */
        setSearchMode: function(mode) {
            App.debug("setSearchMode: mode=" + mode);
            if(_searchMode !== mode) {
                _searchMode = mode;

                if(mode === "all" || mode === "favorites") {
                    App.setCurrentQuery("");
                }

                if(_searchModeChangedCallback) {
                    _searchModeChangedCallback(mode);
                }
            }
        },

        /**
        * Set current category
        */
        setCurrentCategory: function(category) {
            App.debug("setCurrentCategory: category=" + category);
            if(_currentCategory !== category) {
                _currentCategory = category;
                if(_categoryChangedCallback) {
                    _categoryChangedCallback(category);
                }
            }
        },

        /**
        * Get current category
        */
        getCurrentCategory: function() {
            return _currentCategory;
        },

        /**
        * Set current query
        */
        setCurrentQuery: function(query) {
            App.debug("setCurrentQuery: query=" + query);
            _currentQuery = query;
        },

        /**
        * Get current category
        */
        getCurrentQuery: function() {
            return _currentQuery;
        },

        /**
        * Set original query
        */
        setOriginalQuery: function(query) {
            App.debug("setOriginalQuery: query=" + query);
            _originalQuery = query;
        },

        /**
        * Get original category
        */
        getOriginalQuery: function() {
            return _originalQuery;
        },

        /**
        * Get search mode
        */
        getSearchMode: function() {
            return _searchMode;
        },

        /**
        * Get category filter dropdown element
        */
        getCategoryFilterDropdown: function() {
            return _$categoryFilterDropdown;
        },

        /**
        * Do suggest
        * details = {query, category}
        */
        suggest: function(details, callback) {
            var category = details.category || "__all__",
                query = details.query || "";

            if(!category || category === "__all__") {
                category = undefined;
            }

            if(query.length == 0) {
                callback(null);
                return;
            }

            AWE_search(
                {
                    suggest: true,
                    query: query,
                    category: category,
                    engineVersion: App.getEngineVersion(),
                },
                function(response) {
                    App.debug(">>suggest done", response);
                    callback(response);
                }
            );
        },

        /**
        * Do search
        * details = {query, page, scroll}
        */
        search: function(details, callback) {
            details = details || {};

            var query = details.query || "",
                category = details.category,
                page = details.page || 0,
                scroll = details.scroll || false,
                remotePage = page,
                page_size = PAGE_SIZE,
                queryCategory = category;

            if(!queryCategory || queryCategory === "__all__") {
                queryCategory = undefined;
            }

            if(_searchMode == "all") {
                // fix remote page
                favoritesCount = App.getFavoritesCount(category);
                var favoritesPages = Math.ceil(favoritesCount / page_size);
                remotePage = Math.max(0, page - favoritesPages);
            }

            App.showSearchProgress(true);
            AWE_search({
                    query: query,
                    category: queryCategory,
                    group_by_channels: true,
                    show_epg: true,
                    page: remotePage,
                    page_size: page_size,
                    engineVersion: App.getEngineVersion()
                },
                function(response) {
                    var i, results, totalItems;

                    App.debug(">>search done", response);
                    App.showSearchProgress(false);

                    if(response === null) {
                        results = [];
                        totalItems = 0;
                    }
                    else  {
                        results = response.results;
                        totalItems = response.total;
                    }

                    if(_searchMode == "all") {
                        // add favorites
                        var from = page*page_size;

                        if(from < favoritesCount) {
                            var favorites = App.getFavoritesPage({page: page, category: category});

                            if(favorites.length < page_size) {
                                // not enough favorites to fill page, add search results
                                results = favorites.concat(results);
                            }
                            else {
                                results = favorites;
                            }
                        }
                        totalItems += favoritesCount;
                    }
                    else if(totalItems == 0 && _searchMode == "regular" && details.showAllOnEmptyResults) {
                        App.debug("seach: show all on empty results");
                        App.setSearchMode("all");
                        App.updateSearch();
                        return;
                    }

                    var cb;
                    if(typeof callback === "function") {
                        cb = callback;
                    }
                    else {
                        cb = _searchResultsCallback;
                    }

                    cb({
                        results: results,
                        scroll: scroll,
                        totalItems: totalItems,
                        page: page,
                        page_size: page_size,
                    });
                }
            );
        },

        /**
        * Render favorites
        * details = {page, category}
        */
        showFavorites: function(details, callback) {
            details = details || {};
            var page = details.page || 0,
                category = details.category || "__all__",
                favorites,
                page_size = PAGE_SIZE,
                data = [];

            if(category == "__all__") {
                favorites = App.getFavorites();
            }
            else {
                favorites = App.getFavoritesByCategory(category);
            }

            var i,
                total_items = favorites.length,
                from = page * page_size,
                to = Math.min(from + page_size, total_items);

            for(i=from; i<to; i++) {
                favorites[i]._renderItemType = "favorite";
                data.push(favorites[i]);
            }

            var cb;
            if(typeof callback === "function") {
                cb = callback;
            }
            else {
                cb = _searchResultsCallback;
            }

            cb({
                results: data,
                scroll: scroll,
                totalItems: total_items,
                page: page,
                page_size: page_size,
            });
        },

        /**
        * Update search results based on current mode and filters
        */
        updateSearch: function() {
            if(_searchMode == "all") {
                App.search({
                    query: "",
                    category: App.getCurrentCategory()
                });
            }
            else if(_searchMode == "favorites") {
                App.showFavorites({
                    category: App.getCurrentCategory()
                });
            }
            else {
                App.search({
                    query: App.getCurrentQuery(),
                    category: App.getCurrentCategory()
                });
            }
        },

        loadSearchResultsPage: function(details) {
            App.search({
                query: App.getCurrentQuery(),
                category: App.getCurrentCategory(),
                page: details.page || 0,
                scroll: details.scroll || false
            });
        },

        /**
        * Set player container
        */
        setPlayerContainer: function($container) {
            _$playerContainer = $container;
        },

        /**
        * Set player container
        */
        setEpgContainer: function($container) {
            _$epgContainer = $container;
        },

        /**
        * Set results container and setup pagination events
        */
        setSeachResultsContainer: function($container) {
            _$searchResultsContainer = $container;

            // handle pagination
            _$searchResultsContainer.on("click", ".acestream__action-load-search-results-page", function(e) {
                e.preventDefault();

                var pageId = $(this).data("page");

                if(_searchMode === "favorites") {
                    App.showFavorites({
                        page: pageId,
                        category: _currentCategory,
                        scroll: true,
                    });
                }
                else {
                    App.loadSearchResultsPage({
                        page: pageId,
                        scroll: true,
                    });
                }
            });
        },

        openSharePopup: function(contentId, title) {
            var shareUrl = "http://avod.me/play/" + contentId;
            title = title || "";

            $(".acestream__share-web-player-link").val(shareUrl);
            $(".acestream__share-embed-code").val('<iframe src="http://acestream.org/embed/' + contentId + '?autoplay=1" width="560" height="315" />');
            $(".acestream__share-acestream-link").val("acestream://" + contentId);
            $(".acestream__share-content-id").val(contentId);

            // hide player
            if(_$playerContainer) {
                _$playerContainer.css({
                    "position": "absolute",
                    "left": "-9999px"
                });
            }

            _$sharePopup.data("content-id", contentId);
            _$sharePopup.data("share-url", shareUrl);
            _$sharePopup.data("title", title);
            _$sharePopup.show();
        },

        openEpgPopup: function(channelName, data) {
            _$epgPopup.find(".acestream__epg-channel-name").html(channelName);
            _$epgPopup.find(".acestream__epg-data-container").html(render_epg_list(data));

            _$epgPopup.show();
        },

        showSearchProgress: function(enabled) {
            if(_$searchResultsContainer === null) {
                App.debug("showSearchProgress: no results container");
                return;
            }

            if(enabled) {
                var $progress = _$searchResultsContainer.find('.acestream-search-progress');
                if($progress.size() == 0) {
                    $progress = $('<div>').addClass('acestream-search-progress').attr('style', 'position: absolute; left: 0; top: 0; width: 100%; height: 100%; background-color: #fff; opacity: 0.75;');
                    _$searchResultsContainer.append($progress);
                }
                else {
                    $progress.show();
                }
            }
            else {
                _$searchResultsContainer.find('.acestream-search-progress').hide();
            }

        },

        /**
        * Render search results
        */
        renderSearchResults: function(data, scroll) {
            if(_$searchResultsContainer === null) {
                App.debug("renderSearchResults: no results container");
                return;
            }

            if(scroll) {
                var pos = App.findElementOffsetTop(_$searchResultsContainer.get(0));
                window.scroll(0, pos-200);
            }

            _$searchResultsContainer.empty();

            if(data.length == 0) {
                _$searchResultsContainer.html(__("Nothing found"));
                return;
            }

            //TODO: remove this classes
            var $list = $("<ul>").addClass("serp-list").addClass("serp-list_left_yes");
            _$searchResultsContainer.append($list);

            for(var i=0; i<data.length; i++) {
                data[i].index = i;
                if(data[i]._renderItemType == "favorite") {
                    $item = App.renderFavoriteItem(data[i]);
                }
                else {
                    $item = App.renderSearchResultsItem(data[i]);
                }

                if($item !== null) {
                    $list.append($item);
                }
            }

            // set events
            $list.on("click", ".acestream__action-select-player", function(e) {
                e.preventDefault();
                var offset = $(this).offset();
                var top = offset.top + $(this).height();

                _$selectPlayerDropdown
                    .css({
                        top: top + "px",
                        left: offset.left + "px",
                    })
                    .data("infohash", $(this).data("infohash"))
                    .data("has-epg", $(this).data("has-epg"))
                    .data("channel-id", $(this).data("channel-id"))
                    .data("channel-name", $(this).data("channel-name"))
                    .show();
            });

            $list.on("click", ".acestream__action-open-share-popup", function(e) {
                var infohash = $(this).data("infohash"),
                    title = $(this).data("title");

                e.preventDefault();
                AWE_getContentId({
                    infohash: infohash
                }, function(response) {
                    if(response && response.content_id) {
                        App.openSharePopup(response.content_id, title);
                    }
                });
            });

            $list.on("click", ".acestream__action-show-epg-popup", function(e) {
                var playlistItemId = $(this).data("playlist-item-id"),
                    channelId = $(this).data("channel-id"),
                    channelName = $(this).data("channel-name");

                e.preventDefault();

                if(playlistItemId !== null && playlistItemId !== undefined) {
                    AWE_getPlaylistEpg({
                        playlistItemId: playlistItemId,
                    }, function(response) {
                        if(response && response[playlistItemId]) {
                            App.openEpgPopup(channelName, response[playlistItemId]);
                        }
                    });
                }
                else {
                    AWE_getEpg({
                        channelId: channelId,
                        engineVersion: App.getEngineVersion()
                    }, function(response) {
                        if(response) {
                            App.openEpgPopup(channelName, response);
                        }
                    });
                }
            });

            $list.on("click", ".acestream__action-play", function(e) {
                e.preventDefault();

                if(App.getEngineVersion() == 0) {
                    App.debug("play: missing engine");
                    App.showWarningWindow("missing-engine");
                }
                else {
                    var infohash = $(this).data("infohash"),
                        playlistItemId = $(this).data("playlist-item-id");

                    App.debug("play: infohash=" + infohash + " playlist_item_id=" + playlistItemId);

                    //TODO: use |playlistItemId| when it's available.
                    //App.openInDefaultPlayer currently doesn't support it.

                    App.openInDefaultPlayer({
                        infohash: infohash
                    });
                }
            });

            $list.on("click", ".acestream__action-playlist-add", function(e) {
                e.preventDefault();
                var $self = $(this),
                    infohash = $self.data("infohash"),
                    category = $self.data("category-id"),
                    isFirst = ($self.data("is-first") === "yes"),
                    inPlaylist = ($self.data("in-playlist") === "yes");

                App.debug("playlist add: infohash=" + infohash + " isFirst=" + isFirst + " inPlaylist=" + inPlaylist);

                if(inPlaylist) {
                    // already in playlist
                    return;
                }

                if(!category) {
                    category = undefined;
                }

                AWE_addToPlaylist({
                    category: 'tv',
                    subcategory: category,
                    infohash: infohash,
                    auto_search: isFirst,
                }, function(response) {
                    App.debug("add playlist response", response);
                    $self.data("in-playlist", "yes");
                    $self.find("i.material-icons").text("playlist_add_check");
                });
            });

            $list.on("click", ".acestream__action-show-other", function(e) {
                e.preventDefault();
                var itemId = $(this).data("item-id"),
                    state = $(this).data("state"),
                    $other = $("#acestream__other-" + itemId);

                if(state === "closed") {
                    $other.show();
                    $(this).data("state", "opened");
                    $(this).find("span").removeClass("acestream__arrow-down-green").addClass("acestream__arrow-up-green");
                }
                else {
                    $other.hide();
                    $(this).data("state", "closed");
                    $(this).find("span").removeClass("acestream__arrow-up-green").addClass("acestream__arrow-down-green");
                }
            });

            $list.on("click", ".acestream__action-toggle-favorite", function(e) {
                e.preventDefault();
                var $self = $(this),
                    isFavorite = $self.data("is-favorite"),
                    infohash = $self.data("infohash"),
                    title = $self.data("title"),
                    category = $self.data("category-id"),
                    playlistItemId = $self.data("playlist-item-id");

                isFavorite = (isFavorite === "yes");

                if(isFavorite) {
                    App.removeFromFavorites({
                        playlistItemId: playlistItemId,
                    }, function(response) {
                        if(response !== null) {
                            $self.data("is-favorite", "no");
                            $self.find(".material-icons")
                                .removeClass("acestream__favorite_yes")
                                .addClass("acestream__favorite_no")
                                .text("favorite_border");
                        }
                    });
                }
                else {
                    App.addToFavorites({
                        infohash: infohash,
                        title: title,
                        category: category
                    }, function(response) {
                        if(response !== null) {
                            $self.data("is-favorite", "yes");
                            $self.data("playlist-item-id", response.playlist_item_id);
                            $self.find(".material-icons")
                                .removeClass("acestream__favorite_no")
                                .addClass("acestream__favorite_yes")
                                .text("favorite");
                        }
                    });
                }
            });
        },

        renderSearchResultsItem: function(channelData) {
            var firstItem, channelId = 0, hasEpg = false, gotDetails = false;

            // get first item
            if(channelData.items && channelData.items.length > 0) {
                // sort by status
                channelData.items.sort(function(a, b) {
                    if(a.status > b.status) {
                        return -1;
                    }
                    if(a.status < b.status) {
                        return 1;
                    }
                    return 0;
                });
                firstItem = channelData.items[0];
                channelId = firstItem.channel_id;
                gotDetails = true;
            }
            else {
                channelId = channelData.channel_id || 0;
            }

            var isFavorite = false,
                playlistItemId = null;

            if(gotDetails) {
                playlistItemId = App.getFavoritePlaylistItemId(firstItem.infohash, null);
            }

            if(playlistItemId === null) {
                playlistItemId = 0;
            }
            else {
                isFavorite = true;
            }

            var itemCategory = "",
                statusColor = "",
                htmlStatus = "",
                htmlBitrate = "",
                htmlEpg = "",
                htmlEpgButton = "",
                htmlIcon = "",
                htmlAddToPlaylist = "",
                htmlSelectPlayer = "",
                htmlShare = "",
                htmlToggleFavorite = "",
                htmlCategory = "",
                htmlOtherLink = "",
                htmlOther = "";

            if(gotDetails && firstItem.bitrate) {
                htmlBitrate = '<div class="acestream__sri-description">';
                htmlBitrate += (firstItem.bitrate * 8 / 1000000).toFixed(2);
                htmlBitrate += ' ' + __('Mbps');
                htmlBitrate += '</div>';
            }

            var currentProgram = null;
            if(channelData.epg) {
                if(Array.isArray(channelData.epg) && channelData.epg.length > 0) {
                    // new style: `epg` is array of objects
                    currentProgram = channelData.epg[0];
                }
                else {
                    // old style: `epg` is object
                    currentProgram = channelData.epg;
                }
            }

            if(currentProgram) {
                hasEpg = true;

                var now = TorrentStream.moment();
                var start = TorrentStream.moment.unix(currentProgram.start);
                var stop = TorrentStream.moment.unix(currentProgram.stop);

                var secondsPlayed = TorrentStream.moment.duration(now.diff(start)).asSeconds();
                var totalSeconds = currentProgram.stop - currentProgram.start;
                var playedPercent = Math.round(secondsPlayed / totalSeconds * 100);

                htmlEpg = '<div class="acestream__sri-epg-data">';
                htmlEpg += start.format("HH:mm") + " - ";
                htmlEpg += stop.format("HH:mm") + " ";
                htmlEpg += currentProgram.name;
                htmlEpg += '<div style="position: relative; width: 200px; height: 5px; background-color: #ccc;">';
                htmlEpg += '<div style="position: absolute; left: 0; top: 0; width: '+playedPercent+'%; height: 100%; background-color: #27a75b;"></div>';
                htmlEpg += '</div>';
                htmlEpg += '</div>';
            }

            if(channelData.icon) {
                htmlIcon = '<img class="acestream__sri-icon" style="display: none;" />';
            }

            if(channelData.epg) {
                htmlEpgButton = '<a href="#" class="acestream__sri-toolbar-link acestream__action-show-epg-popup" data-channel-id="' + channelId + '" data-channel-name="' + TorrentStream.Utils.escapeHtml(channelData.name) + '" onclick="return false;">';
                htmlEpgButton += __('Program Guide (EPG)');
                htmlEpgButton += '</a>';
            }

            if(gotDetails) {
                if(firstItem.status == 2) {
                    statusColor = "#27a75b";
                }
                else if(firstItem.status == 1) {
                    statusColor = "#dddd00";
                }
                htmlStatus = '<span class="acestream__sri-status-icon acestream__floating" style="background-color: ' + statusColor + '"></span>';
            }

            if(channelData.category) {
                itemCategory = channelData.category;
            }
            else if(firstItem && firstItem.categories && firstItem.categories.length > 0) {
                itemCategory = firstItem.categories[0];
            }

            if(itemCategory.length > 0) {
                htmlCategory += ' &gt; <a href="#" class="acestream__action-filter-category" onclick="return false;" data-category-id="'+itemCategory+'">' + App.getCategoryName(itemCategory) + '</a>';
            }

            if(channelData.items && channelData.items.length > 1) {
                htmlOtherLink = ' &gt; <a href="#" class="acestream__link-dropdown acestream__action-show-other" data-item-id="' + channelData.index + '" data-state="closed">' + __('Other variants of broadcast') +  '<span class="acestream__arrow-down-green"></span></a>';

                htmlOther = '<div style="display: none;" class="acestream__sri-other" id="acestream__other-' + channelData.index + '">';
                for(var i=1; i<channelData.items.length; i++) {
                    var _item = channelData.items[i],
                        _itemStatusColor = "#ccc",
                        bitrate = _item.bitrate,
                        category = "",
                        infohash = _item.infohash;

                    if(_item.status == 2) {
                        _itemStatusColor = "#27a75b";
                    }
                    else if(_item.status == 1) {
                        _itemStatusColor = "#dddd00";
                    }

                    if(_item.categories && _item.categories.length > 0) {
                        category = _item.categories[0];
                    }

                    htmlOther += '<div class="acestream__sri-other-item">';
                    htmlOther += '<span class="acestream__sri-status-icon" style="background-color: ' + _itemStatusColor + '"></span>';

                    htmlOther += '<span>';
                    if(bitrate) {
                        htmlOther += (bitrate * 8 / 1000000).toFixed(2);
                    }
                    else {
                        htmlOther += '?.??';
                    }
                    htmlOther += ' ' + __('Mbps');
                    htmlOther += '</span>';

                    htmlOther += '<a href="#" class="acestream__action-open-share-popup" data-infohash="' + _item.infohash + '" data-title="' + TorrentStream.Utils.escapeHtml(channelData.name) + '"><i class="material-icons">share</i></a>';
                    htmlOther += '<a href="#" class="acestream__action-playlist-add" data-infohash="' + _item.infohash + '" data-category-id="' + category + '" data-in-playlist="' + (_item.in_playlist ? 'yes' : 'no') + '" data-is-first="no"><i class="material-icons">' + (_item.in_playlist ? 'playlist_add_check' : 'playlist_add') + '</i></a>';
                    htmlOther += '<a href="#" class="acestream__action-select-player" data-infohash="' + _item.infohash + '" data-has-epg="' + (hasEpg ? 'yes' : 'no') + '" data-channel-id="' + channelId + '" data-channel-name="' + TorrentStream.Utils.escapeHtml(channelData.name) + '"><i class="material-icons">more_vert</i></a>';
                    htmlOther += '<a href="#" class="acestream__action-play" data-infohash="' + _item.infohash + '"><i class="material-icons">play_arrow</i></a>';
                    htmlOther += '</div>';
                }
                htmlOther += '</div>';
            }

            if(gotDetails) {
                if(!App.getOption('add_to_playlist.hide')) {
                    htmlAddToPlaylist =
                        '<a href="#" class="acestream__sri-toolbar-link acestream__action-playlist-add" data-is-first="yes" data-in-playlist="' + (firstItem.in_playlist ? 'yes' : 'no') + '" data-infohash="' + firstItem.infohash + '" data-category-id="' + itemCategory + '">'+
                            __('Add to playlist')+
                            '<i class="material-icons">' + (firstItem.in_playlist ? 'playlist_add_check' : 'playlist_add') + '</i>'+
                        '</a>';
                }

                if(!App.getOption('select_player.hide')) {
                    htmlSelectPlayer =
                        '<a href="#" class="acestream__sri-toolbar-link acestream__link-dropdown acestream__action-select-player" data-infohash="' + firstItem.infohash + '" data-has-epg="' + (hasEpg ? 'yes' : 'no') + '" data-channel-id="' + channelId + '" data-channel-name="' + TorrentStream.Utils.escapeHtml(channelData.name) + '">'+
                            __('Select player')+
                            '<span class="acestream__arrow-down-blue"></span>'+
                        '</a>';
                }

                htmlShare =
                    '<a href="#" class="acestream__sri-toolbar-link acestream__action-open-share-popup" data-infohash="' + firstItem.infohash + '" data-title="' + TorrentStream.Utils.escapeHtml(channelData.name) + '">'+
                        __('Share')+
                        '<i class="material-icons">share</i>'+
                    '</a>';

                htmlToggleFavorite =
                    '<a href="#" class="acestream__action-toggle-favorite" data-infohash="' + firstItem.infohash + '" data-category-id="' + itemCategory + '" data-title="' + TorrentStream.Utils.escapeHtml(channelData.name) + '" data-is-favorite="' + (isFavorite ? 'yes' : 'no') + '" data-playlist-item-id="' + playlistItemId + '">'+
                        '<i class="material-icons ' + (isFavorite ? 'acestream__favorite_yes' : 'acestream__favorite_no') + '">' + (isFavorite ? 'favorite' : 'favorite_border') + '</i>'+
                    '</a>';
            }

            var itemTitle = prepareTitle(channelData.name);

            var $item = $(
                '<div class="acestream__search-result-item">'+
                    '<div class="acestream__sri-title">'+
                        htmlStatus+
                        (gotDetails
                            ? '<a href="#" class="acestream__action-play" data-infohash="' + firstItem.infohash + '">' + itemTitle + '</a>'
                            : '<a href="#" class="acestream__action-play" onclick="return false;">' + itemTitle + '</a>'
                            )+
                        htmlIcon+
                        htmlToggleFavorite+
                    '</div>'+
                    '<div class="acestream__sri-info">'+
                        'P2P &gt; TV'+
                        htmlCategory+
                        htmlOtherLink+
                    '</div>'+
                    htmlBitrate+
                    htmlEpg+
                    '<div class="acestream__sri-toolbar">'+
                        htmlEpgButton+
                        htmlAddToPlaylist+
                        htmlSelectPlayer+
                        htmlShare+
                    '</div>'+
                    htmlOther+
                '</div>'
                );

            if(channelData.icon) {
                var $img = $item.find("img.acestream__sri-icon");
                App.loadImage(
                    channelData.icon,
                    $img.get(0),
                    function(success) {
                        if(success) {
                            $img.show();
                        }
                    });
            }

            return $item;
        },

        renderFavoriteItem: function(item) {
            // for testing
            var firstItem = {};

            var isFavorite = true,
                playlistItemId = item.id,
                statusColor = "",
                htmlBitrate = "",
                htmlEpg = "",
                htmlEpgButton = "",
                htmlCategory = "";

            if(firstItem.bitrate) {
                htmlBitrate = '<div class="acestream__sri-description">';
                htmlBitrate += (firstItem.bitrate * 8 / 1000000).toFixed(2);
                htmlBitrate += ' Мбит/с';
                htmlBitrate += '</div>';
            }

            if(item.epg && item.epg.length > 0) {
                var epgItem = item.epg[0];

                htmlEpgButton = '<a href="#" class="acestream__sri-toolbar-link acestream__action-show-epg-popup" data-playlist-item-id="' + playlistItemId + '" data-channel-name="' + TorrentStream.Utils.escapeHtml(item.title) + '">';
                htmlEpgButton += 'Программа передач (EPG)';
                htmlEpgButton += '</a>';

                // hasEpg = true;

                var now = TorrentStream.moment();
                var start = TorrentStream.moment.unix(epgItem.start);
                var stop = TorrentStream.moment.unix(epgItem.stop);

                var secondsPlayed = TorrentStream.moment.duration(now.diff(start)).asSeconds();
                var totalSeconds = epgItem.stop - epgItem.start;
                var playedPercent = Math.round(secondsPlayed / totalSeconds * 100);

                htmlEpg = '<div class="acestream__sri-epg-data">';
                htmlEpg += start.format("HH:mm") + " - ";
                htmlEpg += stop.format("HH:mm") + " ";
                htmlEpg += epgItem.title;
                htmlEpg += '<div style="position: relative; width: 200px; height: 5px; background-color: #ccc;">';
                htmlEpg += '<div style="position: absolute; left: 0; top: 0; width: '+playedPercent+'%; height: 100%; background-color: #27a75b;"></div>';
                htmlEpg += '</div>';
                htmlEpg += '</div>';
            }

            if(firstItem.status == 2) {
                statusColor = "#27a75b";
            }
            else if(firstItem.status == 1) {
                statusColor = "#dddd00";
            }

            if(item.subcategory) {
                htmlCategory += ' &gt; <a href="#" class="acestream__action-filter-category" onclick="return false;" data-category-id="'+item.subcategory+'">' + App.getCategoryName(item.subcategory) + '</a>';
            }

            var infohash = item.infohash;
            if(item.last_auto_search_data && item.last_auto_search_data.infohash) {
                // use autosearch infohash
                infohash = item.last_auto_search_data.infohash;
            }

            var $item = $(
                '<div class="acestream__search-result-item">'+
                    '<div class="acestream__sri-title">'+
                        '<span class="acestream__sri-status-icon acestream__floating" style="background-color: ' + statusColor + '"></span>'+
                        '<a href="#" class="acestream__action-play" data-infohash="' + infohash + '" data-playlist-item-id="' + playlistItemId + '">' + TorrentStream.Utils.escapeHtml(item.title) + '</a>'+
                        '<a href="#" class="acestream__action-toggle-favorite" data-playlist-item-id="' + playlistItemId + '" data-is-favorite="yes">'+
                            '<i class="material-icons ' + (isFavorite ? 'acestream__favorite_yes' : 'acestream__favorite_no') + '">' + (isFavorite ? 'favorite' : 'favorite_border') + '</i>'+
                        '</a>'+
                    '</div>'+
                    '<div class="acestream__sri-info">'+
                        'P2P &gt; TV'+
                        htmlCategory+
                    '</div>'+
                    htmlBitrate+
                    htmlEpg+
                    '<div class="acestream__sri-toolbar">'+
                        htmlEpgButton+
                        '<a href="#" class="acestream__sri-toolbar-link acestream__link-dropdown acestream__action-select-player" data-infohash="' + item.infohash + '">'+
                            'Выбрать плеер'+
                            '<span class="acestream__arrow-down-blue"></span>'+
                        '</a>'+
                        '<a href="#" class="acestream__sri-toolbar-link acestream__action-open-share-popup" data-infohash="' + item.infohash + '">'+
                            'Поделиться'+
                            '<i class="material-icons">share</i>'+
                        '</a>'+
                    '</div>'+
                '</div>'
                );

            return $item;
        },

        /**
        * Render default pagination
        */
        renderPagination: function(total_items, page, page_size) {
            var html = "";
            var count_pages = Math.ceil(total_items / page_size);
            if(count_pages > 1) {
                html += '<div class="search-results-pagination" style="margin-top: 10px;">';

                if(count_pages <= 3) {
                    // show just page numbers
                    for(var i=0; i < count_pages; i++) {
                        if(i === page) {
                            html += '<a href="#" class="btn btn-info" onclick="return false;">' + (i+1) + '</a> ';
                        }
                        else {
                            html += '<a href="#" class="btn btn-info white acestream__action-load-search-results-page" data-page="'+i+'">' + (i+1) + '</a> ';
                        }
                    }
                }
                else {
                    // first
                    html += '<a href="#" class="btn btn-info white acestream__action-load-search-results-page" data-page="0">&lt;&lt;</a> ';
                    // prev
                    html += '<a href="#" class="btn btn-info white acestream__action-load-search-results-page" data-page="'+Math.max(0, page-1)+'">&lt;</a> ';

                    var start = Math.max(page-2, 0),
                        end = Math.min(page+2, count_pages-1);

                    start = Math.max(0, Math.min(start, end-4));
                    end = Math.min(count_pages-1, Math.max(end, start+4));

                    for(var i=start; i <= end; i++) {
                        if(i === page) {
                            html += '<a href="#" class="btn btn-info" onclick="return false;">' + (i+1) + '</a> ';
                        }
                        else {
                            html += '<a href="#" class="btn btn-info white acestream__action-load-search-results-page" data-page="'+i+'">' + (i+1) + '</a> ';
                        }
                    }

                    // last page number
                    if(end < count_pages-2) {
                        html += '<a href="#" class="btn btn-info white" onclick="return false;">...</a> ';
                    }
                    if(end < count_pages-1) {
                        html += '<a href="#" class="btn btn-info white acestream__action-load-search-results-page" data-page="'+(count_pages-1)+'">' + count_pages + '</a> ';
                    }

                    // next
                    html += '<a href="#" class="btn btn-info white acestream__action-load-search-results-page" data-page="'+Math.min(page+1, count_pages-1)+'">&gt;</a> ';
                    // last
                    html += '<a href="#" class="btn btn-info white acestream__action-load-search-results-page" data-page="'+(count_pages-1)+'">&gt;&gt;</a>';
                }

                html += '</div>';
            }

            App.setPagination(html);
        },

        /**
        * Set rendered pagination (html)
        */
        setPagination: function(html) {
            if(_$searchResultsContainer === null) {
                App.debug("setPagination: no results container");
                return;
            }
            _$searchResultsContainer.append(html);
        },

        /**
        * Call |updateFavorites| and schedule it.
        */
        updateFavoritesTask: function() {
            App.updateFavorites();
            setTimeout(App.updateFavoritesTask, UPDATE_FAVORITES_INTERVAL);
        },

        /**
        * Get all favorites from engine and save in local vars
        */
        updateFavorites: function() {
            AWE_getPlaylist({
                is_favorite: true,
                sort: 1,
                offset: 0,
                limit: 1000
            }, function(response) {
                App.debug("updateFavorites: got playlist", response);

                // reset
                _favoritesAll = [];
                _favoritesByCategory = {};
                _favoritesByInfohash = {};
                _favoritesByName = {};

                if(response && response.playlist) {
                    for(var i=0; i<response.playlist.length; i++) {
                        var item = response.playlist[i];
                        _favoritesAll.push(item);
                        if(item.subcategory) {
                            if(_favoritesByCategory[item.subcategory] === undefined) {
                                _favoritesByCategory[item.subcategory] = [];
                            }
                            _favoritesByCategory[item.subcategory].push(item);
                        }
                        _favoritesByInfohash[item.infohash] = item.id;
                        _favoritesByName[item.title] = item.id;
                    }
                }
            });
        },

        /**
        * Add item to favorites
        * details = {infohash, category, title}
        */
        addToFavorites: function(details, callback) {
            // 1) add to playlist
            // 2) search playlist by name to find added item (we need item id)
            // 3) set favorite
            AWE_addToPlaylist({
                    category: 'tv',
                    subcategory: details.category,
                    infohash: details.infohash,
                    title: details.title,
                    auto_search: true,
                }, function(response) {
                    App.debug("addToFavorites: add playlist response", response);
                    AWE_getPlaylist({
                            name: details.title
                        },
                        function(response) {
                            App.debug("addToFavorites: get playlist response", response);
                            if(response && response.playlist) {
                                for(var i=0; i<response.playlist.length; i++) {
                                    var item = response.playlist[i];
                                    if(item.infohash === details.infohash) {
                                        AWE_setFavorite({
                                            id: item.id,
                                            value: 1
                                        }, function(response) {
                                            if(response != null) {
                                                callback({
                                                    playlist_item_id: item.id
                                                });
                                                //TODO: optimize - no need to reload all favorites
                                                App.updateFavorites();
                                            }
                                        });
                                        break;
                                    }
                                }
                            }
                        });
                });
        },

        /**
        * Remove items from favorites
        * details = {playlistItemId}
        */
        removeFromFavorites: function(details, callback) {
            AWE_setFavorite({
                id: details.playlistItemId,
                value: 0
            }, function(response) {
                callback(response);
                //TODO: optimize - no need to reload all favorites
                App.updateFavorites();
            });
        },

        openInDefaultPlayer: function(details) {
            App.log("openInDefaultPlayer: details=" + JSON.stringify(details));
            showSpinner();

            // Logic:
            // if plugin is installed and enabled, run it
            // if plugin is installed, but not enabled, show warning
            // if plugin is not installed then check engine status
            // if engine is not running (status==0) then show warning
            // if old engine is running (no media server API), then get content id and try to open acestream:// link
            // if new engine is running then open content in the default player

            // check whether plugin is installed
            var availablePlugin = TorrentStream.Utils.detectPluginExt();

            if(!_pluginEnabled) {
                availablePlugin.type = 0;
            }

            if(availablePlugin.type != 0) {
                // plugin is installed
                if(availablePlugin.enabled) {
                    // open in web player
                    hideSpinner();
                    showPlayer({
                        infohash: details.infohash
                    });
                }
                else {
                    hideSpinner();
                    App.showWarningWindow("plugin-not-enabled");
                }
            }
            else {
                // plugin is not installed, check engine
                AWE_engineStatus(function(engineStatus) {
                    App.log("openInDefaultPlayer: engine status: " + JSON.stringify(engineStatus));

                    // for testing - remove this when AWE_getEngineStatus is fixed in the extension
                    if (engineStatus.status === 'test') {
                        engineStatus.version = 0;
                    }

                    if(engineStatus.version == 0) {
                        // engine is not running
                        hideSpinner();
                        App.showWarningWindow("missing-engine");
                    }
                    else {
                        var playFunction;
                        var needContentId = false;

                        if(IS_ANDROID) {
                            needContentId = true;
                            playFunction = function(contentId) {
                                hideSpinner();
                                window.location.href = 'acestream://' + contentId;
                            };
                        }
                        else if(_pluginEnabled && _jsPlayerEnabled && engineStatus.version >= 3010800) {
                            // open jsplayer
                            needContentId = false;
                            playFunction = function() {
                                hideSpinner();
                                showPlayer({
                                    infohash: details.infohash,
                                    forceJsPlayer: true,
                                });
                            };

                        }
                        else if(engineStatus.version >= 3003200) {
                            // new engine running, open in default desktop player
                            needContentId = true;
                            playFunction = function(contentId) {
                                var params = {
                                    content_id: contentId
                                };
                                AWE_openInPlayer(params, undefined, function(response) {
                                    hideSpinner();
                                });
                            };
                        }
                        else {
                            // old engine running
                            needContentId = true;
                            playFunction = function(contentId) {
                                hideSpinner();
                                window.location.href = "acestream://" + contentId;
                            };
                        }

                        if(!needContentId) {
                            if(!details.infohash) {
                                throw 'missing required infohash';
                            }
                            // call playFunction now
                            playFunction();
                        } else if(details.contentId) {
                            playFunction(details.contentId);
                        } else {
                            // get content id and then call playFunction
                            var _infohash = details.infohash;
                            if(_content_id_cache[_infohash]) {
                                App.debug("got content id from cache: id=" + _content_id_cache[_url] + " infohash=" + _infohash);
                                playFunction(_content_id_cache[_infohash]);
                            }
                            else {
                                App.debug("get content id");

                                AWE_getContentId({
                                    infohash: _infohash
                                }, function(response) {
                                    hideSpinner();
                                    if(response && response.content_id) {
                                        _content_id_cache[_infohash] = response.contentId;
                                        playFunction(response.content_id);
                                    }
                                    else {
                                        alert(__("Failed to get content id"));
                                    }
                                });
                            }
                        }
                    }
                });
            }
        },

        showWarningWindow: function(windowId) {
            App.log("showWarningWindow: id=" + windowId);
            _$warningPopup.show();
        },

        /**
        * Send stat query
        */
        stat: function(queryString, source) {
            var url = "https://mstat.acestream.net/imp?_t=search&q=" + encodeURIComponent(queryString) + "&b="+Math.random();
            // referer
            url += "&_r=" + encodeURIComponent(window.location.href);
            if(source) {
                url += "&_s=" + encodeURIComponent(source);
            }
            GM_xmlhttpRequest({
                method: "GET",
                url: url,
            });
        },

        LocationChangeListener: function(callback, interval) {
            var self = this,
                timer;

            interval = interval || 1000;
            this.currentLocation = window.location.href;

            var detect = function(){
                if(self.currentLocation != window.location.href) {
                    if(typeof callback === "function") {
                        callback(self.currentLocation, window.location.href);
                    }
                    self.currentLocation = window.location.href;
                }
            };
            timer = setInterval(function(){ detect() }, interval);
        },

        parseQueryString: function(queryString, stripChar) {
            var params = {};

            if(queryString.length > 0) {
                // remove "stripChar" at the beginning
                if(stripChar && queryString.substring(0, 1) === stripChar) {
                    queryString = queryString.substring(1);
                }

                var i, a = queryString.split("&");
                for(i=0; i<a.length; i++) {
                    var b = a[i].split("=");
                    if(b.length == 2) {
                        params[b[0]] = decodeURIComponent(b[1]);
                    }
                }
            }

            return params;
        },

        setOption: function(key, value) {
            _options[key] = value;
        },

        getOption: function(key, value) {
            return _options[key];
        },
    });

    function showPlayer(conf) {
        var controls = {
            attachPlayer: function(player) {
            }
        };

        if(conf.hasEpg) {
            AWE_getEpg({
                channelId: conf.channelId,
                engineVersion: App.getEngineVersion()
            }, function(response) {
                if(response) {
                    _$epgContainer.html(render_epg_list(response));
                }
            });
        }
        else {
            _$epgContainer.empty();
        }

        try {
            var playerClass = conf.forceJsPlayer ? TorrentStream.JsPlayer : TorrentStream.Player;
            var player = new playerClass(_$playerContainer.get(0), {
                    useInternalControls: true,
                    debug: conf.debug,
                    bgColor: "#2b2b2b",
                    onLoad: function() {
                        try {
                            var self = this;
                            this.registerEventHandler(controls);
                            controls.attachPlayer(this);

                            var mediaConf = {
                                autoplay: true,
                                affiliateId: AFFILIATE_ID,
                                zoneId: ZONE_ID
                            };

                            function _start(skip_autoplay) {
                                if(skip_autoplay) {
                                    mediaConf.autoplay = false;
                                }
                                self.loadInfohash(conf.infohash, mediaConf);
                            }

                            if(this.getType() == "flowplayer" || this.getType() == "jsplayer") {
                                $.ajax({
                                    url: 'https://auth3.acestream.net/d',
                                    type: 'GET',
                                    dataType: 'json',
                                    cache: false,
                                    xhrFields: {
                                        withCredentials: true
                                    },
                                    timeout: 10000,
                                    success: function(response) {
                                        if(response.a === 1) {
                                            controls.showYandexOffer(function(got_install, install_type) {
                                                _start(got_install);

                                                if(got_install) {
                                                    $.ajax({
                                                        url: 'https://auth3.acestream.net/e',
                                                        type: 'GET',
                                                        dataType: 'json',
                                                        data: {
                                                            type: install_type
                                                        },
                                                        cache: false,
                                                        timeout: 10000
                                                    });
                                                }
                                            });
                                        }
                                        else {
                                            _start();
                                        }
                                    },
                                    error: function() {
                                        _start();
                                    }
                                });
                            }
                            else {
                                _start();
                            }
                        }
                        catch(e) {
                            App.debug("player:onload: " + e);
                        }
                    }
            });
        }
        catch(e) {
            App.log("showPlayer: " + e);
            if(e == "plugin_not_installed") {
                App.showWarningWindow("missing-engine");
            }
            else if(e == "plugin_not_enabled") {
                App.showWarningWindow("plugin-not-enabled");
            }
        }
    }

    function showSpinner(conf) {
        if(document.getElementById("magicplayer-spinner")) {
            return;
        }

        var spinner = document.createElement("div");
        spinner.id = "magicplayer-spinner";
        spinner.setAttribute('style', 'z-index:1000000;position:fixed;left:39%;top:0px;width:22%;height:50px;background-color:#424242;text-align:center;font-size:25px;line-height:50px;color:#eaeaea;;font-family:Open Sans,Arial,Tahoma;');
        spinner.innerHTML = __("Loading");
        document.body.appendChild(spinner);

        if(conf && conf.useTsButton) {
            TorrentStream.Button.start();
        }
    };

    function hideSpinner(conf) {
        var spinner = document.getElementById("magicplayer-spinner");
        if(spinner) {
            spinner.parentNode.removeChild(spinner);
        }

        if(conf && conf.useTsButton) {
            TorrentStream.Button.stop();
        }
    };

    function getHandlers(url)
    {
        var handlers = [];
        for(var i = 0; i < App.script_map.length; i++) {
            item = App.script_map[i];
            if(item.pattern && (new RegExp(item.pattern)).test(url)) {
                GM_log("getHandlers: got match: url=" + url + " handler=" + item.handler);
                if(item.handler) {
                    handlers.push(item.handler);
                }
            }
        }
        return handlers;
    };

    //metrika
    (function(d) {
        var s=d.createElement('script');
        s.src='//mstat.acestream.net/p2p-search/metrika.js?loc=' + encodeURIComponent(location.host) + "&_r=" + Math.random();
        d.body.appendChild(s);
    })(document);

    // entry point
    AWE_engineStatus(function(engineStatus) {
        var i,
            handlers = getHandlers(location.href),
            toRun = [];

        App.debug("engine status on start: " + JSON.stringify(engineStatus));
        App.setEngineVersion(engineStatus.version);

        for(i=0; i < handlers.length; i++) {
            if(typeof App.handlers[handlers[i]] === 'function') {
                toRun.push(handlers[i]);
            }
        }
        if(toRun.length) {
            for(i=0; i < toRun.length; i++) {
                GM_log("execute handler: " + toRun[i]);
                try {
                    App.handlers[toRun[i]].call(null);
                }
                catch(e) {
                    App.log('handler failed: ' + e);
                }
            }
        }

        if(shouldSearchContentId()) {
            App.log('p2p-search: search for content ids');
            App.injectCommonStyles();
            App.createMissingEnginePopup();
            replaceContentIds();
        }
    });

}();