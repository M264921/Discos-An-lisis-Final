App.addHandler("google", function() {
    App.debug("start google");

    var SUGGEST_INTERVAL = 350;
    var SOURCE_ID = "p2ps/g";

    var _suggestTimer = null,
        $original_container = null,
        $original_pagination = null,
        $acestream_container = null,
        $original_filters_container = null,
        $acestream_filters_container = null,
        $acestream_btn = null,
        $acestream_btn_active = null,
        $www_active = null,
        _lastQueryLength = 0,
        _lastQueryString = "",
        _markupVersion = 0,
        _isMobile = false,
        $ = TorrentStream.jQuery,
        __ = TorrentStream.Lang.getString;

    function detectMarkupVersion() {
        // _markupVersion and _isMobile are set here

        if($("#searchform .sfibbbc").size()) {
            _markupVersion = 1;
            _isMobile = false;
        }
        else if($("#searchform form.tsf").size()) {
            if($("div.beZ0tf.O1uzAe").size()) {
                _markupVersion = 6;
                _isMobile = false;
            }
            else if($("#hdtb-msb").size()) {
                _markupVersion = 2;
                _isMobile = false;
            }
            else if($("#bqHHPb").size()) {
                _markupVersion = 4;
                _isMobile = false;
            }
            else if($(".sBbkle .xhjkHe .TrmO7 .nfdoRb").size()) {
                _markupVersion = 5;
                _isMobile = false;
            }
        }
        else if($("div.bz1lBb form#sf").size()) {
            _markupVersion = 3;
            _isMobile = true;
        }
        else {
            throw 'failed_detect_markup';
        }

        App.debug("markup version", _markupVersion);
    }

    function findSearchForm() {
        var $form;

        if(_markupVersion == 1) {
            $form = $("#searchform .sfibbbc");
        }
        else if(_markupVersion == 2 || _markupVersion == 4 || _markupVersion == 5 || _markupVersion == 6) {
            $form = $("#searchform form.tsf");
        }
        else if(_markupVersion == 3) {
            $form = $("div.bz1lBb form#sf");
        }
        else {
            throw 'unknown_markup_version';
        }


        if($form.size() == 0) {
            throw 'missing_search_form';
        }
        else if($form.size() > 1) {
            throw 'ambigious_search_form';
        }

        return $form;
    }

    function findSearchInput() {
        var $input;
        if(_markupVersion == 1) {
            $input = $original_search_form.find("input");
        }
        else if(_markupVersion == 2 || _markupVersion == 4 || _markupVersion == 5 || _markupVersion == 6) {
            $input = $original_search_form.find("textarea[name=q]");
            if($input.size() == 0) {
                $input = $original_search_form.find("input[name=q]");
            }
        }
        else if(_markupVersion == 3) {
            $input = $original_search_form.find("input.noHIxc");
        }
        else {
            throw 'unknown_markup_version';
        }

        if($input.size() == 0) {
            throw 'missing_search_input';
        }
        else if($input.size() > 1) {
            throw 'ambigious_search_input';
        }

        return $input;
    }

    function findNavigationContainer() {
        var $container;

        if(_markupVersion == 6) {
            $container = $("div.beZ0tf.O1uzAe");
        }
        else if(_markupVersion == 5) {
            $container = $(".sBbkle .xhjkHe .TrmO7 .nfdoRb");
        }
        else if(_markupVersion == 4) {
            $container = $("#bqHHPb .IUOThf");
        }
        else if(_isMobile) {
            $container = $("div.N6RWV div.Pg70bf");
        }
        else {
            $container = $("#hdtb-msb");
        }

        if($container.size() == 0) {
            throw 'missing_nav_container';
        }

        if($container.size() > 1) {
            throw 'ambigious_nav_container';
        }

        return  $container;
    }

    function createNavigationButton(details) {
        var $button;

        if(_markupVersion == 6) {
            // $button = $('<div role="listitem" data-hveid="CBsQAA" data-ved="2ahUKEwjj9arMw5mPAxWwTkEAHaImBU0QtoAJKAB6BAgbEAA"><a jsname="pxBnId" class="C6AK7c xZk2S" href="/search?sca_esv=1c2c48b035966a68&amp;sxsrf=AE3TifPLpQGiA0N0t-8dkJu4uMqZsmqdTA:1755697696657&amp;q=bbc+news&amp;tbm=nws&amp;source=lnms&amp;fbs=AIIjpHxU7SXXniUZfeShr2fp4giZrjP_Cx0LI1Ytb_FGcOviEreERTNAkkP8Y6EXltYTGWs9RGaEMfZ2dZFFrbmM-rnqDh6hIMjQfCAhrLJz0ZmMZpUjCqTWcnwxm3CIjs0GarosQfLkZI74FJnvDMIm-XrwYNH_ZLlnLC3tycVbHgi9_Y2zDHGtoE3W6PReY7DiZvfCy8yTVgdH6w-S-Wt5wwt6R5lw8w&amp;sa=X&amp;ved=2ahUKEwjj9arMw5mPAxWwTkEAHaImBU0Q0pQJegQIGxAB" jsaction="" data-hveid="CBsQAQ" data-ved="2ahUKEwjj9arMw5mPAxWwTkEAHaImBU0Q0pQJegQIGxAB"><div jsname="xBNgKe" class="mXwfNd"><span class="R1QWuf">News</span></div></a></div>')
            if(details.active) {
                $button = $('<div role="listitem"><a class="C6AK7c xZk2S acestream-nav-button-active" href="#"><div selected class="mXwfNd acestream-tab-inner"><span class="R1QWuf">' + details.title + '</span></div></a></div>')
            }
            else {
                $button = $('<div role="listitem"><a class="C6AK7c xZk2S" href="#"><div class="mXwfNd acestream-tab-inner"><span class="R1QWuf">' + details.title + '</span></div></a></div>')
            }
        }
        else if(_markupVersion == 5) {
            if(details.active) {
                $button = $('<a class="zItAnd FOU1zf acestream-nav-button-active" href="javascript:void(0)"><div class="O3S9Rb">' + details.title + '</div></a>');
            }
            else {
                $button = $('<a class="zItAnd FOU1zf" href="#"><div class="O3S9Rb">' + details.title + '</div></a>');
            }
        }
        else if(_markupVersion == 4) {
            if(details.active) {
                $button = $('<a class="LatpMc nPDzT T3FoJb acestream-nav-button-active" href="javascript:void(0)" role="link listitem"><div class="GKS7s"><span class="FMKtTb UqcIvb">' + details.title + '</span></div></a>');
            }
            else {
                $button = $('<a class="LatpMc nPDzT T3FoJb" href="#" role="link listitem"><div class="GKS7s"><span class="FMKtTb UqcIvb">' + details.title + '</span></div></a>');
            }
        }
        else {
            if(details.active) {
                if(_markupVersion == 3) {
                    $button = $('<span class="OXXup">' + details.title + '</span>');
                }
                else {
                    $button = $('<div class="hdtb-mitem hdtb-msel hdtb-imb">' + details.title + '<div class="YTDezd"></div></div>');
                }
            }
            else {
                $button = $('<div class="hdtb-mitem hdtb-imb"><a class="q qs" href="#">' + details.title + '</a></div>');
            }
        }

        if(details.id) {
            $button.attr('id', details.id);
        }

        if(details.active) {
            $button.css({ 'display': 'none' });
        }

        return $button;
    }

    function hideGoogleResults() {
        if($original_search_form) {
            $original_search_form.hide();
        }
        if($original_container) {
            $original_container.hide();
        }
        if($original_pagination) {
            $original_pagination.hide();
        }
        if(_markupVersion == 4 || _markupVersion == 5) {
            // hide additional info container (e.g. wikipedia block)
            $('.M8OgIe').hide();
        }
    }

    function showAceStreamTab() {
        hideGoogleResults();
        $acestream_search_form.show();
        $acestream_container.show();
        if($acestream_btn) {
            $acestream_btn.hide();
        }
        if($acestream_btn_active) {
            $acestream_btn_active.show();
        }
        showAceStreamFilters();
    }

    function onCurrentCategoryChanged(categoryId) {
        if(categoryId === "__all__") {
            $(".acestream__top-category-filter .acestream__name").text(__("Select category"));
        }
        else {
            $(".acestream__top-category-filter .acestream__name").text(App.getCategoryName(categoryId));
        }
    }

    function onSearchModeChanged(mode) {
        if(mode == "favorites") {
            $acestream_search_input.val("");
            $(".acestream__action-filter-all").removeClass("acestream__selected");
            $(".acestream__action-filter-favorite").addClass("acestream__selected");
        }
        else if(mode == "all") {
            $acestream_search_input.val("");
            $(".acestream__action-filter-all").addClass("acestream__selected");
            $(".acestream__action-filter-favorite").removeClass("acestream__selected");
        }
        else {
            $(".acestream__action-filter-all").removeClass("acestream__selected");
            $(".acestream__action-filter-favorite").removeClass("acestream__selected");
        }
    }

    function renderPagination(total_items, page, page_size) {
        var html = "";
        var count_pages = Math.ceil(total_items / page_size);
        if(count_pages > 1) {

            html += '<div class="acestream__pagination">';
            html += '<table style="border-collapse:collapse;text-align:left;margin:30px auto 30px" id="nav" role="presentation">';
            html += '<tbody>';
            html += '<tr valign="top">';

            // prev
            if(page > 0) {
                html += '<td class="acestream__pagination_prev"><a class="acestream__action-load-search-results-page" href="#" onclick="return false;" data-page="'+Math.max(0, page-1)+'"><span>' + __('google_prev') + '</span></a></td>';
            }

            var start = Math.max(page-5, 0),
                end = Math.min(page+4, count_pages-1);

            start = Math.max(0, Math.min(start, end-9));
            end = Math.min(count_pages-1, Math.max(end, start+9));

            for(var i=start; i <= end; i++) {
                if(i === page) {
                    html += '<td class="acestream__pagination_current">' + (i+1) + '</td>';
                }
                else {
                    html += '<td class="acestream__pagination_page"><a class="acestream__action-load-search-results-page" href="#" data-page="'+i+'" onclick="return false;">' + (i+1) + '</a></td>';
                }
            }

            // next
            if(page < count_pages-1) {
                html += '<td class="acestream__pagination_next"><a class="acestream__action-load-search-results-page" href="#" onclick="return false;" data-page="'+Math.min(page+1, count_pages-1)+'"><span>' + __('google_next') + '</span></a></td>';
            }

            html += '</tr>';
            html += '</tbody>';
            html += '</table>';
            html += '</div>';
        }

        return html;
    }

    function searchResultsCallback(response) {
        var results = response.results,
            scroll = response.scroll,
            totalItems = response.totalItems,
            page = response.page,
            page_size = response.page_size;

        App.renderSearchResults(results, scroll);
        App.setPagination(renderPagination(totalItems, page, page_size));
    }

    function showAceStreamFilters() {
        if($original_filters_container) {
            $original_filters_container.hide();
        }

        if($acestream_filters_container) {
            $acestream_filters_container.show();
        }

        $("#hdtbMenus").removeClass("hdtb-td-c").removeClass("hdtb-td-h").addClass("hdtb-td-o");
        $("#appbar").addClass("hdtb-ab-o");
        $("#hdtb-tls").removeClass("hdtb-tl-sel").hide();
        $('#result-stats').hide();
    }

    function hideAceStreamFilters() {
        if($original_filters_container) {
            $original_filters_container.show();
        }

        if($acestream_filters_container) {
            $acestream_filters_container.hide();
        }

        $("#hdtbMenus").addClass("hdtb-td-c").addClass("hdtb-td-h").removeClass("hdtb-td-o");
        $("#appbar").removeClass("hdtb-ab-o");
        $("#hdtb-tls").removeClass("hdtb-tl-sel").show();
        $('#result-stats').show();
    }

    function insertAceStreamTab() {
        if(document.getElementById("acestream-navigation-tab")) {
            App.debug("insertAceStreamTab: already inserted");

            if(location.hash.indexOf("p2p=1") !== -1) {
                //TODO: check if visible
                showAceStreamSearch();
            }

            return;
        }

        var isDefaultSearch;
        var isImageSearch;
        var isVideoSearch;

        var $navigationContainer = findNavigationContainer();

        if (_markupVersion == 6) {
            $www_active = $navigationContainer.find('div[role="listitem"]:eq(1)');
            isDefaultSearch = true;
            isImageSearch = false;
            isVideoSearch = false;
        }
        else if(_markupVersion == 4 || _markupVersion == 5) {
            $www_active = $navigationContainer.find("a:first");
            isDefaultSearch = true;
            isImageSearch = false;
            isVideoSearch = false;
        }
        else if(_isMobile) {
            $www_active = $navigationContainer.find("span:first");
            isDefaultSearch = $www_active.hasClass("OXXup");
            isImageSearch = (location.href.indexOf("tbm=isch") !== -1);
            isVideoSearch = (location.href.indexOf("tbm=vid") !== -1);
        }
        else {
            $www_active = $navigationContainer.find(".hdtb-mitem:first");
            isDefaultSearch = $www_active.hasClass("hdtb-msel");
            isImageSearch = (location.href.indexOf("tbm=isch") !== -1);
            isVideoSearch = (location.href.indexOf("tbm=vid") !== -1);
        }

        if($www_active.size() == 0) {
            throw 'missing_button_anchor';
        }

        $acestream_btn = createNavigationButton({
            title: __('P2P TV'),
            active: false,
            id: 'acestream-navigation-tab',
        });
        $acestream_btn_active = createNavigationButton({
            title: __('P2P TV'),
            active: true,
            id: 'acestream-navigation-tab-active',
        });

        $acestream_btn_active.on('click', function(e) {
            e.preventDefault();
        });

        var $activator;
        if (_markupVersion == 6) {
            $www_active.after($acestream_btn);
            $activator = $acestream_btn;
        }
        else if (_markupVersion == 4 || _markupVersion == 5) {
            $www_active.before($acestream_btn);
            $activator = $acestream_btn;
        }
        else {
            $www_active.after($acestream_btn);
            $activator = $acestream_btn.find('a');
        }

        $acestream_btn.after($acestream_btn_active);

        if(location.hash.indexOf("p2p=1") !== -1) {
            showAceStreamSearch();
        }

        $activator.on("click", function(event) {
            event.preventDefault();

            var queryString = $original_search_input.val();

            if(isImageSearch || isVideoSearch) {
                location.href = "/search?q=" + encodeURIComponent(queryString) + "#p2p=1";
            }
            else if(isDefaultSearch) {
                showAceStreamSearch();
            }
            else {
                location.hash = "q=" + encodeURIComponent(queryString) + "&p2p=1";
            }
        });

        function showAceStreamSearch() {
            if(!$acestream_btn) {
                App.debug("showAceStreamSearch: no acestream_btn", $acestream_btn);
                return;
            }
            if(!$acestream_search_form) {
                App.debug("showAceStreamSearch: no acestream_search_form");
                return;
            }
            if(!$acestream_container) {
                App.debug("showAceStreamSearch: no acestream_container");
                return;
            }

            if(document.getElementById("acestream__www-tab-button")) {
                App.debug("showAceStreamSearch: already visible");
                return;
            }

            var queryString = $original_search_input.val();

            var hashParams = App.parseQueryString(location.hash, "#");
            if(hashParams.q) {
                // overwrite from hash params
                queryString = decodeURIComponent(hashParams.q);
            }

            // ensure results container exists
            insertAceStreamSearchResultsContainer();

            // ensure filters exists
            insertAceStreamFilters();

            showAceStreamTab();

            var $www = createNavigationButton({
                title: 'All',
                active: false,
                id: 'acestream__www-tab-button',
            });

            if (_markupVersion == 6) {
                $www_active.before($www);
                $www_active.hide();

                var $selectedTab = $('div.mXwfNd[selected]:not(.acestream-tab-inner)');
                $selectedTab.removeAttr('selected');
            }
            else if (_markupVersion == 4 || _markupVersion == 5) {
                $acestream_btn.before($www);
            }
            else {
                $www_active.before($www);
                $www_active.hide();
            }

            // copy query string from original input
            $acestream_search_input.val(queryString);

            // do search it the query was modified
            var currQuery = $acestream_search_input.val(),
                lastQuery = App.getCurrentQuery();

            if(currQuery != lastQuery) {
                doSearch(currQuery, false, true);
            }
            else if(currQuery.length == 0) {
                App.setSearchMode("all");
                App.updateSearch();
            }

            var currentHash = location.hash;
            if(currentHash.substring(0, 1) === "#") {
                currentHash = currentHash.substring(1);
            }
            if(currentHash.indexOf("p2p=1") === -1) {
                if(currentHash.length > 0) {
                    currentHash = currentHash + "&p2p=1";
                }
                else {
                    currentHash = "p2p=1";
                }
                location.hash = currentHash;
            }

            $www.on("click", function(event) {
                event.preventDefault();

                let q = App.getCurrentQuery()
                if(!q || q.length == 0) {
                    q = App.getOriginalQuery();
                }
                location.href = "/search?q=" + encodeURIComponent(q);
            });

            if(_markupVersion == 3) {
                // mobile: hide original pagination button
                $('footer div.BmP5tf').hide();
            }

            // hide search tips
            $('div#taw').hide();

            // hide "related searches"
            $('div#botstuff').hide();

            // hide original pagination
            $('span#xjs').hide();

            // hide right container with additional info
            $('div#rhs').hide();

            // hide bottom bar with geolocation info
            $('div#footcnt div.b2hzT').hide();
        }

        return true;
    }

    function insertAceStreamSearchResultsContainerDelayed(retries, interval) {
        if(retries <=0) {
            App.debug("insertAceStreamSearchResultsContainerDelayed: give up");
            return;
        }
        if(!insertAceStreamSearchResultsContainer()) {
            setTimeout(function() {
                insertAceStreamSearchResultsContainerDelayed(retries-1, interval);
            }, interval);
        }
    }

    function insertAceStreamSearchResultsContainer() {
        if(document.getElementById("acestream-search-results-container")) {
            App.debug("insertAceStreamSearchResultsContainer: already inserted");
            return true;
        }

        if(_markupVersion == 3) {
            $original_container = $('div#main > div.O9g5cc');
        }
        else {
            // find original search container

            // list or funcs which try to find container
            var funcs = [];

            // div#search
            funcs.push(function() {
                var $container = $("div#search");
                if($container.size() == 0) {
                    return null;
                }

                $original_pagination = $('div#foot');

                return $container;
            });

            // (div.mv as parent of #rcnt)
            funcs.push(function() {
                var $rcnt = $("#rcnt");
                if($rcnt.size() > 0) {
                    if($rcnt.parent().hasClass("mw")) {
                        return $rcnt.parent();
                    }
                }

                return null;
            });

            // (div.mv before #footcnt)
            funcs.push(function() {
                var $footer = $("#footcnt");
                if($footer.size() == 0) {
                    return null;
                }

                var $container = $footer.prev();
                if(!$container.hasClass("mw")) {
                    return null;
                }

                return $container;
            });

            var $container = null;
            for(var i = 0; i < funcs.length; i++) {
                App.debug("find container: trying func " + i);
                $container = funcs[i]();
                if($container !== null) {
                    break;
                }
            }

            if($container === null) {
                return false;
            }
            $original_container = $container;
        }

        $acestream_container = $('<div id="acestream-search-results-container" class="mw acestream-mark-up-v' + _markupVersion + '"></div>');
        if(_markupVersion == 3) {
            $acestream_container.addClass('acestream__mobile');
        }
        var $search_results_container = $('<div>');
        if(_markupVersion != 3) {
            $search_results_container.css({
                "width": "580px"
            });
        }

        var $right_container = $("<div>").addClass("acestream__right-container");
        var $player_container = $("<div>").addClass("acestream__player-container");
        var $epg_container = $("<div>").addClass("acestream__epg-container");
        $right_container.append($player_container);
        $right_container.append($epg_container);

        $acestream_container.append($right_container);
        $acestream_container.append($search_results_container);

        if(_markupVersion == 3) {
            $right_container.hide();
        }

        App.setPlayerContainer($player_container);
        App.setEpgContainer($epg_container);
        App.setSeachResultsContainer($search_results_container);

        // reset query when container was reset
        App.setCurrentQuery("");

        $acestream_container.hide();

        if(_markupVersion == 3) {
            $original_container.last().after($acestream_container);
        }
        else {
            $original_container.after($acestream_container);
        }

        return true;
    }

    function insertAceStreamFilters() {
        if(document.getElementById("acestream-filters-container")) {
            App.debug("insertAceStreamFilters: already inserted");
            return;
        }

        let filterMarkupVersion = _markupVersion;

        if(_markupVersion == 4 || _markupVersion == 5 || _markupVersion == 6) {
            // filters are not initially visible so no need to hide them
            $original_filters_container = null;
        }
        else if(filterMarkupVersion == 3) {
            $original_filters_container = $("#st-card");
        }
        else {
            $original_filters_container = $("#hdtbMenus .hdtb-mn-cont");
            if($original_filters_container.size() == 0) {
                $original_filters_container = $("#hdtbMenus");
                if($original_filters_container.size() != 0) {
                    filterMarkupVersion = 4;
                }
            }
        }

        if($original_filters_container && $original_filters_container.size() == 0) {
            App.debug("insertAceStreamFilters: no original filters");
            return;
        }

        App.debug(`insertAceStreamFilters (v${filterMarkupVersion})`);

        if (filterMarkupVersion == 4 || filterMarkupVersion == 5 || filterMarkupVersion == 6) {
            $acestream_filters_container = $(`
                <div class="acestream-filters-container-v4" id="acestream-filters-container">
                    <div class="acestream-filter-item acestream__action-filter-all">
                        <div>${__('All broadcasts')}</div>
                    </div>
                    <div class="acestream-filter-item acestream__action-filter-favorite ${(App.getEngineVersion() == 0 ? 'acestream__hidden' : '')}">
                        <div>${__('Favorite')}</div>
                    </div>
                    <div class="acestream-filter-item acestream__top-category-filter acestream__action-show-category-filter" data-category-id="__all__">
                        <div class="acestream__name">${__('Select category')}</div>
                        <span class="mn-dwn-arw"></span>
                    </div>
                </div>
                `);
        }
        else if(filterMarkupVersion == 3) {
            $acestream_filters_container = $(
                '<div id="acestream-filters-container" class="Pg70bf wEsjbd O9g5cc uUPGi ZINbbc xpd">'+
                    '<div class="Xj2aue">'+
                        '<div class="coPU8c">'+
                            '<div class="RnNGze">'+
                                '<div class="PA9J5">'+
                                    '<div class="acestream__action-filter-all RXaOfd" role="button" tabindex="0">'+
                                        '<div class="TWMOUc">' + __('All broadcasts') + '</div>'+
                                    '</div>'+
                                '</div>'+
                                '<div class="PA9J5">'+
                                    '<div class="acestream__action-filter-favorite RXaOfd ' + (App.getEngineVersion() == 0 ? 'acestream__hidden' : '') + '" role="button" tabindex="0">'+
                                        '<div class="TWMOUc">' + __('Favorite') + '</div>'+
                                    '</div>'+
                                    '<span class="OmTIzf"></span>'+
                                '</div>'+
                                '<div class="PA9J5">'+
                                    '<div class="RXaOfd acestream__top-category-filter acestream__action-show-category-filter" data-category-id="__all__" role="button" tabindex="0">'+
                                        '<div class="TWMOUc acestream__name">'+
                                            __('Select category')+
                                        '</div>'+
                                        '<span class="OmTIzf"></span>'+
                                    '</div>'+
                                '</div>'+
                            '</div>'+
                        '</div>'+
                    '</div>'+
                '</div>'
                );
        }
        else {
            $acestream_filters_container = $(
                '<div id="acestream-filters-container" class="hdtb-mn-cont">'+
                    '<div style="display: inline-block; width: 160px;"></div>'+
                    '<div class="hdtb-mn-hd acestream__action-filter-all">'+
                        '<div class="mn-hd-txt">'+
                            __('All broadcasts')+
                        '</div>'+
                    '</div>'+
                    '<div class="hdtb-mn-hd acestream__action-filter-favorite '+ (App.getEngineVersion() == 0 ? 'acestream__hidden' : '') +'">'+
                        '<div class="mn-hd-txt">'+
                            __('Favorite')+
                        '</div>'+
                    '</div>'+
                    '<div class="hdtb-mn-hd acestream__top-category-filter acestream__action-show-category-filter" data-category-id="__all__">'+
                        '<div class="mn-hd-txt acestream__name">'+
                            __('Select category')+
                        '</div>'+
                        '<span class="mn-dwn-arw"></span>'+
                    '</div>'+
                '</div>'
                );
        }

        $acestream_filters_container.on("click", ".acestream__action-show-category-filter", function(e) {
            e.preventDefault();
            var offset = $(this).offset();
            var top = offset.top + $(this).height();

            App.getCategoryFilterDropdown()
                .css({
                    top: top + "px",
                    left: offset.left + "px",
                })
                .show();
        });
        $acestream_filters_container.on("click", ".acestream__action-filter-all", function(e) {
            e.preventDefault();
            App.setSearchMode("all");
            App.updateSearch();
        });
        $acestream_filters_container.on("click", ".acestream__action-filter-favorite", function(e) {
            e.preventDefault();
            App.setSearchMode("favorites");
            App.updateSearch();
        });

        if(_markupVersion == 4 || _markupVersion == 5 || _markupVersion == 6) {
            $acestream_container.append($acestream_filters_container);
        }
        else {
            $original_filters_container.after($acestream_filters_container);
        }

        if($("#acestream-navigation-tab-active").is(":visible")) {
            showAceStreamFilters();
        }
        else {
            if($acestream_filters_container) {
                $acestream_filters_container.hide();
            }
        }
    }

    function doSuggest(queryString) {
        var curr = $acestream_search_input.data("suggest-query-string");
        if(curr && curr == queryString) {
            App.debug("doSuggest: query has not changed");

            // call without items to show last results
            show_autocomplete();

            return;
        }

        App.debug("doSuggest: new query: " + queryString);

        $acestream_search_input.data("suggest-query-string", queryString);
        App.suggest({
            query: queryString,
            category: App.getCurrentCategory(),
        }, function(response) {
            var i, items = [];

            if(response && response.results) {
                for(i=0; i<response.results.length; i++) {
                    items.push({
                        title: response.results[i].name
                    });
                }
            }

            show_autocomplete(items);
        });
    }

    function doSearch(queryString, fill_input, showAllOnEmptyResults) {
        App.debug("doSearch: queryString=" + queryString + " showAllOnEmptyResults=" + showAllOnEmptyResults);

        // cancel suggest timer
        if(_suggestTimer) {
            clearTimeout(_suggestTimer);
            _suggestTimer = null;
        }
        if(fill_input) {
            $acestream_search_input.val(queryString);
        }

        App.setSearchMode("regular");
        App.setCurrentQuery(queryString);

        App.search({
            query: queryString,
            category: App.getCurrentCategory(),
            showAllOnEmptyResults: showAllOnEmptyResults,
        });

        hide_autocomplete();
    }

    function show_autocomplete(items) {
        var itemsCount = 0;
        var $popup = $(".acestream__sbdd_b");

        if(items !== undefined) {
            // fill the list
            itemsCount = items.length;
            $popup.data("items-count", itemsCount);
            var $li, $div1, $div2;
            var $list = $popup.find("ul");
            $list.empty();
            for(i=0; i<items.length; i++) {
                $li = $('<li class="acestream__sbsb_c" dir="ltr" style="text-align: left;">');
                $li.data("query-string", items[i].title);
                $div1 = $('<div>');
                $div2 = $('<div class="acestream__sbqs_c">');
                $div2.html(items[i].title);

                $div1.append($div2);
                $li.append($div1);
                $list.append($li);
            }
        }
        else {
            itemsCount = parseInt($popup.data("items-count"));
        }

        if(itemsCount > 0) {
            $popup.show();
        }
        else {
            $popup.hide();
        }
    }

    function hide_autocomplete() {
        $(".acestream__sbdd_b").hide();
    }

    function checkStats() {
        var queryString = "", start = 0;
        var queryParams = App.parseQueryString(location.search, "?");
        var hashParams = App.parseQueryString(location.hash, "#");

        if(hashParams.start) {
            start = parseInt(hashParams.start);
        }
        else if(queryParams.start) {
            start = parseInt(queryParams.start);
        }

        if(!isNaN(start) && start > 0) {
            App.debug("checkStats: got start: " + start);
            return;
        }

        if(hashParams.q) {
            queryString = hashParams.q;
        }
        else if(queryParams.q) {
            queryString = queryParams.q;
        }

        if(!queryString || queryString.length == 0) {
            App.debug("checkStats: empty query string");
            return;
        }

        App.debug("checkStats: got query string: " + queryString);

        if(queryString == _lastQueryString) {
            App.debug("checkStats: query string has not changed");
            return;
        }

        _lastQueryString = queryString;

        App.stat(queryString, SOURCE_ID);
    }

    function watchDOM() {
        // insert our tab and results container after search form was initialized

        // Get the parent element to observe
        const mainElement = document.getElementById('main');

        // Ensure the main element exists before setting up the observer
        if (mainElement) {
            // Create a new MutationObserver instance
            const observer = new MutationObserver((mutationsList, observer) => {
                for (const mutation of mutationsList) {
                    // Check if the mutation is a change to the subtree (childList or attributes for simplicity)
                    // or if a node was added/removed (which implies subtree modification)
                    if (mutation.type === 'childList' || mutation.type === 'attributes') {
                        const targetElement = mutation.target;

                        // Check the ID of the element that was modified
                        switch (targetElement.id) {
                            case 'top_nav':
                                setTimeout(insertAceStreamTab, 0);
                                break;
                            case 'cnt':
                                App.debug("#cnt modified");
                                setTimeout(insertAceStreamSearchResultsContainer, 0);
                                break;
                            case 'hdtbMenus':
                                setTimeout(insertAceStreamFilters, 0);
                                break;
                        }
                    }
                }
            });

            // Configure the observer:
            // subtree: true -> observe changes in descendants of mainElement
            // childList: true -> observe additions/removals of direct children
            // attributes: true -> observe attribute changes on mainElement and its descendants (optional, depends on what 'modification' means for your use case)
            // You might also consider characterData: true if content changes inside text nodes are relevant
            observer.observe(mainElement, { subtree: true, childList: true, attributes: true });

            // Optional: To stop observing later, you can call observer.disconnect();
            // observer.disconnect();
        } else {
            App.debug("Element with ID 'main' not found. Cannot attach MutationObserver.");
        }
    }

    // stats
    if(location.pathname == "/search") {
        checkStats();
        $(window).on("hashchange", function() {
            checkStats();
        });
    }

    // init
    if(location.pathname == "/" || location.pathname == "/webhp" || location.pathname == "/search") {
        TorrentStream.Lang.setCurrent(App.getHtmlLanguage());
        App.setJsPlayerEnabled(true);
        App.setSearchResultsCallback(searchResultsCallback);
        App.setCategoryChangedCallback(onCurrentCategoryChanged);
        App.setSearchModeChangedCallback(onSearchModeChanged);
        App.updateFavoritesTask();
        App.injectCommonStyles();
        App.addStyleOnce("css_google");
        App.createCommonElements();
        App.setupCommonEvents();
        App.addHideOnClickOutsideElements([
            {
                element: ".acestream__sbdd_b",
                selectors: [".acestream__sfibbbc"]
            }
            ]);

        detectMarkupVersion();

        // find original search form
        var $original_search_form = findSearchForm();

        if(_markupVersion == 3) {
            // mobile version
            App.setOption('add_to_playlist.hide', true);
            App.setOption('select_player.hide', true);
        }

        var $search = $(".serp-header__search2");
        var $acestream_search_form = $(
            '<div class="acestream__sfibbbc">'+
                '<div class="acestream__sbtc">'+
                    '<div class="acestream__sbibtd">'+
                        '<div class="acestream__sfsbc">'+
                            '<div class="acestream__nojsb">'+
                                '<div class="acestream__ds">'+
                                    '<div class="acestream__kpbb">'+
                                        '<button class="acestream__lsb">'+
                                            '<span class="acestream__sbico"></span>'+
                                        '</button>'+
                                    '</div>'+
                                '</div>'+
                            '</div>'+
                        '</div>'+
                        '<div class="acestream__sbibod">'+
                            '<div class="acestream__gstl_0 acestream__sbib_a" style="height: 38px;">'+
                                '<div class="acestream__sbib_b" dir="ltr">'+
                                    '<div style="position: relative;">'+
                                        '<input class="acestream__gsfi" maxlength="2048" type="text" value="" dir="ltr">'+
                                    '</div>'+
                                '</div>'+
                            '</div>'+
                        '</div>'+
                    '</div>'+
                    '<div class="acestream__sbdd_a" style="min-width: 590px; top: 39px; position: absolute; text-align: left; left: 0px;" dir="ltr">'+
                        '<div>'+
                            '<div class="acestream__sbdd_b">'+
                                '<div class="acestream__sbsb_a">'+
                                    '<ul class="acestream__sbsb_b">'+
                                    '</ul>'+
                                '</div>'+
                            '</div>'+
                        '</div>'+
                    '</div>'+
                '</div>'+
            '</div>'
            );

        $acestream_search_form.hide();
        $original_search_form.after($acestream_search_form);

        if(_markupVersion == 2 || _markupVersion == 4 || _markupVersion == 5 || _markupVersion == 6) {
            var $google_logo = $original_search_form.find('.logo').clone();
            $acestream_search_form.prepend($google_logo);
            $acestream_search_form.css({
                'margin-left': '150px',
                'position': 'relative',
            });
        }
        else if(_markupVersion == 3) {
            $acestream_search_form.addClass('acestream__mobile');
        }

        var $acestream_search_input = $acestream_search_form.find("input");
        var $acestream_search_button = $acestream_search_form.find("button");

        // copy query string from original search input
        var $original_search_input = findSearchInput();

        // save original search query
        App.setOriginalQuery($original_search_input.val());

        // catch original search input changes
        $original_search_input.on("change", function() {
            $acestream_search_input.val($(this).val());
        });

        $acestream_search_button.on("click", function(e) {
            doSearch($acestream_search_input.val());
        });

        $acestream_search_input.on("click", function(e) {
            doSuggest($(this).val());
        });

        watchDOM();

        insertAceStreamSearchResultsContainerDelayed(20, 100);
        insertAceStreamFilters();
        insertAceStreamTab();

        $acestream_search_input.on("keyup", function(e) {
            var queryString = $(this).val();

            if(e.keyCode == 13) {
                // searcn on Enter
                doSearch(queryString);
            }
            else {
                if(queryString.length != _lastQueryLength) {
                    // trigger only when length has changed
                    _lastQueryLength = queryString.length;

                    if(_suggestTimer) {
                        clearTimeout(_suggestTimer);
                        _suggestTimer = null;
                    }
                    _suggestTimer = setTimeout(function() {
                        doSuggest(queryString);
                    }, SUGGEST_INTERVAL);
                }
            }
        });

        // prevent google handler
        $acestream_search_input.on("keypress", function(e) {
            if(e.keyCode== 13) {
                e.preventDefault();
            }
        });

        $(".acestream__sbdd_b").on("click", "li.acestream__sbsb_c", function(e) {
            var queryString = $(this).data("query-string");
            doSearch(queryString, true);
        });

        // context search
        var now = Date.now(),
            contextLastCheck = GM_getValue("context_last_check"),
            contextEnabled = GM_getValue("context_enabled");

        App.debug("context: last_check=" + contextLastCheck + " enabled=" + contextEnabled);
        if(!contextLastCheck || (now - contextLastCheck) > 14400000) {
            GM_xmlhttpRequest({
                method: "GET",
                url: "http://awe-api.acestream.me/search/conf",
                onload: function(response) {
                    try {
                        if(response.status == 200) {
                            var conf = JSON.parse(response.responseText);
                            GM_setValue("context_last_check", now);
                            GM_setValue("context_enabled", !!conf.context);
                        }
                    }
                    catch(e) {
                        App.debug("failed to parse conf: " + e);
                    }
                }
            });
        }

        function contextSearch() {
            //TOD: implement
        }

        if(contextEnabled) {
            contextSearch();
        }
    }
});

